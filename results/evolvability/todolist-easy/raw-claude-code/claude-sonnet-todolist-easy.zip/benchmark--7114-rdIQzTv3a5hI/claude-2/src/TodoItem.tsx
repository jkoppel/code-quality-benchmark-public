import React, { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus: (id: string, status: TodoStatus) => void;
  onUpdatePriority: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate: (id: string, dueDate: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggle, 
  onDelete, 
  onEdit, 
  onUpdateStatus, 
  onUpdatePriority, 
  onUpdateDueDate 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const getPriorityColor = (priority: TodoPriority) => {
    switch (priority) {
      case 'urgent': return '#ff4444';
      case 'high': return '#ff9900';
      case 'medium': return '#0066cc';
      case 'low': return '#666666';
    }
  };

  const getStatusColor = (status: TodoStatus) => {
    switch (status) {
      case 'not-started': return '#cccccc';
      case 'in-progress': return '#0066cc';
      case 'under-review': return '#9900cc';
      case 'blocked': return '#ff4444';
      case 'done': return '#00aa00';
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return `${Math.abs(diffDays)} days overdue`;
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `Due in ${diffDays} days`;
  };

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <div style={{ 
      border: '1px solid #ccc', 
      borderLeft: `4px solid ${getPriorityColor(todo.priority)}`,
      marginBottom: '8px', 
      padding: '12px',
      backgroundColor: todo.status === 'done' ? '#f0f8ff' : 'white'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => onToggle(todo.id)}
          style={{ marginRight: '12px' }}
        />
        
        {isEditing ? (
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSave();
              if (e.key === 'Escape') handleCancel();
            }}
            style={{ flex: 1, padding: '4px', border: '1px solid #ccc' }}
            autoFocus
          />
        ) : (
          <span
            style={{
              flex: 1,
              textDecoration: todo.completed ? 'line-through' : 'none',
              cursor: 'pointer',
              fontWeight: todo.priority === 'urgent' ? 'bold' : 'normal'
            }}
            onDoubleClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
        )}
        
        <div style={{ display: 'flex', gap: '4px', marginLeft: '8px' }}>
          {isEditing ? (
            <>
              <button onClick={handleSave} style={{ fontSize: '12px', padding: '4px 8px' }}>Save</button>
              <button onClick={handleCancel} style={{ fontSize: '12px', padding: '4px 8px' }}>Cancel</button>
            </>
          ) : (
            <>
              <button onClick={() => setIsEditing(true)} style={{ fontSize: '12px', padding: '4px 8px' }}>Edit</button>
              <button onClick={() => onDelete(todo.id)} style={{ fontSize: '12px', padding: '4px 8px' }}>Delete</button>
            </>
          )}
        </div>
      </div>
      
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Status:</span>
          <select
            value={todo.status}
            onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
            style={{ 
              fontSize: '12px', 
              padding: '2px 4px', 
              border: '1px solid #ccc',
              backgroundColor: getStatusColor(todo.status),
              color: 'white',
              fontWeight: 'bold'
            }}
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Priority:</span>
          <select
            value={todo.priority}
            onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
            style={{ 
              fontSize: '12px', 
              padding: '2px 4px', 
              border: '1px solid #ccc',
              color: getPriorityColor(todo.priority),
              fontWeight: 'bold'
            }}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Due:</span>
          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value)}
            style={{ fontSize: '12px', padding: '2px 4px', border: '1px solid #ccc' }}
          />
          {todo.dueDate && (
            <span style={{ 
              color: formatDate(todo.dueDate)?.includes('overdue') ? '#ff4444' : '#666',
              fontWeight: formatDate(todo.dueDate)?.includes('overdue') ? 'bold' : 'normal'
            }}>
              ({formatDate(todo.dueDate)})
            </span>
          )}
        </div>
      </div>
    </div>
  );
};