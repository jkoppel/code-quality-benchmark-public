export type TodoStatus = 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'done';
export type TodoPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string;
}