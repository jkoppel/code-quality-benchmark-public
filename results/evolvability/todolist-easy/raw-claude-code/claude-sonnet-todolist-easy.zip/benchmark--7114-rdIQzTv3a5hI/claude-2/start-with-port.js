#!/usr/bin/env node

const { spawn } = require('child_process');
const args = process.argv.slice(2);

// Extract port from --port=VALUE or --port VALUE
let port = null;
const filteredArgs = [];

for (let i = 0; i < args.length; i++) {
  if (args[i].startsWith('--port=')) {
    port = args[i].split('=')[1];
  } else if (args[i] === '--port' && i + 1 < args.length) {
    port = args[i + 1];
    i++; // skip next argument since it's the port value
  } else {
    filteredArgs.push(args[i]);
  }
}

// Set PORT environment variable if provided
if (port) {
  process.env.PORT = port;
}

// Start react-scripts with remaining arguments
const child = spawn('npx', ['react-scripts', 'start', ...filteredArgs], {
  stdio: 'inherit',
  env: process.env
});

child.on('exit', (code) => {
  process.exit(code);
});