export type TodoStatus = 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'completed';
export type TodoPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Todo {
  id: string;
  text: string;
  completed: boolean; // Keep for backward compatibility
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string; // ISO date string
}