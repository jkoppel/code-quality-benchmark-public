import React, { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus: (id: string, status: TodoStatus) => void;
  onUpdatePriority: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate: (id: string, dueDate?: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggle, 
  onDelete, 
  onEdit, 
  onUpdateStatus, 
  onUpdatePriority, 
  onUpdateDueDate 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const getStatusColor = (status: TodoStatus) => {
    const colors = {
      'not-started': '#gray',
      'in-progress': '#1890ff',
      'under-review': '#faad14',
      'blocked': '#ff4d4f',
      'completed': '#52c41a'
    };
    return colors[status] || '#gray';
  };

  const getPriorityColor = (priority: TodoPriority) => {
    const colors = {
      'low': '#52c41a',
      'medium': '#faad14',
      'high': '#ff7a45',
      'urgent': '#ff4d4f'
    };
    return colors[priority] || '#gray';
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return { text: `Overdue by ${Math.abs(diffDays)} day(s)`, color: '#ff4d4f' };
    } else if (diffDays === 0) {
      return { text: 'Due today', color: '#faad14' };
    } else if (diffDays <= 3) {
      return { text: `Due in ${diffDays} day(s)`, color: '#faad14' };
    } else {
      return { text: date.toLocaleDateString(), color: '#666' };
    }
  };

  const dueDateInfo = formatDate(todo.dueDate);

  return (
    <div style={{ 
      padding: '12px', 
      border: '1px solid #ccc', 
      marginBottom: '8px',
      backgroundColor: todo.completed ? '#f6f6f6' : '#fff'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => onToggle(todo.id)}
          style={{ marginRight: '12px' }}
        />
        
        {isEditing ? (
          <>
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSave();
                if (e.key === 'Escape') handleCancel();
              }}
              style={{ flex: 1, marginRight: '8px', padding: '4px' }}
              autoFocus
            />
            <button onClick={handleSave} style={{ marginRight: '4px' }}>Save</button>
            <button onClick={handleCancel}>Cancel</button>
          </>
        ) : (
          <>
            <span
              style={{
                flex: 1,
                textDecoration: todo.completed ? 'line-through' : 'none',
                cursor: 'pointer',
                fontSize: '16px'
              }}
              onDoubleClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <button onClick={() => setIsEditing(true)} style={{ marginRight: '4px' }}>Edit</button>
            <button onClick={() => onDelete(todo.id)}>Delete</button>
          </>
        )}
      </div>

      <div style={{ display: 'flex', gap: '12px', alignItems: 'center', fontSize: '14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Status:</span>
          <select
            value={todo.status}
            onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
            style={{ 
              padding: '2px 4px', 
              border: '1px solid #ccc',
              backgroundColor: getStatusColor(todo.status),
              color: 'white',
              fontSize: '12px'
            }}
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="completed">Completed</option>
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Priority:</span>
          <select
            value={todo.priority}
            onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
            style={{ 
              padding: '2px 4px', 
              border: '1px solid #ccc',
              backgroundColor: getPriorityColor(todo.priority),
              color: 'white',
              fontSize: '12px'
            }}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Due:</span>
          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value || undefined)}
            style={{ padding: '2px 4px', border: '1px solid #ccc', fontSize: '12px' }}
          />
          {dueDateInfo && (
            <span style={{ color: dueDateInfo.color, fontSize: '12px', fontWeight: 'bold' }}>
              {dueDateInfo.text}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};