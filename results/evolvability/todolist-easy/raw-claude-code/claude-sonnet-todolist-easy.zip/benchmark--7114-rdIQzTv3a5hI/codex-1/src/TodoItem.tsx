import React, { useState } from 'react';
import { Todo, TodoPriority, TodoStatus } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdate: (id: string, updates: Partial<Todo>) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '8px', border: '1px solid #ccc', marginBottom: '4px', gap: '8px', flexWrap: 'wrap' }}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
        style={{ marginRight: '8px' }}
      />
      
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSave();
              if (e.key === 'Escape') handleCancel();
            }}
            style={{ flex: 1, marginRight: '8px' }}
            autoFocus
          />
          <button onClick={handleSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </>
      ) : (
        <>
          <span
            style={{
              flex: 1,
              textDecoration: todo.completed ? 'line-through' : 'none',
              cursor: 'pointer'
            }}
            onDoubleClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <label style={{ fontSize: '0.85em' }}>
              Status:
              <select
                value={(todo.status ?? 'not-started') as TodoStatus}
                onChange={(e) => onUpdate(todo.id, { status: e.target.value as TodoStatus })}
                style={{ marginLeft: '4px' }}
              >
                <option value="not-started">Not started</option>
                <option value="in-progress">In progress</option>
                <option value="under-review">Under review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
            </label>
            <label style={{ fontSize: '0.85em' }}>
              Priority:
              <select
                value={(todo.priority ?? 'medium') as TodoPriority}
                onChange={(e) => onUpdate(todo.id, { priority: e.target.value as TodoPriority })}
                style={{ marginLeft: '4px' }}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </label>
            <label style={{ fontSize: '0.85em' }}>
              Due:
              <input
                type="date"
                value={todo.dueDate ?? ''}
                onChange={(e) => onUpdate(todo.id, { dueDate: e.target.value || undefined })}
                style={{ marginLeft: '4px' }}
              />
            </label>
          </div>
          <button onClick={() => setIsEditing(true)}>Edit</button>
          <button onClick={() => onDelete(todo.id)}>Delete</button>
        </>
      )}
    </div>
  );
};
