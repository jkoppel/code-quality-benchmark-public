import React, { useState } from 'react';
import { TodoPriority, TodoStatus } from './types';

interface AddTodoProps {
  onAdd: (
    text: string,
    status?: TodoStatus,
    priority?: TodoPriority,
    dueDate?: string
  ) => void;
}

export const AddTodo: React.FC<AddTodoProps> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [status, setStatus] = useState<TodoStatus>('not-started');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAdd(text.trim(), status, priority, dueDate || undefined);
      setText('');
      setStatus('not-started');
      setPriority('medium');
      setDueDate('');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add a new todo..."
          style={{ flex: 1, padding: '8px', border: '1px solid #ccc' }}
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as TodoStatus)}
          style={{ padding: '8px', border: '1px solid #ccc' }}
          aria-label="Status"
        >
          <option value="not-started">Not started</option>
          <option value="in-progress">In progress</option>
          <option value="under-review">Under review</option>
          <option value="blocked">Blocked</option>
          <option value="done">Done</option>
        </select>
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value as TodoPriority)}
          style={{ padding: '8px', border: '1px solid #ccc' }}
          aria-label="Priority"
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          style={{ padding: '8px', border: '1px solid #ccc' }}
          aria-label="Due date"
        />
        <button type="submit" style={{ padding: '8px 16px' }}>
          Add
        </button>
      </div>
    </form>
  );
};
