export type TodoStatus =
  | 'not-started'
  | 'in-progress'
  | 'under-review'
  | 'blocked'
  | 'done';

export type TodoPriority = 'low' | 'medium' | 'high';

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  status?: TodoStatus;
  priority?: TodoPriority;
  // ISO date string (YYYY-MM-DD)
  dueDate?: string;
}
