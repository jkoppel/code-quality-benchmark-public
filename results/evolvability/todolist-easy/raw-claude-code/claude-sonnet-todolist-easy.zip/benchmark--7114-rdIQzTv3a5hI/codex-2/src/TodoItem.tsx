import React, { useState } from 'react';
import { Todo } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onStatusChange: (id: string, status: Todo['status']) => void;
  onPriorityChange: (id: string, priority: Todo['priority']) => void;
  onDueDateChange: (id: string, dueDate: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onStatusChange, onPriorityChange, onDueDateChange }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '8px', border: '1px solid #ccc', marginBottom: '4px', gap: '8px', flexWrap: 'wrap' }}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
        style={{ marginRight: '8px' }}
      />
      
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSave();
              if (e.key === 'Escape') handleCancel();
            }}
            style={{ flex: 1, minWidth: '200px' }}
            autoFocus
          />
          <button onClick={handleSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </>
      ) : (
        <>
          <span
            style={{
              flex: 1,
              textDecoration: todo.completed ? 'line-through' : 'none',
              cursor: 'pointer'
            }}
            onDoubleClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
          <button onClick={() => setIsEditing(true)}>Edit</button>
          <button onClick={() => onDelete(todo.id)}>Delete</button>
        </>
      )}

      <label style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
        <span style={{ fontSize: '0.85em', color: '#555' }}>Status:</span>
        <select
          value={todo.status}
          onChange={(e) => onStatusChange(todo.id, e.target.value as Todo['status'])}
        >
          <option value="not_started">Not started</option>
          <option value="in_progress">In progress</option>
          <option value="under_review">Under review</option>
          <option value="blocked">Blocked</option>
          <option value="done">Done</option>
        </select>
      </label>

      <label style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
        <span style={{ fontSize: '0.85em', color: '#555' }}>Priority:</span>
        <select
          value={todo.priority}
          onChange={(e) => onPriorityChange(todo.id, e.target.value as Todo['priority'])}
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </label>

      <label style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
        <span style={{ fontSize: '0.85em', color: '#555' }}>Due:</span>
        <input
          type="date"
          value={todo.dueDate || ''}
          onChange={(e) => onDueDateChange(todo.id, e.target.value)}
        />
      </label>
    </div>
  );
};
