export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  // Additional metadata
  status: 'not_started' | 'in_progress' | 'under_review' | 'blocked' | 'done';
  priority: 'low' | 'medium' | 'high';
  // Stored as YYYY-MM-DD string for simplicity
  dueDate?: string;
}
