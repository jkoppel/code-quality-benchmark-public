export type TodoStatus =
  | 'not_started'
  | 'in_progress'
  | 'under_review'
  | 'blocked'
  | 'done';

export type TodoPriority = 'low' | 'medium' | 'high';

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string; // ISO date string (YYYY-MM-DD)
}
