import React, { useState } from 'react';
import { Todo, TodoPriority, TodoStatus } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus: (id: string, status: TodoStatus) => void;
  onUpdatePriority: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate: (id: string, dueDate?: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '8px', border: '1px solid #ccc', marginBottom: '4px', gap: '8px' }}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
        style={{ marginRight: '8px' }}
      />
      
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSave();
              if (e.key === 'Escape') handleCancel();
            }}
            style={{ flex: 1, marginRight: '8px' }}
            autoFocus
          />
          <button onClick={handleSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </>
      ) : (
        <>
          <span
            style={{
              flex: 1,
              textDecoration: todo.completed ? 'line-through' : 'none',
              cursor: 'pointer'
            }}
            onDoubleClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>

          <select
            value={todo.status}
            onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
            title="Status"
          >
            <option value="not_started">Not started</option>
            <option value="in_progress">In progress</option>
            <option value="under_review">Under review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>

          <select
            value={todo.priority}
            onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
            title="Priority"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>

          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value || undefined)}
            title="Due date"
          />
          <button onClick={() => setIsEditing(true)}>Edit</button>
          <button onClick={() => onDelete(todo.id)}>Delete</button>
        </>
      )}
    </div>
  );
};
