import React, { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from './types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onStatusChange: (id: string, status: TodoStatus) => void;
  onPriorityChange: (id: string, priority: TodoPriority) => void;
  onDueDateChange: (id: string, dueDate?: string) => void;
}

export const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onStatusChange, onPriorityChange, onDueDateChange }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const getPriorityColor = (priority: TodoPriority) => {
    switch (priority) {
      case 'high': return '#ff6b6b';
      case 'medium': return '#feca57';
      case 'low': return '#48dbfb';
      default: return '#ddd';
    }
  };

  const getStatusColor = (status: TodoStatus) => {
    switch (status) {
      case 'completed': return '#2ed573';
      case 'in-progress': return '#3742fa';
      case 'under-review': return '#ff9ff3';
      case 'blocked': return '#ff6b6b';
      default: return '#ddd';
    }
  };

  const isOverdue = todo.dueDate && new Date(todo.dueDate) < new Date() && !todo.completed;

  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      padding: '12px', 
      border: '1px solid #ccc', 
      marginBottom: '8px',
      borderLeft: `4px solid ${getPriorityColor(todo.priority)}`,
      backgroundColor: isOverdue ? '#ffe6e6' : 'white'
    }}>
      {/* Main row */}
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => onToggle(todo.id)}
          style={{ marginRight: '8px' }}
        />
        
        {isEditing ? (
          <>
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSave();
                if (e.key === 'Escape') handleCancel();
              }}
              style={{ flex: 1, marginRight: '8px', padding: '4px' }}
              autoFocus
            />
            <button onClick={handleSave} style={{ marginRight: '4px' }}>Save</button>
            <button onClick={handleCancel}>Cancel</button>
          </>
        ) : (
          <>
            <span
              style={{
                flex: 1,
                textDecoration: todo.completed ? 'line-through' : 'none',
                cursor: 'pointer',
                fontWeight: todo.priority === 'high' ? 'bold' : 'normal'
              }}
              onDoubleClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <button onClick={() => setIsEditing(true)} style={{ marginRight: '4px' }}>Edit</button>
            <button onClick={() => onDelete(todo.id)}>Delete</button>
          </>
        )}
      </div>
      
      {/* Status, Priority, Due Date row */}
      <div style={{ display: 'flex', gap: '12px', alignItems: 'center', fontSize: '14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Status:</span>
          <select 
            value={todo.status} 
            onChange={(e) => onStatusChange(todo.id, e.target.value as TodoStatus)}
            style={{ 
              padding: '2px 4px', 
              fontSize: '12px',
              backgroundColor: getStatusColor(todo.status),
              color: 'white',
              border: 'none',
              borderRadius: '3px'
            }}
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Priority:</span>
          <select 
            value={todo.priority} 
            onChange={(e) => onPriorityChange(todo.id, e.target.value as TodoPriority)}
            style={{ 
              padding: '2px 4px', 
              fontSize: '12px',
              backgroundColor: getPriorityColor(todo.priority),
              color: 'white',
              border: 'none',
              borderRadius: '3px'
            }}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span>Due:</span>
          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onDueDateChange(todo.id, e.target.value || undefined)}
            style={{ 
              padding: '2px 4px', 
              fontSize: '12px',
              border: '1px solid #ccc',
              borderRadius: '3px'
            }}
          />
          {isOverdue && <span style={{ color: 'red', fontSize: '12px' }}>⚠️ Overdue</span>}
        </div>
      </div>
    </div>
  );
};