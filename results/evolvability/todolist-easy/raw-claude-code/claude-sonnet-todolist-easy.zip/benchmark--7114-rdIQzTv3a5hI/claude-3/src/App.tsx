import React, { useState } from 'react';
import './App.css';
import { Todo, TodoStatus, TodoPriority } from './types';
import { TodoList } from './TodoList';
import { AddTodo } from './AddTodo';

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);

  const addTodo = (text: string, priority: TodoPriority = 'medium', dueDate?: string) => {
    const newTodo: Todo = {
      id: Date.now().toString(),
      text,
      completed: false,
      status: 'not-started',
      priority,
      dueDate,
    };
    setTodos(prev => [...prev, newTodo]);
  };

  const toggleTodo = (id: string) => {
    setTodos(prev =>
      prev.map(todo =>
        todo.id === id 
          ? { 
              ...todo, 
              completed: !todo.completed,
              status: !todo.completed ? 'completed' : 'not-started'
            } 
          : todo
      )
    );
  };

  const deleteTodo = (id: string) => {
    setTodos(prev => prev.filter(todo => todo.id !== id));
  };

  const editTodo = (id: string, newText: string) => {
    setTodos(prev =>
      prev.map(todo =>
        todo.id === id ? { ...todo, text: newText } : todo
      )
    );
  };

  const updateTodoStatus = (id: string, status: TodoStatus) => {
    setTodos(prev =>
      prev.map(todo =>
        todo.id === id 
          ? { 
              ...todo, 
              status,
              completed: status === 'completed'
            } 
          : todo
      )
    );
  };

  const updateTodoPriority = (id: string, priority: TodoPriority) => {
    setTodos(prev =>
      prev.map(todo =>
        todo.id === id ? { ...todo, priority } : todo
      )
    );
  };

  const updateTodoDueDate = (id: string, dueDate?: string) => {
    setTodos(prev =>
      prev.map(todo =>
        todo.id === id ? { ...todo, dueDate } : todo
      )
    );
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Todo List</h1>
        <div style={{ maxWidth: '500px', width: '100%' }}>
          <AddTodo onAdd={addTodo} />
          <TodoList
            todos={todos}
            onToggle={toggleTodo}
            onDelete={deleteTodo}
            onEdit={editTodo}
            onStatusChange={updateTodoStatus}
            onPriorityChange={updateTodoPriority}
            onDueDateChange={updateTodoDueDate}
          />
        </div>
      </header>
    </div>
  );
}

export default App;
