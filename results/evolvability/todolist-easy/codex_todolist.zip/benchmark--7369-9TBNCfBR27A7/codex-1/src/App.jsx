import React, { useState } from 'react';

function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function TodoForm({ onAdd }) {
  const [text, setText] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    onAdd(value);
    setText('');
  };

  return (
    <form onSubmit={submit} className="row">
      <label htmlFor="new-todo" className="visually-hidden">New todo</label>
      <input
        id="new-todo"
        type="text"
        placeholder="Add a task..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label="Add a task"
      />
      <button type="submit" className="primary">Add</button>
    </form>
  );
}

function TodoItem({ todo, onToggle, onDelete, onUpdate, onMutate }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(todo.text);
  const [status, setStatus] = useState(todo.status || 'not-started');
  const [priority, setPriority] = useState(todo.priority || 'medium');
  const [dueDate, setDueDate] = useState(todo.dueDate || '');

  const save = () => {
    const value = draft.trim();
    if (!value) return; // do not save empty
    if (value !== todo.text) onUpdate(todo.id, value);
    const updates = {};
    if (status !== (todo.status || 'not-started')) updates.status = status;
    if (priority !== (todo.priority || 'medium')) updates.priority = priority;
    if ((dueDate || '') !== (todo.dueDate || '')) updates.dueDate = dueDate || '';
    if (Object.keys(updates).length) onMutate(todo.id, updates);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(todo.text);
    setStatus(todo.status || 'not-started');
    setPriority(todo.priority || 'medium');
    setDueDate(todo.dueDate || '');
    setEditing(false);
  };

  return (
    <li className="todo-item">
      <input
        id={`chk-${todo.id}`}
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo.id)}
        aria-label={todo.done ? 'Mark as not done' : 'Mark as done'}
      />
      {editing ? (
        <div className="edit-fields">
          <input
            className="todo-text"
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') save();
              if (e.key === 'Escape') cancel();
            }}
            autoFocus
          />
          <div className="row">
            <label className="visually-hidden" htmlFor={`status-${todo.id}`}>Status</label>
            <select id={`status-${todo.id}`} value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="not-started">Not started</option>
              <option value="in-progress">In progress</option>
              <option value="under-review">Under review</option>
              <option value="blocked">Blocked</option>
              <option value="done">Done</option>
            </select>
            <label className="visually-hidden" htmlFor={`priority-${todo.id}`}>Priority</label>
            <select id={`priority-${todo.id}`} value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
            <label className="visually-hidden" htmlFor={`due-${todo.id}`}>Due date</label>
            <input id={`due-${todo.id}`} type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
        </div>
      ) : (
        <label
          className={`todo-text ${todo.done ? 'done' : ''}`}
          htmlFor={`chk-${todo.id}`}
        >
          {todo.text}
        </label>
      )}
      {!editing && (
        <div className="meta">
          <span className={`badge status ${todo.status || 'not-started'}`}>{(todo.status || 'not-started').replace('-', ' ')}</span>
          <span className={`badge priority ${todo.priority || 'medium'}`}>{todo.priority || 'medium'}</span>
          {todo.dueDate ? <span className="badge due">Due {todo.dueDate}</span> : null}
        </div>
      )}
      <div className="actions">
        {editing ? (
          <>
            <button onClick={save} className="primary" aria-label="Save">Save</button>
            <button onClick={cancel} aria-label="Cancel">Cancel</button>
          </>
        ) : (
          <>
            <button onClick={() => setEditing(true)} aria-label="Edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} aria-label="Delete">Delete</button>
          </>
        )}
      </div>
    </li>
  );
}

function TodoList({ todos, onToggle, onDelete, onUpdate, onMutate }) {
  if (!todos.length) return <p className="muted">No tasks yet. Add one above.</p>;
  return (
    <ul>
      {todos.map((t) => (
        <TodoItem
          key={t.id}
          todo={t}
          onToggle={onToggle}
          onDelete={onDelete}
          onUpdate={onUpdate}
          onMutate={onMutate}
        />
      ))}
    </ul>
  );
}

export default function App() {
  const [todos, setTodos] = useState([]);

  const add = (text) => setTodos((xs) => [
    { id: uid(), text, done: false, status: 'not-started', priority: 'medium', dueDate: '' },
    ...xs,
  ]);
  const toggle = (id) => setTodos((xs) => xs.map((t) => {
    if (t.id !== id) return t;
    const nextDone = !t.done;
    return { ...t, done: nextDone, status: nextDone ? 'done' : (t.status === 'done' ? 'not-started' : (t.status || 'not-started')) };
  }));
  const update = (id, text) => setTodos((xs) => xs.map((t) => (t.id === id ? { ...t, text } : t)));
  const mutate = (id, patch) => setTodos((xs) => xs.map((t) => {
    if (t.id !== id) return t;
    const next = { ...t, ...patch };
    if (Object.prototype.hasOwnProperty.call(patch, 'status')) {
      next.done = patch.status === 'done';
    }
    if (Object.prototype.hasOwnProperty.call(patch, 'done')) {
      // keep status in sync if done was directly changed by other means
      next.status = patch.done ? 'done' : (t.status === 'done' ? 'not-started' : (t.status || 'not-started'));
    }
    return next;
  }));
  const remove = (id) => setTodos((xs) => xs.filter((t) => t.id !== id));

  return (
    <div className="container">
      <h1>Todo List</h1>
      <div className="card">
        <TodoForm onAdd={add} />
        <div className="space" />
        <TodoList todos={todos} onToggle={toggle} onDelete={remove} onUpdate={update} onMutate={mutate} />
        <div className="space" />
      </div>
    </div>
  );
}
