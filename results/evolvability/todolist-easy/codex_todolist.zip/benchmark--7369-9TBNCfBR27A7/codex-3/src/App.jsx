import React, { useState } from 'react';

function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const STATUSES = ['todo', 'in-progress', 'under-review', 'blocked', 'done'];
const PRIORITIES = ['low', 'medium', 'high'];

function TodoForm({ onAdd }) {
  const [text, setText] = useState('');
  const [status, setStatus] = useState('todo');
  const [priority, setPriority] = useState('medium');
  const [dueDate, setDueDate] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    onAdd({ text: value, status, priority, dueDate });
    setText('');
    setStatus('todo');
    setPriority('medium');
    setDueDate('');
  };

  return (
    <form onSubmit={submit} className="row">
      <label htmlFor="new-todo" className="visually-hidden">New todo</label>
      <input
        id="new-todo"
        type="text"
        placeholder="Add a task..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label="Add a task"
      />
      <select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
        {STATUSES.map((s) => (
          <option key={s} value={s}>{s}</option>
        ))}
      </select>
      <select aria-label="Priority" value={priority} onChange={(e) => setPriority(e.target.value)}>
        {PRIORITIES.map((p) => (
          <option key={p} value={p}>{p}</option>
        ))}
      </select>
      <input
        type="date"
        aria-label="Due date"
        value={dueDate}
        onChange={(e) => setDueDate(e.target.value)}
      />
      <button type="submit" className="primary">Add</button>
    </form>
  );
}

function TodoItem({ todo, onToggle, onDelete, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(todo.text);

  const save = () => {
    const value = draft.trim();
    if (!value) return; // do not save empty
    if (value !== todo.text) onUpdate(todo.id, value);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(todo.text);
    setEditing(false);
  };

  return (
    <li className="todo-item">
      <input
        id={`chk-${todo.id}`}
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo.id)}
        aria-label={todo.done ? 'Mark as not done' : 'Mark as done'}
      />
      {editing ? (
        <input
          className="todo-text"
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') save();
            if (e.key === 'Escape') cancel();
          }}
          autoFocus
        />
      ) : (
        <label
          className={`todo-text ${todo.done ? 'done' : ''}`}
          htmlFor={`chk-${todo.id}`}
        >
          {todo.text}
        </label>
      )}
      <div className="row" style={{ flex: '0 0 auto', gap: 8 }}>
        <select
          aria-label="Status"
          value={todo.status}
          onChange={(e) => onUpdate(todo.id, { status: e.target.value })}
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select
          aria-label="Priority"
          value={todo.priority}
          onChange={(e) => onUpdate(todo.id, { priority: e.target.value })}
        >
          {PRIORITIES.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        <input
          type="date"
          aria-label="Due date"
          value={todo.dueDate || ''}
          onChange={(e) => onUpdate(todo.id, { dueDate: e.target.value })}
        />
      </div>
      <div className="actions">
        {editing ? (
          <>
            <button onClick={save} className="primary" aria-label="Save">Save</button>
            <button onClick={cancel} aria-label="Cancel">Cancel</button>
          </>
        ) : (
          <>
            <button onClick={() => setEditing(true)} aria-label="Edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} aria-label="Delete">Delete</button>
          </>
        )}
      </div>
    </li>
  );
}

function TodoList({ todos, onToggle, onDelete, onUpdate }) {
  if (!todos.length) return <p className="muted">No tasks yet. Add one above.</p>;
  return (
    <ul>
      {todos.map((t) => (
        <TodoItem
          key={t.id}
          todo={t}
          onToggle={onToggle}
          onDelete={onDelete}
          onUpdate={onUpdate}
        />
      ))}
    </ul>
  );
}

export default function App() {
  const [todos, setTodos] = useState([]);

  const add = (payload) =>
    setTodos((xs) => {
      if (typeof payload === 'string') {
        return [
          { id: uid(), text: payload, done: false, status: 'todo', priority: 'medium', dueDate: '' },
          ...xs,
        ];
      }
      const text = payload.text ?? '';
      const status = payload.status ?? 'todo';
      const priority = payload.priority ?? 'medium';
      const dueDate = payload.dueDate ?? '';
      return [
        { id: uid(), text, status, priority, dueDate, done: status === 'done' },
        ...xs,
      ];
    });

  const toggle = (id) =>
    setTodos((xs) =>
      xs.map((t) =>
        t.id === id
          ? {
              ...t,
              done: !t.done,
              status: !t.done ? 'done' : t.status === 'done' ? 'todo' : t.status,
            }
          : t
      )
    );

  const update = (id, patchOrText) =>
    setTodos((xs) =>
      xs.map((t) => {
        if (t.id !== id) return t;
        if (typeof patchOrText === 'string') return { ...t, text: patchOrText };
        const next = { ...t, ...patchOrText };
        if (Object.prototype.hasOwnProperty.call(patchOrText, 'status')) {
          next.done = next.status === 'done';
        }
        return next;
      })
    );

  const remove = (id) => setTodos((xs) => xs.filter((t) => t.id !== id));

  return (
    <div className="container">
      <h1>Todo List</h1>
      <div className="card">
        <TodoForm onAdd={add} />
        <div className="space" />
        <TodoList todos={todos} onToggle={toggle} onDelete={remove} onUpdate={update} />
        <div className="space" />
      </div>
    </div>
  );
}
