import React, { useState } from 'react';

function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const STATUS_OPTIONS = [
  { value: 'not-started', label: 'Not started' },
  { value: 'in-progress', label: 'In progress' },
  { value: 'under-review', label: 'Under review' },
  { value: 'blocked', label: 'Blocked' },
];

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'urgent', label: 'Urgent' },
];

function TodoForm({ onAdd }) {
  const [text, setText] = useState('');
  const [status, setStatus] = useState(STATUS_OPTIONS[0].value);
  const [priority, setPriority] = useState(PRIORITY_OPTIONS[1].value);
  const [dueDate, setDueDate] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    onAdd(value, { status, priority, dueDate });
    setText('');
    setStatus(STATUS_OPTIONS[0].value);
    setPriority(PRIORITY_OPTIONS[1].value);
    setDueDate('');
  };

  return (
    <form onSubmit={submit} className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
      <label htmlFor="new-todo" className="visually-hidden">New todo</label>
      <input
        id="new-todo"
        type="text"
        placeholder="Add a task..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label="Add a task"
      />
      <label htmlFor="status" className="visually-hidden">Status</label>
      <select id="status" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
        {STATUS_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      <label htmlFor="priority" className="visually-hidden">Priority</label>
      <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Priority">
        {PRIORITY_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      <label htmlFor="due" className="visually-hidden">Due date</label>
      <input id="due" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} aria-label="Due date" />
      <button type="submit" className="primary">Add</button>
    </form>
  );
}

function TodoItem({ todo, onToggle, onDelete, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(todo.text);

  const save = () => {
    const value = draft.trim();
    if (!value) return; // do not save empty
    if (value !== todo.text) onUpdate(todo.id, value);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(todo.text);
    setEditing(false);
  };

  return (
    <li className="todo-item">
      <input
        id={`chk-${todo.id}`}
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo.id)}
        aria-label={todo.done ? 'Mark as not done' : 'Mark as done'}
      />
      {editing ? (
        <input
          className="todo-text"
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') save();
            if (e.key === 'Escape') cancel();
          }}
          autoFocus
        />
      ) : (
        <label
          className={`todo-text ${todo.done ? 'done' : ''}`}
          htmlFor={`chk-${todo.id}`}
        >
          {todo.text}
        </label>
      )}
      <div className="row" style={{ gap: 8 }}>
        <label htmlFor={`status-${todo.id}`} className="visually-hidden">Status</label>
        <select
          id={`status-${todo.id}`}
          value={todo.status || STATUS_OPTIONS[0].value}
          onChange={(e) => onUpdate(todo.id, { status: e.target.value })}
          aria-label="Status"
        >
          {STATUS_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <label htmlFor={`priority-${todo.id}`} className="visually-hidden">Priority</label>
        <select
          id={`priority-${todo.id}`}
          value={todo.priority || PRIORITY_OPTIONS[1].value}
          onChange={(e) => onUpdate(todo.id, { priority: e.target.value })}
          aria-label="Priority"
        >
          {PRIORITY_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <label htmlFor={`due-${todo.id}`} className="visually-hidden">Due date</label>
        <input
          id={`due-${todo.id}`}
          type="date"
          value={todo.dueDate || ''}
          onChange={(e) => onUpdate(todo.id, { dueDate: e.target.value })}
          aria-label="Due date"
        />
      </div>
      <div className="actions">
        {editing ? (
          <>
            <button onClick={save} className="primary" aria-label="Save">Save</button>
            <button onClick={cancel} aria-label="Cancel">Cancel</button>
          </>
        ) : (
          <>
            <button onClick={() => setEditing(true)} aria-label="Edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} aria-label="Delete">Delete</button>
          </>
        )}
      </div>
    </li>
  );
}

function TodoList({ todos, onToggle, onDelete, onUpdate }) {
  if (!todos.length) return <p className="muted">No tasks yet. Add one above.</p>;
  return (
    <ul>
      {todos.map((t) => (
        <TodoItem
          key={t.id}
          todo={t}
          onToggle={onToggle}
          onDelete={onDelete}
          onUpdate={onUpdate}
        />
      ))}
    </ul>
  );
}

export default function App() {
  const [todos, setTodos] = useState([]);

  const add = (text, { status, priority, dueDate } = {}) =>
    setTodos((xs) => [
      {
        id: uid(),
        text,
        done: false,
        status: status || STATUS_OPTIONS[0].value,
        priority: priority || PRIORITY_OPTIONS[1].value,
        dueDate: dueDate || '',
      },
      ...xs,
    ]);
  const toggle = (id) => setTodos((xs) => xs.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const update = (id, data) =>
    setTodos((xs) =>
      xs.map((t) =>
        t.id === id
          ? typeof data === 'string'
            ? { ...t, text: data }
            : { ...t, ...data }
          : t
      )
    );
  const remove = (id) => setTodos((xs) => xs.filter((t) => t.id !== id));

  return (
    <div className="container">
      <h1>Todo List</h1>
      <div className="card">
        <TodoForm onAdd={add} />
        <div className="space" />
        <TodoList todos={todos} onToggle={toggle} onDelete={remove} onUpdate={update} />
        <div className="space" />
      </div>
    </div>
  );
}
