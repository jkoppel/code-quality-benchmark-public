import React, { useState } from 'react';

function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function TodoForm({ onAdd }) {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState('medium');
  const [dueDate, setDueDate] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    onAdd(value, priority, dueDate);
    setText('');
    setPriority('medium');
    setDueDate('');
  };

  return (
    <form onSubmit={submit} className="todo-form">
      <div className="row">
        <label htmlFor="new-todo" className="visually-hidden">New todo</label>
        <input
          id="new-todo"
          type="text"
          placeholder="Add a task..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          aria-label="Add a task"
        />
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          aria-label="Priority"
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          aria-label="Due date"
        />
        <button type="submit" className="primary">Add</button>
      </div>
    </form>
  );
}

function TodoItem({ todo, onToggle, onDelete, onUpdate, onStatusChange }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(todo.text);
  const [draftPriority, setDraftPriority] = useState(todo.priority);
  const [draftDueDate, setDraftDueDate] = useState(todo.dueDate || '');

  const save = () => {
    const value = draft.trim();
    if (!value) return; // do not save empty
    onUpdate(todo.id, { text: value, priority: draftPriority, dueDate: draftDueDate });
    setEditing(false);
  };

  const cancel = () => {
    setDraft(todo.text);
    setDraftPriority(todo.priority);
    setDraftDueDate(todo.dueDate || '');
    setEditing(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'done': return 'status-done';
      case 'in-progress': return 'status-progress';
      case 'under-review': return 'status-review';
      case 'blocked': return 'status-blocked';
      default: return '';
    }
  };

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'high': return '🔴';
      case 'medium': return '🟡';
      case 'low': return '🟢';
      default: return '';
    }
  };

  const formatDueDate = (date) => {
    if (!date) return '';
    const d = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDay = new Date(d);
    dueDay.setHours(0, 0, 0, 0);
    
    const diffTime = dueDay - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return '⚠️ Overdue';
    if (diffDays === 0) return '📅 Today';
    if (diffDays === 1) return '📅 Tomorrow';
    return `📅 ${d.toLocaleDateString()}`;
  };

  return (
    <li className={`todo-item ${getStatusColor(todo.status)}`}>
      <select
        value={todo.status}
        onChange={(e) => onStatusChange(todo.id, e.target.value)}
        className="status-select"
        aria-label="Status"
      >
        <option value="pending">Pending</option>
        <option value="in-progress">In Progress</option>
        <option value="under-review">Under Review</option>
        <option value="blocked">Blocked</option>
        <option value="done">Done</option>
      </select>
      {editing ? (
        <>
          <input
            className="todo-text"
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') save();
              if (e.key === 'Escape') cancel();
            }}
            autoFocus
          />
          <select
            value={draftPriority}
            onChange={(e) => setDraftPriority(e.target.value)}
            aria-label="Priority"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            value={draftDueDate}
            onChange={(e) => setDraftDueDate(e.target.value)}
            aria-label="Due date"
          />
        </>
      ) : (
        <>
          <span className="priority-badge">{getPriorityBadge(todo.priority)}</span>
          <label
            className={`todo-text ${todo.status === 'done' ? 'done' : ''}`}
          >
            {todo.text}
          </label>
          <span className="due-date">{formatDueDate(todo.dueDate)}</span>
        </>
      )}
      <div className="actions">
        {editing ? (
          <>
            <button onClick={save} className="primary" aria-label="Save">Save</button>
            <button onClick={cancel} aria-label="Cancel">Cancel</button>
          </>
        ) : (
          <>
            <button onClick={() => setEditing(true)} aria-label="Edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} aria-label="Delete">Delete</button>
          </>
        )}
      </div>
    </li>
  );
}

function TodoList({ todos, onToggle, onDelete, onUpdate, onStatusChange }) {
  if (!todos.length) return <p className="muted">No tasks yet. Add one above.</p>;
  return (
    <ul>
      {todos.map((t) => (
        <TodoItem
          key={t.id}
          todo={t}
          onToggle={onToggle}
          onDelete={onDelete}
          onUpdate={onUpdate}
          onStatusChange={onStatusChange}
        />
      ))}
    </ul>
  );
}

export default function App() {
  const [todos, setTodos] = useState([]);

  const add = (text, priority, dueDate) => setTodos((xs) => [{ 
    id: uid(), 
    text, 
    status: 'pending',
    priority: priority || 'medium',
    dueDate: dueDate || null
  }, ...xs]);
  
  const toggle = (id) => setTodos((xs) => xs.map((t) => (t.id === id ? { 
    ...t, 
    status: t.status === 'done' ? 'pending' : 'done' 
  } : t)));
  
  const update = (id, updates) => setTodos((xs) => xs.map((t) => (t.id === id ? { 
    ...t, 
    text: updates.text,
    priority: updates.priority,
    dueDate: updates.dueDate
  } : t)));
  
  const statusChange = (id, newStatus) => setTodos((xs) => xs.map((t) => (t.id === id ? { 
    ...t, 
    status: newStatus 
  } : t)));
  
  const remove = (id) => setTodos((xs) => xs.filter((t) => t.id !== id));

  return (
    <div className="container">
      <h1>Todo List</h1>
      <div className="card">
        <TodoForm onAdd={add} />
        <div className="space" />
        <TodoList 
          todos={todos} 
          onToggle={toggle} 
          onDelete={remove} 
          onUpdate={update}
          onStatusChange={statusChange}
        />
        <div className="space" />
      </div>
    </div>
  );
}
