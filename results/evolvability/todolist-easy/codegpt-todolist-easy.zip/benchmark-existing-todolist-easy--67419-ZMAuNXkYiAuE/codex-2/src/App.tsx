import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: 'not-started' | 'in-progress' | 'under-review' | 'blocked';
  priority: 'low' | 'medium' | 'high';
  dueDate?: string; // ISO date
}

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [nextId, setNextId] = useState(1);
  const [status, setStatus] = useState<
    'not-started' | 'in-progress' | 'under-review' | 'blocked'
  >('not-started');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [dueDate, setDueDate] = useState<string>('');

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([
        ...todos,
        {
          id: nextId,
          text: inputText,
          done: false,
          status,
          priority,
          dueDate: dueDate || undefined,
        },
      ]);
      setNextId(nextId + 1);
      setInputText('');
      setStatus('not-started');
      setPriority('medium');
      setDueDate('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, done: !todo.done } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <select
            aria-label="Status"
            value={status}
            onChange={(e) =>
              setStatus(e.target.value as 'not-started' | 'in-progress' | 'under-review' | 'blocked')
            }
            className="task-input"
          >
            <option value="not-started">Not started</option>
            <option value="in-progress">In progress</option>
            <option value="under-review">Under review</option>
            <option value="blocked">Blocked</option>
          </select>
          <select
            aria-label="Priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high')}
            className="task-input"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            aria-label="Due date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="task-input"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
        />
      </div>
    </div>
  );
}

export default App;
