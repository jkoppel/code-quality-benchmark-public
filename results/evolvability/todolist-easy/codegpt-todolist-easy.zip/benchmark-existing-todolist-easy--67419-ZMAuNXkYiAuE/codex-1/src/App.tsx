import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';

type TodoStatus =
  | 'not-started'
  | 'in-progress'
  | 'under-review'
  | 'blocked'
  | 'done';

type TodoPriority = 'low' | 'medium' | 'high';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string; // ISO date (YYYY-MM-DD)
}

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [status, setStatus] = useState<TodoStatus>('not-started');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState<string>('');
  const [nextId, setNextId] = useState(1);

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([
        ...todos,
        {
          id: nextId,
          text: inputText,
          done: status === 'done',
          status,
          priority,
          dueDate: dueDate || undefined,
        },
      ]);
      setNextId(nextId + 1);
      setInputText('');
      setStatus('not-started');
      setPriority('medium');
      setDueDate('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id
          ? {
              ...todo,
              done: !todo.done,
              status: !todo.done ? 'done' : 'not-started',
            }
          : todo
      )
    );
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  const changeStatus = (id: number, newStatus: TodoStatus) => {
    setTodos((prev) =>
      prev.map((todo) =>
        todo.id === id
          ? {
              ...todo,
              status: newStatus,
              done: newStatus === 'done',
            }
          : todo
      )
    );
  };

  const changePriority = (id: number, newPriority: TodoPriority) => {
    setTodos((prev) =>
      prev.map((todo) => (todo.id === id ? { ...todo, priority: newPriority } : todo))
    );
  };

  const changeDueDate = (id: number, newDueDate?: string) => {
    setTodos((prev) =>
      prev.map((todo) =>
        todo.id === id ? { ...todo, dueDate: newDueDate || undefined } : todo
      )
    );
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <select
            aria-label="Select status"
            value={status}
            onChange={(e) => setStatus(e.target.value as TodoStatus)}
            className="task-input"
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
          <select
            aria-label="Select priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value as TodoPriority)}
            className="task-input"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            aria-label="Select due date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="task-input"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onChangeStatus={changeStatus}
          onChangePriority={changePriority}
          onChangeDueDate={changeDueDate}
        />
      </div>
    </div>
  );
}

export default App;
