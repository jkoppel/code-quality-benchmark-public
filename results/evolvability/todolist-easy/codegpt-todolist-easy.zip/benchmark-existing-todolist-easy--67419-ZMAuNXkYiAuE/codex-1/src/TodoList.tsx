import React from 'react';
import TodoItem from './TodoItem';

type TodoStatus =
  | 'not-started'
  | 'in-progress'
  | 'under-review'
  | 'blocked'
  | 'done';

type TodoPriority = 'low' | 'medium' | 'high';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string;
}

interface TodoListProps {
  todos: Todo[];
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onChangeStatus: (id: number, status: TodoStatus) => void;
  onChangePriority: (id: number, priority: TodoPriority) => void;
  onChangeDueDate: (id: number, dueDate?: string) => void;
}

const TodoList: React.FC<TodoListProps> = ({
  todos,
  onToggleDone,
  onDelete,
  onEdit,
  onChangeStatus,
  onChangePriority,
  onChangeDueDate,
}) => {
  return (
    <ul className="todo-list">
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggleDone={onToggleDone}
          onDelete={onDelete}
          onEdit={onEdit}
          onChangeStatus={onChangeStatus}
          onChangePriority={onChangePriority}
          onChangeDueDate={onChangeDueDate}
        />
      ))}
    </ul>
  );
};

export default TodoList;
