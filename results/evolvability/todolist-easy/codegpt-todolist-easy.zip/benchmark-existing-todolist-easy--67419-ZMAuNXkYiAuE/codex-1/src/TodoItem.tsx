import React, { useState } from 'react';

type TodoStatus =
  | 'not-started'
  | 'in-progress'
  | 'under-review'
  | 'blocked'
  | 'done';

type TodoPriority = 'low' | 'medium' | 'high';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string;
}

interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onChangeStatus: (id: number, status: TodoStatus) => void;
  onChangePriority: (id: number, priority: TodoPriority) => void;
  onChangeDueDate: (id: number, dueDate?: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({
  todo,
  onToggleDone,
  onDelete,
  onEdit,
  onChangeStatus,
  onChangePriority,
  onChangeDueDate,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);
  const [localStatus, setLocalStatus] = useState<TodoStatus>(todo.status);
  const [localPriority, setLocalPriority] = useState<TodoPriority>(todo.priority);
  const [localDueDate, setLocalDueDate] = useState<string>(todo.dueDate || '');

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      if (localStatus !== todo.status) {
        onChangeStatus(todo.id, localStatus);
      }
      if (localPriority !== todo.priority) {
        onChangePriority(todo.id, localPriority);
      }
      if ((todo.dueDate || '') !== localDueDate) {
        onChangeDueDate(todo.id, localDueDate || undefined);
      }
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setLocalStatus(todo.status);
    setLocalPriority(todo.priority);
    setLocalDueDate(todo.dueDate || '');
    setIsEditing(false);
  };

  return (
    <li className="todo-item">
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggleDone(todo.id)}
        className="todo-checkbox"
      />
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSave()}
            className="todo-edit-input"
          />
          <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
            <select
              aria-label="Change status"
              value={localStatus}
              onChange={(e) => setLocalStatus(e.target.value as TodoStatus)}
            >
              <option value="not-started">Not Started</option>
              <option value="in-progress">In Progress</option>
              <option value="under-review">Under Review</option>
              <option value="blocked">Blocked</option>
              <option value="done">Done</option>
            </select>
            <select
              aria-label="Change priority"
              value={localPriority}
              onChange={(e) => setLocalPriority(e.target.value as TodoPriority)}
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
            <input
              type="date"
              aria-label="Change due date"
              value={localDueDate}
              onChange={(e) => setLocalDueDate(e.target.value)}
            />
          </div>
          <button onClick={handleSave} className="todo-button save">Save</button>
          <button onClick={handleCancel} className="todo-button cancel">Cancel</button>
        </>
      ) : (
        <>
          <span
            className={`todo-text ${todo.done ? 'completed' : ''}`}
            onClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
          <div className="todo-meta" style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <label>
              Status:
              <select
                aria-label="Status"
                value={todo.status}
                onChange={(e) => onChangeStatus(todo.id, e.target.value as TodoStatus)}
              >
                <option value="not-started">Not Started</option>
                <option value="in-progress">In Progress</option>
                <option value="under-review">Under Review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
            </label>
            <label>
              Priority:
              <select
                aria-label="Priority"
                value={todo.priority}
                onChange={(e) => onChangePriority(todo.id, e.target.value as TodoPriority)}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </label>
            <label>
              Due:
              <input
                type="date"
                aria-label="Due date"
                value={todo.dueDate || ''}
                onChange={(e) => onChangeDueDate(todo.id, e.target.value)}
              />
            </label>
          </div>
          <button onClick={() => setIsEditing(true)} className="todo-button edit">Edit</button>
          <button onClick={() => onDelete(todo.id)} className="todo-button delete">Delete</button>
        </>
      )}
    </li>
  );
};

export default TodoItem;
