import React, { useState } from 'react';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: string;
  priority: string;
  dueDate?: string;
}

interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: string) => void;
  onUpdatePriority: (id: number, priority: string) => void;
  onUpdateDueDate: (id: number, dueDate: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggleDone, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <li className="todo-item">
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggleDone(todo.id)}
        className="todo-checkbox"
      />
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSave()}
            className="todo-edit-input"
          />
          <select
            aria-label="Update status"
            value={todo.status}
            onChange={(e) => onUpdateStatus(todo.id, e.target.value)}
            className="todo-button edit"
          >
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="not-started">Not Started</option>
          </select>
          <select
            aria-label="Update priority"
            value={todo.priority}
            onChange={(e) => onUpdatePriority(todo.id, e.target.value)}
            className="todo-button edit"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            aria-label="Update due date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value)}
            className="todo-edit-input"
          />
          <button onClick={handleSave} className="todo-button save">Save</button>
          <button onClick={handleCancel} className="todo-button cancel">Cancel</button>
        </>
      ) : (
        <>
          <span
            className={`todo-text ${todo.done ? 'completed' : ''}`}
            onClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
          <span className="todo-text" style={{ flex: '0 0 auto' }}>
            Status: {todo.status} | Priority: {todo.priority}
            {todo.dueDate ? ` | Due: ${todo.dueDate}` : ''}
          </span>
          <select
            aria-label="Update status"
            value={todo.status}
            onChange={(e) => onUpdateStatus(todo.id, e.target.value)}
            className="todo-button edit"
          >
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="not-started">Not Started</option>
          </select>
          <select
            aria-label="Update priority"
            value={todo.priority}
            onChange={(e) => onUpdatePriority(todo.id, e.target.value)}
            className="todo-button edit"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            aria-label="Update due date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value)}
            className="todo-edit-input"
          />
          <button onClick={() => setIsEditing(true)} className="todo-button edit">Edit</button>
          <button onClick={() => onDelete(todo.id)} className="todo-button delete">Delete</button>
        </>
      )}
    </li>
  );
};

export default TodoItem;
