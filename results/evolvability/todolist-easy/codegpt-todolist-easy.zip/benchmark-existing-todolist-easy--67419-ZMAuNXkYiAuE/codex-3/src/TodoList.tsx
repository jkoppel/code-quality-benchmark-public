import React from 'react';
import TodoItem from './TodoItem';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: string;
  priority: string;
  dueDate?: string;
}

interface TodoListProps {
  todos: Todo[];
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: string) => void;
  onUpdatePriority: (id: number, priority: string) => void;
  onUpdateDueDate: (id: number, dueDate: string) => void;
}

const TodoList: React.FC<TodoListProps> = ({ todos, onToggleDone, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  return (
    <ul className="todo-list">
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggleDone={onToggleDone}
          onDelete={onDelete}
          onEdit={onEdit}
          onUpdateStatus={onUpdateStatus}
          onUpdatePriority={onUpdatePriority}
          onUpdateDueDate={onUpdateDueDate}
        />
      ))}
    </ul>
  );
};

export default TodoList;
