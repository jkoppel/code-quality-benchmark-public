import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: string; // e.g., in-progress, under-review, blocked
  priority: string; // e.g., low, medium, high
  dueDate?: string; // YYYY-MM-DD
}

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [nextId, setNextId] = useState(1);
  const [inputStatus, setInputStatus] = useState<string>('in-progress');
  const [inputPriority, setInputPriority] = useState<string>('medium');
  const [inputDueDate, setInputDueDate] = useState<string>('');

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([
        ...todos,
        {
          id: nextId,
          text: inputText,
          done: false,
          status: inputStatus,
          priority: inputPriority,
          dueDate: inputDueDate || undefined,
        },
      ]);
      setNextId(nextId + 1);
      setInputText('');
      setInputStatus('in-progress');
      setInputPriority('medium');
      setInputDueDate('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id
          ? {
              ...todo,
              done: !todo.done,
            }
          : todo
      )
    );
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  const updateStatus = (id: number, status: string) => {
    setTodos(
      todos.map((todo) => (todo.id === id ? { ...todo, status } : todo))
    );
  };

  const updatePriority = (id: number, priority: string) => {
    setTodos(
      todos.map((todo) => (todo.id === id ? { ...todo, priority } : todo))
    );
  };

  const updateDueDate = (id: number, dueDate: string) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, dueDate: dueDate || undefined } : todo
      )
    );
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <select
            aria-label="Select status"
            value={inputStatus}
            onChange={(e) => setInputStatus(e.target.value)}
            className="task-input"
          >
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="not-started">Not Started</option>
          </select>
          <select
            aria-label="Select priority"
            value={inputPriority}
            onChange={(e) => setInputPriority(e.target.value)}
            className="task-input"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <input
            type="date"
            aria-label="Select due date"
            value={inputDueDate}
            onChange={(e) => setInputDueDate(e.target.value)}
            className="task-input"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onUpdateStatus={updateStatus}
          onUpdatePriority={updatePriority}
          onUpdateDueDate={updateDueDate}
        />
      </div>
    </div>
  );
}

export default App;
