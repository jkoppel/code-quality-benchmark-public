import React, { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from './types/Todo';

interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: TodoStatus) => void;
  onUpdatePriority: (id: number, priority: TodoPriority) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggleDone, onDelete, onEdit, onUpdateStatus, onUpdatePriority }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString();
  };

  const getPriorityClass = (priority: TodoPriority) => {
    return `priority-${priority}`;
  };

  const getStatusClass = (status: TodoStatus) => {
    return `status-${status}`;
  };

  return (
    <li className={`todo-item ${getPriorityClass(todo.priority)} ${getStatusClass(todo.status)}`}>
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggleDone(todo.id)}
        className="todo-checkbox"
      />
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSave()}
            className="todo-edit-input"
          />
          <button onClick={handleSave} className="todo-button save">Save</button>
          <button onClick={handleCancel} className="todo-button cancel">Cancel</button>
        </>
      ) : (
        <>
          <div className="todo-content">
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <div className="todo-meta">
              <select
                value={todo.status}
                onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
                className="status-select"
              >
                <option value="not-started">Not Started</option>
                <option value="in-progress">In Progress</option>
                <option value="under-review">Under Review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
              <select
                value={todo.priority}
                onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
                className="priority-select-item"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
              {todo.dueDate && (
                <span className="due-date">Due: {formatDate(todo.dueDate)}</span>
              )}
            </div>
          </div>
          <div className="todo-actions">
            <button onClick={() => setIsEditing(true)} className="todo-button edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} className="todo-button delete">Delete</button>
          </div>
        </>
      )}
    </li>
  );
};

export default TodoItem;