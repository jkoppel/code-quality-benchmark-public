import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';
import { Todo, TodoStatus, TodoPriority } from './types/Todo';

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [inputPriority, setInputPriority] = useState<TodoPriority>('medium');
  const [inputDueDate, setInputDueDate] = useState('');
  const [nextId, setNextId] = useState(1);

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([...todos, { 
        id: nextId, 
        text: inputText, 
        done: false,
        status: 'not-started',
        priority: inputPriority,
        dueDate: inputDueDate || undefined
      }]);
      setNextId(nextId + 1);
      setInputText('');
      setInputDueDate('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        done: !todo.done,
        status: !todo.done ? 'done' : 'not-started'
      } : todo
    ));
  };

  const updateStatus = (id: number, status: TodoStatus) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        status,
        done: status === 'done'
      } : todo
    ));
  };

  const updatePriority = (id: number, priority: TodoPriority) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, priority } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <select
            value={inputPriority}
            onChange={(e) => setInputPriority(e.target.value as TodoPriority)}
            className="priority-select"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
          <input
            type="date"
            value={inputDueDate}
            onChange={(e) => setInputDueDate(e.target.value)}
            className="date-input"
            placeholder="Due date (optional)"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onUpdateStatus={updateStatus}
          onUpdatePriority={updatePriority}
        />
      </div>
    </div>
  );
}

export default App;
