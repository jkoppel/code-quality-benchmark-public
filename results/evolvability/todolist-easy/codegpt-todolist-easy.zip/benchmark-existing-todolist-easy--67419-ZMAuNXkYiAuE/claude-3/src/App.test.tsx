import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders todo list app', () => {
  render(<App />);
  const titleElement = screen.getByText('Todo List');
  expect(titleElement).toBeInTheDocument();
  
  const inputElement = screen.getByPlaceholderText('Enter a new task');
  expect(inputElement).toBeInTheDocument();
  
  const addButton = screen.getByText('Add Todo');
  expect(addButton).toBeInTheDocument();
});
