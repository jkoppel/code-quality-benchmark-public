import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';

import { Todo, TodoStatus, TodoPriority } from './types/Todo';

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState('');
  const [nextId, setNextId] = useState(1);

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([...todos, { 
        id: nextId, 
        text: inputText, 
        done: false,
        status: 'todo' as TodoStatus,
        priority: priority,
        dueDate: dueDate || undefined
      }]);
      setNextId(nextId + 1);
      setInputText('');
      setPriority('medium');
      setDueDate('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        done: !todo.done,
        status: !todo.done ? 'done' as TodoStatus : 'todo' as TodoStatus
      } : todo
    ));
  };

  const updateStatus = (id: number, newStatus: TodoStatus) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        status: newStatus,
        done: newStatus === 'done'
      } : todo
    ));
  };

  const updatePriority = (id: number, newPriority: TodoPriority) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, priority: newPriority } : todo
    ));
  };

  const updateDueDate = (id: number, newDueDate?: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, dueDate: newDueDate } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <select 
            value={priority} 
            onChange={(e) => setPriority(e.target.value as TodoPriority)}
            className="priority-select"
          >
            <option value="low">Low Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="high">High Priority</option>
          </select>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="due-date-input"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onUpdateStatus={updateStatus}
          onUpdatePriority={updatePriority}
          onUpdateDueDate={updateDueDate}
        />
      </div>
    </div>
  );
}

export default App;
