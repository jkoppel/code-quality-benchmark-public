import React, { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from './types/Todo';

interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, newStatus: TodoStatus) => void;
  onUpdatePriority: (id: number, newPriority: TodoPriority) => void;
  onUpdateDueDate: (id: number, newDueDate?: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggleDone, 
  onDelete, 
  onEdit, 
  onUpdateStatus, 
  onUpdatePriority, 
  onUpdateDueDate 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const formatDate = (dateString?: string) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString();
  };

  const getPriorityColor = (priority: TodoPriority) => {
    switch (priority) {
      case 'high': return '#ff4444';
      case 'medium': return '#ffaa00';
      case 'low': return '#44ff44';
      default: return '#cccccc';
    }
  };

  const getStatusColor = (status: TodoStatus) => {
    switch (status) {
      case 'todo': return '#cccccc';
      case 'in-progress': return '#3498db';
      case 'under-review': return '#f39c12';
      case 'blocked': return '#e74c3c';
      case 'done': return '#27ae60';
      default: return '#cccccc';
    }
  };

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <li className="todo-item">
      <div className="todo-main-row">
        <input
          type="checkbox"
          checked={todo.done}
          onChange={() => onToggleDone(todo.id)}
          className="todo-checkbox"
        />
        {isEditing ? (
          <>
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSave()}
              className="todo-edit-input"
            />
            <button onClick={handleSave} className="todo-button save">Save</button>
            <button onClick={handleCancel} className="todo-button cancel">Cancel</button>
          </>
        ) : (
          <>
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <div className="todo-meta">
              <span className="priority-badge" style={{ backgroundColor: getPriorityColor(todo.priority) }}>
                {todo.priority.toUpperCase()}
              </span>
              {todo.dueDate && (
                <span className="due-date">Due: {formatDate(todo.dueDate)}</span>
              )}
            </div>
            <button onClick={() => setIsEditing(true)} className="todo-button edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} className="todo-button delete">Delete</button>
          </>
        )}
      </div>
      <div className="todo-controls">
        <div className="status-controls">
          <label>Status:</label>
          <select 
            value={todo.status} 
            onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
            className="status-select"
            style={{ borderColor: getStatusColor(todo.status) }}
          >
            <option value="todo">Todo</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
        </div>
        <div className="priority-controls">
          <label>Priority:</label>
          <select 
            value={todo.priority} 
            onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
            className="priority-select"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div className="due-date-controls">
          <label>Due Date:</label>
          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value || undefined)}
            className="due-date-input"
          />
        </div>
      </div>
    </li>
  );
};

export default TodoItem;