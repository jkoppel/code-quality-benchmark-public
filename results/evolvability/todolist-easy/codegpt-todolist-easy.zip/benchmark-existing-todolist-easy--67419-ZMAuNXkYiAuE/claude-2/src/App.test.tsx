import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders todo list app', () => {
  render(<App />);
  const titleElement = screen.getByText(/todo list/i);
  expect(titleElement).toBeInTheDocument();
  const addButton = screen.getByText(/add todo/i);
  expect(addButton).toBeInTheDocument();
});
