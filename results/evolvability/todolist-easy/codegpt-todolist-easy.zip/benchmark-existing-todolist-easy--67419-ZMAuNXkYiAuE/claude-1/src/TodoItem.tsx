import React, { useState } from 'react';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'done';
  priority: 'low' | 'medium' | 'high';
  dueDate?: Date;
}

interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: Todo['status']) => void;
  onUpdatePriority: (id: number, priority: Todo['priority']) => void;
  onUpdateDueDate: (id: number, dueDate?: Date) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggleDone, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const getStatusColor = (status: Todo['status']): string => {
    switch (status) {
      case 'not-started': return '#888';
      case 'in-progress': return '#007bff';
      case 'under-review': return '#ffc107';
      case 'blocked': return '#dc3545';
      case 'done': return '#28a745';
      default: return '#888';
    }
  };

  const getPriorityColor = (priority: Todo['priority']): string => {
    switch (priority) {
      case 'low': return '#28a745';
      case 'medium': return '#ffc107';
      case 'high': return '#dc3545';
      default: return '#888';
    }
  };

  return (
    <li className="todo-item">
      <div className="todo-main">
        <input
          type="checkbox"
          checked={todo.done}
          onChange={() => onToggleDone(todo.id)}
          className="todo-checkbox"
        />
        {isEditing ? (
          <>
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSave()}
              className="todo-edit-input"
            />
            <button onClick={handleSave} className="todo-button save">Save</button>
            <button onClick={handleCancel} className="todo-button cancel">Cancel</button>
          </>
        ) : (
          <>
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <button onClick={() => setIsEditing(true)} className="todo-button edit">Edit</button>
            <button onClick={() => onDelete(todo.id)} className="todo-button delete">Delete</button>
          </>
        )}
      </div>
      <div className="todo-meta">
        <div className="todo-field">
          <label>Status:</label>
          <select 
            value={todo.status} 
            onChange={(e) => onUpdateStatus(todo.id, e.target.value as Todo['status'])}
            className="todo-select"
            style={{ borderColor: getStatusColor(todo.status) }}
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
        </div>
        <div className="todo-field">
          <label>Priority:</label>
          <select 
            value={todo.priority} 
            onChange={(e) => onUpdatePriority(todo.id, e.target.value as Todo['priority'])}
            className="todo-select"
            style={{ borderColor: getPriorityColor(todo.priority) }}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div className="todo-field">
          <label>Due Date:</label>
          <input
            type="date"
            value={todo.dueDate ? todo.dueDate.toISOString().split('T')[0] : ''}
            onChange={(e) => onUpdateDueDate(todo.id, e.target.value ? new Date(e.target.value) : undefined)}
            className="todo-date-input"
          />
        </div>
      </div>
    </li>
  );
};

export default TodoItem;