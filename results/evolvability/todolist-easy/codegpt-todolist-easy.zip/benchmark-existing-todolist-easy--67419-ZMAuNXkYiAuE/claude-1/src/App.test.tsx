import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders todo list app', () => {
  render(<App />);
  const titleElement = screen.getByText(/Todo List/i);
  expect(titleElement).toBeInTheDocument();
  
  const inputElement = screen.getByPlaceholderText(/Enter a new task/i);
  expect(inputElement).toBeInTheDocument();
  
  const addButtonElement = screen.getByText(/Add Todo/i);
  expect(addButtonElement).toBeInTheDocument();
});
