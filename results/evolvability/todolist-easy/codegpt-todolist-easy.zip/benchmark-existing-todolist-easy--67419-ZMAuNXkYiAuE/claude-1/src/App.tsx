import React, { useState } from 'react';
import TodoList from './TodoList';
import './App.css';

interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'done';
  priority: 'low' | 'medium' | 'high';
  dueDate?: Date;
}

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState('');
  const [nextId, setNextId] = useState(1);

  const addTodo = () => {
    if (inputText.trim()) {
      setTodos([...todos, { 
        id: nextId, 
        text: inputText, 
        done: false,
        status: 'not-started',
        priority: 'medium'
      }]);
      setNextId(nextId + 1);
      setInputText('');
    }
  };

  const toggleDone = (id: number) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        done: !todo.done,
        status: !todo.done ? 'done' : 'not-started'
      } : todo
    ));
  };

  const updateStatus = (id: number, status: Todo['status']) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { 
        ...todo, 
        status,
        done: status === 'done'
      } : todo
    ));
  };

  const updatePriority = (id: number, priority: Todo['priority']) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, priority } : todo
    ));
  };

  const updateDueDate = (id: number, dueDate?: Date) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, dueDate } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const editTodo = (id: number, newText: string) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, text: newText } : todo
    ));
  };

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <div className="input-container">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Enter a new task"
            className="task-input"
          />
          <button onClick={addTodo} className="add-button">Add Todo</button>
        </div>
        <TodoList
          todos={todos}
          onToggleDone={toggleDone}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onUpdateStatus={updateStatus}
          onUpdatePriority={updatePriority}
          onUpdateDueDate={updateDueDate}
        />
      </div>
    </div>
  );
}

export default App;
