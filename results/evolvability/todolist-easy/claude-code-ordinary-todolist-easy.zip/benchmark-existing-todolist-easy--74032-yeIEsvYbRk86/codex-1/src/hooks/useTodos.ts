import { useState } from 'react';
import { Todo, TodoMetadata, TodoPriority, TodoStatus } from '../types';
import { createTodo, toggleTodoCompletion, updateTodoText, removeTodo, updateTodoById, isValidTodoText } from '../utils';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [nextId, setNextId] = useState(1);
  const [metadataById, setMetadataById] = useState<Record<number, TodoMetadata>>({});

  const addTodo = (text: string) => {
    if (isValidTodoText(text)) {
      setTodos(prevTodos => [...prevTodos, createTodo(nextId, text)]);
      // initialize default metadata for the new todo
      setMetadataById(prev => ({
        ...prev,
        [nextId]: {
          status: 'not_started',
          priority: 'medium',
          dueDate: undefined,
        },
      }));
      setNextId(prevId => prevId + 1);
      return true;
    }
    return false;
  };

  const toggleTodo = (id: number) => {
    setTodos(prevTodos => updateTodoById(prevTodos, id, toggleTodoCompletion));
  };

  const deleteTodo = (id: number) => {
    setTodos(prevTodos => removeTodo(prevTodos, id));
  };

  const editTodo = (id: number, newText: string) => {
    if (isValidTodoText(newText)) {
      setTodos(prevTodos => 
        updateTodoById(prevTodos, id, todo => updateTodoText(todo, newText))
      );
      return true;
    }
    return false;
  };

  const updateStatus = (id: number, status: TodoStatus) => {
    setMetadataById(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] ?? { status: 'not_started', priority: 'medium', dueDate: undefined }),
        status,
      },
    }));
  };

  const updatePriority = (id: number, priority: TodoPriority) => {
    setMetadataById(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] ?? { status: 'not_started', priority: 'medium', dueDate: undefined }),
        priority,
      },
    }));
  };

  const updateDueDate = (id: number, dueDate?: string) => {
    setMetadataById(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] ?? { status: 'not_started', priority: 'medium', dueDate: undefined }),
        dueDate,
      },
    }));
  };

  const getMetadata = (id: number): TodoMetadata | undefined => metadataById[id];

  return {
    todos,
    addTodo,
    toggleTodo,
    deleteTodo,
    editTodo,
    // extended metadata management
    getMetadata,
    updateStatus,
    updatePriority,
    updateDueDate,
  };
};
