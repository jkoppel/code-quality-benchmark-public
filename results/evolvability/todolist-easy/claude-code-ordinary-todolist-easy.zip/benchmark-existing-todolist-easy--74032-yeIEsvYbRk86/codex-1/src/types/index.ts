export interface Todo {
  id: number;
  text: string;
  done: boolean;
}

export type TodoStatus = 'not_started' | 'in_progress' | 'under_review' | 'blocked';
export type TodoPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface TodoMetadata {
  status: TodoStatus;
  priority: TodoPriority;
  /** ISO date string (YYYY-MM-DD) */
  dueDate?: string;
}

export interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  getMetadata?: (id: number) => TodoMetadata | undefined;
  onUpdateStatus?: (id: number, status: TodoStatus) => void;
  onUpdatePriority?: (id: number, priority: TodoPriority) => void;
  onUpdateDueDate?: (id: number, dueDate?: string) => void;
}

export interface TodoListProps {
  todos: Todo[];
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  getMetadata?: (id: number) => TodoMetadata | undefined;
  onUpdateStatus?: (id: number, status: TodoStatus) => void;
  onUpdatePriority?: (id: number, priority: TodoPriority) => void;
  onUpdateDueDate?: (id: number, dueDate?: string) => void;
}
