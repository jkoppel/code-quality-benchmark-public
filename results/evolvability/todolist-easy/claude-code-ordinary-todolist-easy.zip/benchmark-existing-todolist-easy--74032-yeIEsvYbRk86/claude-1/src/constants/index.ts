// UI Text Constants
export const UI_TEXT = {
  APP_TITLE: 'Todo List',
  INPUT_PLACEHOLDER: 'Enter a new task',
  ADD_BUTTON: 'Add Todo',
  EDIT_BUTTON: 'Edit',
  DELETE_BUTTON: 'Delete',
  SAVE_BUTTON: 'Save',
  CANCEL_BUTTON: 'Cancel',
  STATUS_LABEL: 'Status:',
  PRIORITY_LABEL: 'Priority:',
  DUE_DATE_LABEL: 'Due Date:',
  CLEAR_DATE_BUTTON: 'Clear',
} as const;

// Key Constants
export const KEYS = {
  ENTER: 'Enter',
} as const;

// CSS Classes
export const CSS_CLASSES = {
  APP: 'App',
  APP_CONTAINER: 'app-container',
  APP_TITLE: 'app-title',
  INPUT_CONTAINER: 'input-container',
  TASK_INPUT: 'task-input',
  ADD_BUTTON: 'add-button',
  TODO_LIST: 'todo-list',
  TODO_ITEM: 'todo-item',
  TODO_CHECKBOX: 'todo-checkbox',
  TODO_TEXT: 'todo-text',
  TODO_TEXT_COMPLETED: 'completed',
  TODO_EDIT_INPUT: 'todo-edit-input',
  TODO_BUTTON: 'todo-button',
  TODO_CONTROLS: 'todo-controls',
  TODO_CONTROL_GROUP: 'todo-control-group',
  TODO_SELECT: 'todo-select',
  TODO_DATE_INPUT: 'todo-date-input',
  PRIORITY_LOW: 'priority-low',
  PRIORITY_MEDIUM: 'priority-medium',
  PRIORITY_HIGH: 'priority-high',
  PRIORITY_URGENT: 'priority-urgent',
  STATUS_NOT_STARTED: 'status-not-started',
  STATUS_IN_PROGRESS: 'status-in-progress',
  STATUS_UNDER_REVIEW: 'status-under-review',
  STATUS_BLOCKED: 'status-blocked',
  STATUS_DONE: 'status-done',
} as const;