import React, { useState } from 'react';
import Button from './components/Button';
import { TodoItemProps, TodoStatus, TodoPriority } from './types';
import { UI_TEXT, CSS_CLASSES, KEYS } from './constants';
import './styles/TodoItem.css';

const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggleDone, 
  onDelete, 
  onEdit, 
  onStatusChange, 
  onPriorityChange, 
  onDueDateChange 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const formatDate = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onDueDateChange(todo.id, value ? new Date(value) : undefined);
  };

  const getPriorityClass = (priority: TodoPriority) => {
    switch (priority) {
      case 'low': return CSS_CLASSES.PRIORITY_LOW;
      case 'medium': return CSS_CLASSES.PRIORITY_MEDIUM;
      case 'high': return CSS_CLASSES.PRIORITY_HIGH;
      case 'urgent': return CSS_CLASSES.PRIORITY_URGENT;
      default: return CSS_CLASSES.PRIORITY_MEDIUM;
    }
  };

  const getStatusClass = (status: TodoStatus) => {
    switch (status) {
      case 'not-started': return CSS_CLASSES.STATUS_NOT_STARTED;
      case 'in-progress': return CSS_CLASSES.STATUS_IN_PROGRESS;
      case 'under-review': return CSS_CLASSES.STATUS_UNDER_REVIEW;
      case 'blocked': return CSS_CLASSES.STATUS_BLOCKED;
      case 'done': return CSS_CLASSES.STATUS_DONE;
      default: return CSS_CLASSES.STATUS_NOT_STARTED;
    }
  };

  return (
    <li className={`${CSS_CLASSES.TODO_ITEM} ${getPriorityClass(todo.priority)} ${getStatusClass(todo.status)}`}>
      <div className={CSS_CLASSES.TODO_CONTROL_GROUP}>
        <input
          type="checkbox"
          checked={todo.done}
          onChange={() => onToggleDone(todo.id)}
          className={CSS_CLASSES.TODO_CHECKBOX}
        />
        {isEditing ? (
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => e.key === KEYS.ENTER && handleSave()}
            className={CSS_CLASSES.TODO_EDIT_INPUT}
          />
        ) : (
          <span
            className={`${CSS_CLASSES.TODO_TEXT} ${todo.done ? CSS_CLASSES.TODO_TEXT_COMPLETED : ''}`}
            onClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
        )}
      </div>

      <div className={CSS_CLASSES.TODO_CONTROLS}>
        <div className={CSS_CLASSES.TODO_CONTROL_GROUP}>
          <label>{UI_TEXT.STATUS_LABEL}</label>
          <select
            value={todo.status}
            onChange={(e) => onStatusChange(todo.id, e.target.value as TodoStatus)}
            className={CSS_CLASSES.TODO_SELECT}
          >
            <option value="not-started">Not Started</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
        </div>

        <div className={CSS_CLASSES.TODO_CONTROL_GROUP}>
          <label>{UI_TEXT.PRIORITY_LABEL}</label>
          <select
            value={todo.priority}
            onChange={(e) => onPriorityChange(todo.id, e.target.value as TodoPriority)}
            className={CSS_CLASSES.TODO_SELECT}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <div className={CSS_CLASSES.TODO_CONTROL_GROUP}>
          <label>{UI_TEXT.DUE_DATE_LABEL}</label>
          <input
            type="date"
            value={todo.dueDate ? formatDate(todo.dueDate) : ''}
            onChange={handleDateChange}
            className={CSS_CLASSES.TODO_DATE_INPUT}
          />
          {todo.dueDate && (
            <Button 
              onClick={() => onDueDateChange(todo.id, undefined)} 
              variant="cancel"
            >
              {UI_TEXT.CLEAR_DATE_BUTTON}
            </Button>
          )}
        </div>

        <div className={CSS_CLASSES.TODO_CONTROL_GROUP}>
          {isEditing ? (
            <>
              <Button onClick={handleSave} variant="save">{UI_TEXT.SAVE_BUTTON}</Button>
              <Button onClick={handleCancel} variant="cancel">{UI_TEXT.CANCEL_BUTTON}</Button>
            </>
          ) : (
            <>
              <Button onClick={() => setIsEditing(true)} variant="edit">{UI_TEXT.EDIT_BUTTON}</Button>
              <Button onClick={() => onDelete(todo.id)} variant="delete">{UI_TEXT.DELETE_BUTTON}</Button>
            </>
          )}
        </div>
      </div>
    </li>
  );
};

export default TodoItem;