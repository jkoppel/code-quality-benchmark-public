export type TodoStatus = 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'done';
export type TodoPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: Date;
}

export interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onStatusChange: (id: number, status: TodoStatus) => void;
  onPriorityChange: (id: number, priority: TodoPriority) => void;
  onDueDateChange: (id: number, dueDate: Date | undefined) => void;
}

export interface TodoListProps {
  todos: Todo[];
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onStatusChange: (id: number, status: TodoStatus) => void;
  onPriorityChange: (id: number, priority: TodoPriority) => void;
  onDueDateChange: (id: number, dueDate: Date | undefined) => void;
}