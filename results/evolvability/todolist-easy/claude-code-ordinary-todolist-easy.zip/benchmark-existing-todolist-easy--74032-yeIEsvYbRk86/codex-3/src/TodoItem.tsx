import React, { useState } from 'react';
import Button from './components/Button';
import { TodoItemProps } from './types';
import { UI_TEXT, CSS_CLASSES, KEYS } from './constants';
import './styles/TodoItem.css';

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggleDone, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  return (
    <li className={CSS_CLASSES.TODO_ITEM}>
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggleDone(todo.id)}
        className={CSS_CLASSES.TODO_CHECKBOX}
      />
      {isEditing ? (
        <>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={(e) => e.key === KEYS.ENTER && handleSave()}
            className={CSS_CLASSES.TODO_EDIT_INPUT}
          />
          <Button onClick={handleSave} variant="save">{UI_TEXT.SAVE_BUTTON}</Button>
          <Button onClick={handleCancel} variant="cancel">{UI_TEXT.CANCEL_BUTTON}</Button>
        </>
      ) : (
        <>
          <span
            className={`${CSS_CLASSES.TODO_TEXT} ${todo.done ? CSS_CLASSES.TODO_TEXT_COMPLETED : ''}`}
            onClick={() => setIsEditing(true)}
          >
            {todo.text}
          </span>
          <Button onClick={() => setIsEditing(true)} variant="edit">{UI_TEXT.EDIT_BUTTON}</Button>
          <Button onClick={() => onDelete(todo.id)} variant="delete">{UI_TEXT.DELETE_BUTTON}</Button>
        </>
      )}
      {/* Additional controls for status, priority, and due date */}
      <div style={{ marginLeft: 'auto', display: 'flex', gap: '8px', alignItems: 'center' }}>
        <label>
          <span style={{ marginRight: 4 }}>Status:</span>
          <select
            value={todo.status || 'todo'}
            onChange={(e) => onUpdateStatus && onUpdateStatus(todo.id, e.target.value as NonNullable<typeof todo.status>)}
          >
            <option value="todo">To Do</option>
            <option value="in-progress">In Progress</option>
            <option value="under-review">Under Review</option>
            <option value="blocked">Blocked</option>
            <option value="done">Done</option>
          </select>
        </label>
        <label>
          <span style={{ marginRight: 4 }}>Priority:</span>
          <select
            value={todo.priority || 'medium'}
            onChange={(e) => onUpdatePriority && onUpdatePriority(todo.id, e.target.value as NonNullable<typeof todo.priority>)}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>
        <label>
          <span style={{ marginRight: 4 }}>Due:</span>
          <input
            type="date"
            value={todo.dueDate || ''}
            onChange={(e) => onUpdateDueDate && onUpdateDueDate(todo.id, e.target.value)}
          />
        </label>
      </div>
    </li>
  );
};

export default TodoItem;
