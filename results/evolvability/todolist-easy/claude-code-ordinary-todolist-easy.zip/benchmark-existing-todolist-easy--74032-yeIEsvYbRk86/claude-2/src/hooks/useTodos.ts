import { useState } from 'react';
import { Todo, TodoStatus, TodoPriority } from '../types';
import { createTodo, toggleTodoCompletion, updateTodoText, removeTodo, updateTodoById, isValidTodoText, updateTodoStatus, updateTodoPriority, updateTodoDueDate } from '../utils';

export const useTodos = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [nextId, setNextId] = useState(1);

  const addTodo = (text: string) => {
    if (isValidTodoText(text)) {
      setTodos(prevTodos => [...prevTodos, createTodo(nextId, text)]);
      setNextId(prevId => prevId + 1);
      return true;
    }
    return false;
  };

  const toggleTodo = (id: number) => {
    setTodos(prevTodos => updateTodoById(prevTodos, id, toggleTodoCompletion));
  };

  const deleteTodo = (id: number) => {
    setTodos(prevTodos => removeTodo(prevTodos, id));
  };

  const editTodo = (id: number, newText: string) => {
    if (isValidTodoText(newText)) {
      setTodos(prevTodos => 
        updateTodoById(prevTodos, id, todo => updateTodoText(todo, newText))
      );
      return true;
    }
    return false;
  };

  const updateStatus = (id: number, status: TodoStatus) => {
    setTodos(prevTodos => updateTodoById(prevTodos, id, todo => updateTodoStatus(todo, status)));
  };

  const updatePriority = (id: number, priority: TodoPriority) => {
    setTodos(prevTodos => updateTodoById(prevTodos, id, todo => updateTodoPriority(todo, priority)));
  };

  const updateDueDate = (id: number, dueDate?: string) => {
    setTodos(prevTodos => updateTodoById(prevTodos, id, todo => updateTodoDueDate(todo, dueDate)));
  };

  return {
    todos,
    addTodo,
    toggleTodo,
    deleteTodo,
    editTodo,
    updateStatus,
    updatePriority,
    updateDueDate,
  };
};