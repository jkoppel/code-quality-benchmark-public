export type TodoStatus = 'pending' | 'in-progress' | 'under-review' | 'blocked' | 'done';
export type TodoPriority = 'low' | 'medium' | 'high';

export interface Todo {
  id: number;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string;
}

export interface TodoItemProps {
  todo: Todo;
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: TodoStatus) => void;
  onUpdatePriority: (id: number, priority: TodoPriority) => void;
  onUpdateDueDate: (id: number, dueDate: string) => void;
}

export interface TodoListProps {
  todos: Todo[];
  onToggleDone: (id: number) => void;
  onDelete: (id: number) => void;
  onEdit: (id: number, newText: string) => void;
  onUpdateStatus: (id: number, status: TodoStatus) => void;
  onUpdatePriority: (id: number, priority: TodoPriority) => void;
  onUpdateDueDate: (id: number, dueDate: string) => void;
}