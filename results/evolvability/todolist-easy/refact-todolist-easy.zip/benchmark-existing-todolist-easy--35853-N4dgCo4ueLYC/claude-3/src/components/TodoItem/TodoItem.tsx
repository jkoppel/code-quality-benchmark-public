import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Todo, TodoStatus, TodoPriority } from '../../types/todo';
import './TodoItem.css';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus: (id: string, status: TodoStatus) => void;
  onUpdatePriority: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate: (id: string, dueDate?: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);
  const editInputRef = useRef<HTMLInputElement>(null);

  // Focus and select text when editing starts
  useEffect(() => {
    if (isEditing && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  return (
    <li className="todo-item">
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo.id)}
        className="todo-checkbox"
      />
      {isEditing ? (
        <>
          <input
            ref={editInputRef}
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={handleKeyDown}
            className="todo-edit-input"
          />
          <button onClick={handleSave} className="todo-button save">
            Save
          </button>
          <button onClick={handleCancel} className="todo-button cancel">
            Cancel
          </button>
        </>
      ) : (
        <>
          <div className="todo-content">
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onDoubleClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <div className="todo-metadata">
              <select
                value={todo.status}
                onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
                className={`status-select status-${todo.status}`}
              >
                <option value="not-started">Not Started</option>
                <option value="in-progress">In Progress</option>
                <option value="under-review">Under Review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
              <select
                value={todo.priority}
                onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
                className={`priority-select priority-${todo.priority}`}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
              <input
                type="date"
                value={todo.dueDate || ''}
                onChange={(e) => onUpdateDueDate(todo.id, e.target.value || undefined)}
                className="due-date-input"
                title="Due date"
              />
              {todo.dueDate && (
                <span className={`due-date-display ${new Date(todo.dueDate) < new Date() ? 'overdue' : ''}`}>
                  Due: {new Date(todo.dueDate).toLocaleDateString()}
                </span>
              )}
            </div>
          </div>
          <div className="todo-actions">
            <button onClick={() => setIsEditing(true)} className="todo-button edit">
              Edit
            </button>
            <button onClick={() => onDelete(todo.id)} className="todo-button delete">
              Delete
            </button>
          </div>
        </>
      )}
    </li>
  );
};

export default TodoItem;
