export type TodoStatus = 'not-started' | 'in-progress' | 'under-review' | 'blocked' | 'done';
export type TodoPriority = 'low' | 'medium' | 'high';

export interface Todo {
  id: string;
  text: string;
  done: boolean;
  status: TodoStatus;
  priority: TodoPriority;
  // Stored as ISO date string (YYYY-MM-DD) for simplicity
  dueDate?: string;
}

export type TodosState = Todo[];

export type TodosAction =
  | { type: 'ADD_TODO'; payload: { text: string; status?: TodoStatus; priority?: TodoPriority; dueDate?: string } }
  | { type: 'TOGGLE_TODO'; payload: { id: string } }
  | { type: 'DELETE_TODO'; payload: { id: string } }
  | { type: 'EDIT_TODO'; payload: { id: string; text: string } }
  | { type: 'SET_STATUS'; payload: { id: string; status: TodoStatus } }
  | { type: 'SET_PRIORITY'; payload: { id: string; priority: TodoPriority } }
  | { type: 'SET_DUE_DATE'; payload: { id: string; dueDate?: string } };
