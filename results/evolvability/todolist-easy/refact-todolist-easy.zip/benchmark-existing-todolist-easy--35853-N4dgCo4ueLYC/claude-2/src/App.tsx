import React from 'react';
import { useTodos } from './hooks/useTodos';
import AddTodoForm from './components/AddTodoForm/AddTodoForm';
import TodoList from './components/TodoList/TodoList';
import './App.css';

function App() {
  const { todos, addTodo, toggleTodo, deleteTodo, editTodo, updateStatus, updatePriority, updateDueDate } = useTodos();

  return (
    <div className="App">
      <div className="app-container">
        <h1 className="app-title">Todo List</h1>
        <AddTodoForm onAdd={addTodo} />
        <TodoList
          todos={todos}
          onToggle={toggleTodo}
          onDelete={deleteTodo}
          onEdit={editTodo}
          onUpdateStatus={updateStatus}
          onUpdatePriority={updatePriority}
          onUpdateDueDate={updateDueDate}
        />
      </div>
    </div>
  );
}

export default App;
