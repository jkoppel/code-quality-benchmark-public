import React, { useState, KeyboardEvent } from 'react';
import { TodoPriority } from '../../types/todo';
import './AddTodoForm.css';

interface AddTodoFormProps {
  onAdd: (text: string, priority?: TodoPriority, dueDate?: Date) => void;
}

const AddTodoForm: React.FC<AddTodoFormProps> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState('');

  const handleAdd = () => {
    if (text.trim()) {
      const dueDateObj = dueDate ? new Date(dueDate) : undefined;
      onAdd(text, priority, dueDateObj);
      setText('');
      setPriority('medium');
      setDueDate('');
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAdd();
    }
  };

  return (
    <div className="input-container">
      <div className="main-input-row">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Enter a new task"
          className="task-input"
        />
        <button onClick={handleAdd} className="add-button">
          Add Todo
        </button>
      </div>
      
      <div className="options-row">
        <div className="input-group">
          <label htmlFor="priority">Priority:</label>
          <select
            id="priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value as TodoPriority)}
            className="priority-select"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        
        <div className="input-group">
          <label htmlFor="dueDate">Due Date:</label>
          <input
            id="dueDate"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="date-input"
          />
        </div>
      </div>
    </div>
  );
};

export default AddTodoForm;
