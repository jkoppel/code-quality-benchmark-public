import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Todo, TodoStatus, TodoPriority } from '../../types/todo';
import './TodoItem.css';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus: (id: string, status: TodoStatus) => void;
  onUpdatePriority: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate: (id: string, dueDate?: Date) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggle, 
  onDelete, 
  onEdit, 
  onUpdateStatus, 
  onUpdatePriority, 
  onUpdateDueDate 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);
  const editInputRef = useRef<HTMLInputElement>(null);

  // Focus and select text when editing starts
  useEffect(() => {
    if (isEditing && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  const formatDueDate = (dueDate?: Date) => {
    if (!dueDate) return '';
    return dueDate.toLocaleDateString();
  };

  const isOverdue = (dueDate?: Date) => {
    if (!dueDate) return false;
    return dueDate < new Date() && todo.status !== 'done';
  };

  const getPriorityColor = (priority: TodoPriority) => {
    switch (priority) {
      case 'urgent': return '#ff4444';
      case 'high': return '#ff8800';
      case 'medium': return '#ffcc00';
      case 'low': return '#88cc88';
      default: return '#cccccc';
    }
  };

  const getStatusColor = (status: TodoStatus) => {
    switch (status) {
      case 'done': return '#4CAF50';
      case 'in-progress': return '#2196F3';
      case 'under-review': return '#FF9800';
      case 'blocked': return '#f44336';
      case 'not-started': return '#9E9E9E';
      default: return '#9E9E9E';
    }
  };

  return (
    <li className={`todo-item ${isOverdue(todo.dueDate) ? 'overdue' : ''}`}>
      <div className="todo-main">
        <input
          type="checkbox"
          checked={todo.done}
          onChange={() => onToggle(todo.id)}
          className="todo-checkbox"
        />
        {isEditing ? (
          <>
            <input
              ref={editInputRef}
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={handleKeyDown}
              className="todo-edit-input"
            />
            <button onClick={handleSave} className="todo-button save">
              Save
            </button>
            <button onClick={handleCancel} className="todo-button cancel">
              Cancel
            </button>
          </>
        ) : (
          <>
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onDoubleClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <div className="todo-actions">
              <button onClick={() => setIsEditing(true)} className="todo-button edit">
                Edit
              </button>
              <button onClick={() => onDelete(todo.id)} className="todo-button delete">
                Delete
              </button>
            </div>
          </>
        )}
      </div>
      
      {!isEditing && (
        <div className="todo-metadata">
          <div className="todo-controls">
            <div className="control-group">
              <label>Status:</label>
              <select
                value={todo.status}
                onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
                className="todo-select"
                style={{ borderColor: getStatusColor(todo.status) }}
              >
                <option value="not-started">Not Started</option>
                <option value="in-progress">In Progress</option>
                <option value="under-review">Under Review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
            </div>
            
            <div className="control-group">
              <label>Priority:</label>
              <select
                value={todo.priority}
                onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
                className="todo-select"
                style={{ borderColor: getPriorityColor(todo.priority) }}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            
            <div className="control-group">
              <label>Due Date:</label>
              <input
                type="date"
                value={todo.dueDate ? todo.dueDate.toISOString().split('T')[0] : ''}
                onChange={(e) => onUpdateDueDate(todo.id, e.target.value ? new Date(e.target.value) : undefined)}
                className="todo-date-input"
              />
            </div>
          </div>
          
          <div className="todo-info">
            <span className="priority-indicator" style={{ backgroundColor: getPriorityColor(todo.priority) }}>
              {todo.priority.toUpperCase()}
            </span>
            <span className="status-indicator" style={{ backgroundColor: getStatusColor(todo.status) }}>
              {todo.status.replace('-', ' ').toUpperCase()}
            </span>
            {todo.dueDate && (
              <span className={`due-date ${isOverdue(todo.dueDate) ? 'overdue' : ''}`}>
                Due: {formatDueDate(todo.dueDate)}
              </span>
            )}
          </div>
        </div>
      )}
    </li>
  );
};

export default TodoItem;
