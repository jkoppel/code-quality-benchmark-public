import React, { useState, KeyboardEvent } from 'react';
import { TodoPriority, TodoStatus } from '../../types/todo';
import './AddTodoForm.css';

interface AddTodoFormProps {
  onAdd: (text: string, status: TodoStatus, priority: TodoPriority, dueDate?: string) => void;
}

const AddTodoForm: React.FC<AddTodoFormProps> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [status, setStatus] = useState<TodoStatus>('todo');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState<string | undefined>(undefined);

  const handleAdd = () => {
    if (text.trim()) {
      onAdd(text, status, priority, dueDate);
      setText('');
      setStatus('todo');
      setPriority('medium');
      setDueDate(undefined);
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAdd();
    }
  };

  return (
    <div className="input-container">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder="Enter a new task"
        className="task-input"
      />
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value as TodoStatus)}
        className="select-input"
        aria-label="Status"
      >
        <option value="todo">Todo</option>
        <option value="in-progress">In Progress</option>
        <option value="under-review">Under Review</option>
        <option value="blocked">Blocked</option>
      </select>
      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value as TodoPriority)}
        className="select-input"
        aria-label="Priority"
      >
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
      <input
        type="date"
        value={dueDate ?? ''}
        onChange={(e) => setDueDate(e.target.value || undefined)}
        className="date-input"
        aria-label="Due date"
      />
      <button onClick={handleAdd} className="add-button">
        Add Todo
      </button>
    </div>
  );
};

export default AddTodoForm;
