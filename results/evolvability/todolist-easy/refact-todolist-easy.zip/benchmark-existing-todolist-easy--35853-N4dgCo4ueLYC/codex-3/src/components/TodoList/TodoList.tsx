import React from 'react';
import { Todo, TodoPriority, TodoStatus } from '../../types/todo';
import TodoItem from '../TodoItem/TodoItem';
import './TodoList.css';

interface TodoListProps {
  todos: Todo[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, text: string) => void;
  onSetStatus: (id: string, status: TodoStatus) => void;
  onSetPriority: (id: string, priority: TodoPriority) => void;
  onSetDueDate: (id: string, dueDate?: string) => void;
}

const TodoList: React.FC<TodoListProps> = ({ todos, onToggle, onDelete, onEdit, onSetStatus, onSetPriority, onSetDueDate }) => {
  return (
    <ul className="todo-list">
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={onToggle}
          onDelete={onDelete}
          onEdit={onEdit}
          onSetStatus={onSetStatus}
          onSetPriority={onSetPriority}
          onSetDueDate={onSetDueDate}
        />
      ))}
    </ul>
  );
};

export default React.memo(TodoList);
