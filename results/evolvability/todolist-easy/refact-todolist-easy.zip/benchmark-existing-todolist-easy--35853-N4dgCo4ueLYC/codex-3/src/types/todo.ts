export interface Todo {
  id: string;
  text: string;
  done: boolean;
  // Additional metadata
  status: TodoStatus;
  priority: TodoPriority;
  dueDate?: string; // ISO date string (YYYY-MM-DD)
}

export type TodosState = Todo[];

export type TodoStatus = 'todo' | 'in-progress' | 'under-review' | 'blocked';
export type TodoPriority = 'low' | 'medium' | 'high';

export type TodosAction =
  | { type: 'ADD_TODO'; payload: { text: string; status: TodoStatus; priority: TodoPriority; dueDate?: string } }
  | { type: 'TOGGLE_TODO'; payload: { id: string } }
  | { type: 'DELETE_TODO'; payload: { id: string } }
  | { type: 'EDIT_TODO'; payload: { id: string; text: string } }
  | { type: 'SET_TODO_STATUS'; payload: { id: string; status: TodoStatus } }
  | { type: 'SET_TODO_PRIORITY'; payload: { id: string; priority: TodoPriority } }
  | { type: 'SET_TODO_DUE_DATE'; payload: { id: string; dueDate?: string } };
