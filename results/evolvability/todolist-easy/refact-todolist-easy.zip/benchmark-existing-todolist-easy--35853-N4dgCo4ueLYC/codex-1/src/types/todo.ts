export interface Todo {
  id: string;
  text: string;
  done: boolean;
  // Additional metadata
  status: 'not_started' | 'in_progress' | 'under_review' | 'blocked';
  priority: 'low' | 'medium' | 'high';
  // Stored as YYYY-MM-DD string for simplicity
  dueDate?: string | null;
}

export type TodosState = Todo[];

export type TodosAction =
  | { type: 'ADD_TODO'; payload: { text: string } }
  | { type: 'TOGGLE_TODO'; payload: { id: string } }
  | { type: 'DELETE_TODO'; payload: { id: string } }
  | { type: 'EDIT_TODO'; payload: { id: string; text: string } }
  | { type: 'UPDATE_TODO'; payload: { id: string; updates: Partial<Pick<Todo, 'status' | 'priority' | 'dueDate'>> } };
