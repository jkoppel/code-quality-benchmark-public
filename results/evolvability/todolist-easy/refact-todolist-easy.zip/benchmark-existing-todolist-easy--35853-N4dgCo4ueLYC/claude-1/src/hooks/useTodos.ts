import { useReducer, useCallback } from 'react';
import { TodosState, TodosAction, Todo, TodoStatus, TodoPriority } from '../types/todo';

// Simple ID generator for compatibility
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

function todosReducer(state: TodosState, action: TodosAction): TodosState {
  switch (action.type) {
    case 'ADD_TODO': {
      const text = action.payload.text.trim();
      if (!text) return state;
      const newTodo: Todo = { 
        id: generateId(), 
        text, 
        done: false,
        status: 'not-done',
        priority: action.payload.priority || 'medium',
        dueDate: action.payload.dueDate
      };
      return [...state, newTodo];
    }

    case 'TOGGLE_TODO': {
      return state.map(todo =>
        todo.id === action.payload.id ? { 
          ...todo, 
          done: !todo.done,
          status: !todo.done ? 'done' : 'not-done'
        } : todo
      );
    }

    case 'DELETE_TODO': {
      return state.filter(todo => todo.id !== action.payload.id);
    }

    case 'EDIT_TODO': {
      const newText = action.payload.text.trim();
      if (!newText) return state;
      return state.map(todo =>
        todo.id === action.payload.id ? { ...todo, text: newText } : todo
      );
    }

    case 'UPDATE_STATUS': {
      return state.map(todo =>
        todo.id === action.payload.id ? { 
          ...todo, 
          status: action.payload.status,
          done: action.payload.status === 'done'
        } : todo
      );
    }

    case 'UPDATE_PRIORITY': {
      return state.map(todo =>
        todo.id === action.payload.id ? { ...todo, priority: action.payload.priority } : todo
      );
    }

    case 'UPDATE_DUE_DATE': {
      return state.map(todo =>
        todo.id === action.payload.id ? { ...todo, dueDate: action.payload.dueDate } : todo
      );
    }

    default:
      return state;
  }
}

export function useTodos(initialTodos: TodosState = []) {
  const [todos, dispatch] = useReducer(todosReducer, initialTodos);

  const addTodo = useCallback((text: string, priority?: TodoPriority, dueDate?: string) => 
    dispatch({ type: 'ADD_TODO', payload: { text, priority, dueDate } }), []);
  
  const toggleTodo = useCallback((id: string) => 
    dispatch({ type: 'TOGGLE_TODO', payload: { id } }), []);
  
  const deleteTodo = useCallback((id: string) => 
    dispatch({ type: 'DELETE_TODO', payload: { id } }), []);
  
  const editTodo = useCallback((id: string, text: string) => 
    dispatch({ type: 'EDIT_TODO', payload: { id, text } }), []);

  const updateStatus = useCallback((id: string, status: TodoStatus) => 
    dispatch({ type: 'UPDATE_STATUS', payload: { id, status } }), []);
  
  const updatePriority = useCallback((id: string, priority: TodoPriority) => 
    dispatch({ type: 'UPDATE_PRIORITY', payload: { id, priority } }), []);
  
  const updateDueDate = useCallback((id: string, dueDate?: string) => 
    dispatch({ type: 'UPDATE_DUE_DATE', payload: { id, dueDate } }), []);

  return { todos, addTodo, toggleTodo, deleteTodo, editTodo, updateStatus, updatePriority, updateDueDate };
}
