import React, { useState, KeyboardEvent } from 'react';
import { TodoPriority } from '../../types/todo';
import './AddTodoForm.css';

interface AddTodoFormProps {
  onAdd: (text: string, priority?: TodoPriority, dueDate?: string) => void;
}

const AddTodoForm: React.FC<AddTodoFormProps> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [dueDate, setDueDate] = useState('');

  const handleAdd = () => {
    if (text.trim()) {
      onAdd(text, priority, dueDate || undefined);
      setText('');
      setPriority('medium');
      setDueDate('');
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAdd();
    }
  };

  return (
    <div className="input-container">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder="Enter a new task"
        className="task-input"
      />
      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value as TodoPriority)}
        className="priority-select"
      >
        <option value="low">Low Priority</option>
        <option value="medium">Medium Priority</option>
        <option value="high">High Priority</option>
      </select>
      <input
        type="date"
        value={dueDate}
        onChange={(e) => setDueDate(e.target.value)}
        className="due-date-input"
        title="Due Date (optional)"
      />
      <button onClick={handleAdd} className="add-button">
        Add Todo
      </button>
    </div>
  );
};

export default AddTodoForm;
