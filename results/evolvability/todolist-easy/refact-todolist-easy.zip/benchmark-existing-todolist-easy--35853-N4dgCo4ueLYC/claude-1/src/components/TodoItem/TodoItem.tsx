import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Todo, TodoStatus, TodoPriority } from '../../types/todo';
import './TodoItem.css';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, newText: string) => void;
  onUpdateStatus?: (id: string, status: TodoStatus) => void;
  onUpdatePriority?: (id: string, priority: TodoPriority) => void;
  onUpdateDueDate?: (id: string, dueDate?: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit, onUpdateStatus, onUpdatePriority, onUpdateDueDate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);
  const editInputRef = useRef<HTMLInputElement>(null);

  // Focus and select text when editing starts
  useEffect(() => {
    if (isEditing && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(todo.id, editText);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  const getStatusColor = (status: TodoStatus) => {
    switch (status) {
      case 'done': return '#4caf50';
      case 'in-progress': return '#2196f3';
      case 'under-review': return '#ff9800';
      case 'blocked': return '#f44336';
      default: return '#9e9e9e';
    }
  };

  const getPriorityColor = (priority: TodoPriority) => {
    switch (priority) {
      case 'high': return '#f44336';
      case 'medium': return '#ff9800';
      case 'low': return '#4caf50';
      default: return '#9e9e9e';
    }
  };

  const formatDueDate = (dueDate?: string) => {
    if (!dueDate) return null;
    const date = new Date(dueDate);
    const today = new Date();
    const isOverdue = date < today;
    return {
      formatted: date.toLocaleDateString(),
      isOverdue
    };
  };

  return (
    <li className="todo-item">
      <input
        type="checkbox"
        checked={todo.done}
        onChange={() => onToggle(todo.id)}
        className="todo-checkbox"
      />
      {isEditing ? (
        <>
          <input
            ref={editInputRef}
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={handleKeyDown}
            className="todo-edit-input"
          />
          <button onClick={handleSave} className="todo-button save">
            Save
          </button>
          <button onClick={handleCancel} className="todo-button cancel">
            Cancel
          </button>
        </>
      ) : (
        <>
          <div className="todo-content">
            <span
              className={`todo-text ${todo.done ? 'completed' : ''}`}
              onDoubleClick={() => setIsEditing(true)}
            >
              {todo.text}
            </span>
            <div className="todo-metadata">
              <span 
                className="status-badge" 
                style={{ backgroundColor: getStatusColor(todo.status) }}
              >
                {todo.status.replace('-', ' ')}
              </span>
              <span 
                className="priority-badge" 
                style={{ backgroundColor: getPriorityColor(todo.priority) }}
              >
                {todo.priority}
              </span>
              {todo.dueDate && (
                <span 
                  className={`due-date ${formatDueDate(todo.dueDate)?.isOverdue ? 'overdue' : ''}`}
                >
                  Due: {formatDueDate(todo.dueDate)?.formatted}
                </span>
              )}
            </div>
          </div>
          <div className="todo-controls">
            {onUpdateStatus && (
              <select
                value={todo.status}
                onChange={(e) => onUpdateStatus(todo.id, e.target.value as TodoStatus)}
                className="status-select"
              >
                <option value="not-done">Not Done</option>
                <option value="in-progress">In Progress</option>
                <option value="under-review">Under Review</option>
                <option value="blocked">Blocked</option>
                <option value="done">Done</option>
              </select>
            )}
            {onUpdatePriority && (
              <select
                value={todo.priority}
                onChange={(e) => onUpdatePriority(todo.id, e.target.value as TodoPriority)}
                className="priority-select"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            )}
            {onUpdateDueDate && (
              <input
                type="date"
                value={todo.dueDate || ''}
                onChange={(e) => onUpdateDueDate(todo.id, e.target.value || undefined)}
                className="due-date-input"
              />
            )}
            <button onClick={() => setIsEditing(true)} className="todo-button edit">
              Edit
            </button>
            <button onClick={() => onDelete(todo.id)} className="todo-button delete">
              Delete
            </button>
          </div>
        </>
      )}
    </li>
  );
};

export default TodoItem;
