import React, { useRef, useState } from 'react';
import './styles/PixelArt.css';
import { ColorPicker } from './components/ColorPicker';
import { DEFAULT_COLOR } from './constants';
import EditorPane from './components/EditorPane';
import { Color } from './types';

const PixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState(DEFAULT_COLOR);
  const [paneIds, setPaneIds] = useState<number[]>([1]);
  const nextIdRef = useRef(2);

  const updateColor = (partial: Partial<Color>) => {
    setSelectedColor((prev) => ({ ...prev, ...partial }));
  };

  const addPane = () => {
    const id = nextIdRef.current++;
    setPaneIds((prev) => [...prev, id]);
  };

  const closePane = (id: number) => {
    setPaneIds((prev) => prev.filter((pid) => pid !== id));
  };

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>

      <div className="toolbar">
        <ColorPicker selectedColor={selectedColor} onColorChange={updateColor} />
        <button className="add-pane" onClick={addPane}>+ New Pane</button>
      </div>

      <div className="panes-container">
        {paneIds.map((id) => (
          <EditorPane key={id} id={id} selectedColor={selectedColor} onClose={closePane} />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;
