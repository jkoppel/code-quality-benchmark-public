import React, { useRef, useState } from 'react';
import './styles/PixelArt.css';
import { ColorPicker } from './components/ColorPicker';
import { DEFAULT_COLOR } from './constants';
import PixelPane from './components/PixelPane';
import { Color } from './types';

const PixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState<Color>(DEFAULT_COLOR);
  const [paneIds, setPaneIds] = useState<string[]>(() => ['1']);
  const nextIdRef = useRef<number>(2);

  const handleAddPane = () => {
    const id = String(nextIdRef.current++);
    setPaneIds((prev) => [...prev, id]);
  };

  const handleClosePane = (id: string) => {
    setPaneIds((prev) => prev.filter((p) => p !== id));
  };

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>
      <div className="toolbar">
        <ColorPicker selectedColor={selectedColor} onColorChange={(c) => setSelectedColor((prev) => ({ ...prev, ...c }))} />
        <div className="toolbar-actions">
          <button onClick={handleAddPane}>New Pane</button>
        </div>
      </div>

      <div className="panes-container">
        {paneIds.map((id) => (
          <PixelPane key={id} id={id} selectedColor={selectedColor} onClose={handleClosePane} />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;
