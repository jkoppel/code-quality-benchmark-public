import React, { useRef } from 'react';
import { usePixelArt } from '../hooks/usePixelArt';
import { Color } from '../types';
import { CanvasGrid } from './CanvasGrid';
import { Controls } from './Controls';
import { FileLoader } from './FileLoader';

interface PixelPaneProps {
  id: string;
  selectedColor: Color;
  onClose: (id: string) => void;
}

export const PixelPane: React.FC<PixelPaneProps> = ({ id, selectedColor, onClose }) => {
  const { pixels, updatePixel, loadPixels } = usePixelArt({ selectedColorOverride: selectedColor });
  const fileLoaderRef = useRef<HTMLInputElement>(null);

  const handleLoadClick = () => {
    fileLoaderRef.current?.click();
  };

  return (
    <div className="pane-card">
      <div className="pane-header">
        <span>Pane {id}</span>
        <button className="close-pane" onClick={() => onClose(id)} aria-label={`Close pane ${id}`}>
          ×
        </button>
      </div>
      <CanvasGrid pixels={pixels} onPixelClick={updatePixel} />
      <Controls pixels={pixels} onLoadClick={handleLoadClick} />
      <FileLoader ref={fileLoaderRef} onLoad={loadPixels} />
    </div>
  );
};

export default PixelPane;

