import { useState, useCallback } from 'react';
import { PixelPane, PixelGrid, Color } from '../types';
import { GRID_SIZE, DEFAULT_PIXEL_COLOR, DEFAULT_COLOR } from '../constants';

const createInitialGrid = (): PixelGrid => {
  return Array(GRID_SIZE)
    .fill(null)
    .map(() => Array(GRID_SIZE).fill(DEFAULT_PIXEL_COLOR));
};

const generateId = () => Math.random().toString(36).substr(2, 9);

export const useMultiPane = () => {
  const [panes, setPanes] = useState<PixelPane[]>([
    { id: generateId(), pixels: createInitialGrid(), name: 'Pane 1' }
  ]);
  const [selectedColor, setSelectedColor] = useState<Color>(DEFAULT_COLOR);

  const createPane = useCallback(() => {
    setPanes(prevPanes => [
      ...prevPanes,
      { 
        id: generateId(), 
        pixels: createInitialGrid(), 
        name: `Pane ${prevPanes.length + 1}` 
      }
    ]);
  }, []);

  const closePane = useCallback((paneId: string) => {
    setPanes(prevPanes => {
      if (prevPanes.length <= 1) return prevPanes; // Keep at least one pane
      return prevPanes.filter(pane => pane.id !== paneId);
    });
  }, []);

  const updatePanePixels = useCallback((paneId: string, newPixels: PixelGrid) => {
    setPanes(prevPanes => 
      prevPanes.map(pane => 
        pane.id === paneId ? { ...pane, pixels: newPixels } : pane
      )
    );
  }, []);

  const updateColor = useCallback((color: Partial<Color>) => {
    setSelectedColor((prevColor) => ({ ...prevColor, ...color }));
  }, []);

  return {
    panes,
    selectedColor,
    createPane,
    closePane,
    updatePanePixels,
    updateColor,
    setSelectedColor
  };
};