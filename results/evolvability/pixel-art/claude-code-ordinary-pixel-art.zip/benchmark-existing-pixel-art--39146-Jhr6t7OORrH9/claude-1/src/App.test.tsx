import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders pixel art editor', () => {
  render(<App />);
  const titleElement = screen.getByText(/pixel art editor/i);
  expect(titleElement).toBeInTheDocument();
});
