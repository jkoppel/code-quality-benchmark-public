import React, { useRef, useCallback } from 'react';
import { PixelPane as PixelPaneType, Color, GridPosition, PixelGrid } from '../types';
import { CanvasGrid } from './CanvasGrid';
import { Controls } from './Controls';
import { FileLoader } from './FileLoader';
import { colorToRgbString, isValidGridPosition } from '../utils/canvasUtils';

interface PixelPaneProps {
  pane: PixelPaneType;
  selectedColor: Color;
  onPixelsUpdate: (paneId: string, pixels: PixelGrid) => void;
  onClose: (paneId: string) => void;
  showCloseButton: boolean;
}

export const PixelPane: React.FC<PixelPaneProps> = ({
  pane,
  selectedColor,
  onPixelsUpdate,
  onClose,
  showCloseButton
}) => {
  const fileLoaderRef = useRef<HTMLInputElement>(null);

  const updatePixel = useCallback((position: GridPosition) => {
    if (!isValidGridPosition(position)) return;

    const newPixels = [...pane.pixels];
    newPixels[position.row][position.col] = colorToRgbString(selectedColor);
    onPixelsUpdate(pane.id, newPixels);
  }, [pane.id, pane.pixels, selectedColor, onPixelsUpdate]);

  const handleLoadClick = () => {
    fileLoaderRef.current?.click();
  };

  const handleLoad = (newPixels: PixelGrid) => {
    onPixelsUpdate(pane.id, newPixels);
  };

  return (
    <div className="pixel-pane">
      <div className="pane-header">
        <h3>{pane.name}</h3>
        {showCloseButton && (
          <button 
            className="close-button"
            onClick={() => onClose(pane.id)}
            aria-label="Close pane"
          >
            ×
          </button>
        )}
      </div>

      <CanvasGrid
        pixels={pane.pixels}
        onPixelClick={updatePixel}
      />

      <Controls
        pixels={pane.pixels}
        onLoadClick={handleLoadClick}
      />
      
      <FileLoader
        ref={fileLoaderRef}
        onLoad={handleLoad}
      />
    </div>
  );
};