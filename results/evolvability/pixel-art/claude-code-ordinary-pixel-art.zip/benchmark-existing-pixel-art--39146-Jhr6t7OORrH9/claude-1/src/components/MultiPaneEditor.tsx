import React from 'react';
import { useMultiPane } from '../hooks/useMultiPane';
import { ColorPicker } from './ColorPicker';
import { PixelPane } from './PixelPane';

const MultiPaneEditor: React.FC = () => {
  const {
    panes,
    selectedColor,
    createPane,
    closePane,
    updatePanePixels,
    updateColor
  } = useMultiPane();

  return (
    <div className="multi-pane-editor">
      <h1>Pixel Art Editor</h1>
      
      <ColorPicker
        selectedColor={selectedColor}
        onColorChange={updateColor}
      />

      <div className="pane-management">
        <button onClick={createPane} className="create-pane-button">
          + Add New Pane
        </button>
        <span className="pane-count">{panes.length} pane{panes.length !== 1 ? 's' : ''}</span>
      </div>

      <div className="panes-container">
        {panes.map((pane) => (
          <PixelPane
            key={pane.id}
            pane={pane}
            selectedColor={selectedColor}
            onPixelsUpdate={updatePanePixels}
            onClose={closePane}
            showCloseButton={panes.length > 1}
          />
        ))}
      </div>
    </div>
  );
};

export default MultiPaneEditor;