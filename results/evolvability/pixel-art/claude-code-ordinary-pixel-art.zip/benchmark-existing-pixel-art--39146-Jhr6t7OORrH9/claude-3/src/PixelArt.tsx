import React, { useRef, useCallback } from 'react';
import './styles/PixelArt.css';
import { usePixelArt } from './hooks/usePixelArt';
import { ColorPicker } from './components/ColorPicker';
import { CanvasGrid } from './components/CanvasGrid';
import { Controls } from './components/Controls';
import { FileLoader } from './components/FileLoader';
import { Color, PixelGrid, GridPosition } from './types';
import { colorToRgbString, isValidGridPosition } from './utils/canvasUtils';

interface PixelArtProps {
  paneId?: string;
  pixels?: PixelGrid;
  selectedColor?: Color;
  onPixelsChange?: (pixels: PixelGrid) => void;
  showColorPicker?: boolean;
  showTitle?: boolean;
}

const PixelArt: React.FC<PixelArtProps> = ({ 
  paneId,
  pixels: externalPixels,
  selectedColor: externalSelectedColor,
  onPixelsChange,
  showColorPicker = true,
  showTitle = true
}) => {
  const {
    pixels: internalPixels,
    selectedColor: internalSelectedColor,
    updatePixel: internalUpdatePixel,
    updateColor: internalUpdateColor,
    loadPixels: internalLoadPixels
  } = usePixelArt();
  
  const fileLoaderRef = useRef<HTMLInputElement>(null);

  // Use external props if provided, otherwise fall back to internal state
  const pixels = externalPixels || internalPixels;
  const selectedColor = externalSelectedColor || internalSelectedColor;

  const updatePixel = useCallback((position: GridPosition) => {
    if (!isValidGridPosition(position)) return;

    if (externalPixels && onPixelsChange) {
      // External mode: update through callback
      const newPixels = [...externalPixels];
      newPixels[position.row][position.col] = colorToRgbString(selectedColor);
      onPixelsChange(newPixels);
    } else {
      // Internal mode: use internal state
      internalUpdatePixel(position);
    }
  }, [externalPixels, onPixelsChange, selectedColor, internalUpdatePixel]);

  const loadPixels = useCallback((newPixels: PixelGrid) => {
    if (externalPixels && onPixelsChange) {
      // External mode: update through callback
      onPixelsChange(newPixels);
    } else {
      // Internal mode: use internal state
      internalLoadPixels(newPixels);
    }
  }, [externalPixels, onPixelsChange, internalLoadPixels]);

  const handleLoadClick = () => {
    fileLoaderRef.current?.click();
  };

  return (
    <div className="pixel-art-container">
      {showTitle && <h1>Pixel Art Editor</h1>}
      
      {showColorPicker && (
        <ColorPicker
          selectedColor={selectedColor}
          onColorChange={internalUpdateColor}
        />
      )}

      <CanvasGrid
        pixels={pixels}
        onPixelClick={updatePixel}
      />

      <Controls
        paneId={paneId}
        pixels={pixels}
        onLoadClick={handleLoadClick}
      />
      
      <FileLoader
        ref={fileLoaderRef}
        onLoad={loadPixels}
      />
    </div>
  );
};

export default PixelArt;