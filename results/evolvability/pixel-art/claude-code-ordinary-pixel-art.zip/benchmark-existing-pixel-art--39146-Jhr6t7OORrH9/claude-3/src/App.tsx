import React from 'react';
import MultiPaneEditor from './MultiPaneEditor';
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <MultiPaneEditor />
    </div>
  );
}

export default App;
