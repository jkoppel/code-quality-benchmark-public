import React, { useState, useCallback } from 'react';
import { Pane, Color, PixelGrid } from './types';
import { DEFAULT_COLOR, DEFAULT_PIXEL_COLOR, GRID_SIZE } from './constants';
import { ColorPicker } from './components/ColorPicker';
import PixelArt from './PixelArt';
import './styles/PixelArt.css';

const createInitialGrid = (): PixelGrid => {
  return Array(GRID_SIZE)
    .fill(null)
    .map(() => Array(GRID_SIZE).fill(DEFAULT_PIXEL_COLOR));
};

const createNewPane = (index: number): Pane => ({
  id: `pane-${Date.now()}-${index}`,
  name: `Pane ${index + 1}`,
  pixels: createInitialGrid()
});

const MultiPaneEditor: React.FC = () => {
  const [panes, setPanes] = useState<Pane[]>([createNewPane(0)]);
  const [selectedColor, setSelectedColor] = useState<Color>(DEFAULT_COLOR);

  const addPane = useCallback(() => {
    setPanes(prev => [...prev, createNewPane(prev.length)]);
  }, []);

  const removePane = useCallback((paneId: string) => {
    setPanes(prev => {
      if (prev.length <= 1) return prev; // Keep at least one pane
      return prev.filter(pane => pane.id !== paneId);
    });
  }, []);

  const updatePanePixels = useCallback((paneId: string, newPixels: PixelGrid) => {
    setPanes(prev => prev.map(pane => 
      pane.id === paneId ? { ...pane, pixels: newPixels } : pane
    ));
  }, []);

  const updateColor = useCallback((color: Partial<Color>) => {
    setSelectedColor(prevColor => ({ ...prevColor, ...color }));
  }, []);

  return (
    <div className="multi-pane-container">
      <h1>Multi-Pane Pixel Art Editor</h1>
      
      <ColorPicker
        selectedColor={selectedColor}
        onColorChange={updateColor}
      />

      <div className="pane-controls">
        <button onClick={addPane} className="add-pane-btn">
          + Add New Pane
        </button>
      </div>

      <div className="panes-container">
        {panes.map((pane) => (
          <div key={pane.id} className="pane-wrapper">
            <div className="pane-header">
              <h3>{pane.name}</h3>
              {panes.length > 1 && (
                <button 
                  onClick={() => removePane(pane.id)}
                  className="close-pane-btn"
                >
                  ✕
                </button>
              )}
            </div>
            <PixelArt
              paneId={pane.id}
              pixels={pane.pixels}
              selectedColor={selectedColor}
              onPixelsChange={(newPixels) => updatePanePixels(pane.id, newPixels)}
              showColorPicker={false}
              showTitle={false}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default MultiPaneEditor;