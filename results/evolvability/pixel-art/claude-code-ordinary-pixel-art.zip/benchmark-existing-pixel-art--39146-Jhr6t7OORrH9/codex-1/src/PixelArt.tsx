import React, { useCallback, useRef, useState } from 'react';
import './styles/PixelArt.css';
import { ColorPicker } from './components/ColorPicker';
import { CanvasGrid } from './components/CanvasGrid';
import { Controls } from './components/Controls';
import { FileLoader } from './components/FileLoader';
import { Color, PixelGrid, GridPosition } from './types';
import { DEFAULT_COLOR, DEFAULT_PIXEL_COLOR, GRID_SIZE } from './constants';
import { colorToRgbString, isValidGridPosition } from './utils/canvasUtils';

const PixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState<Color>(DEFAULT_COLOR);
  const createInitialGrid = useCallback((): PixelGrid => {
    return Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill(DEFAULT_PIXEL_COLOR));
  }, []);

  const [panes, setPanes] = useState<PixelGrid[]>(() => [createInitialGrid()]);

  const fileLoaderRefs = useRef<Array<HTMLInputElement | null>>([]);

  const updateColor = useCallback((color: Partial<Color>) => {
    setSelectedColor((prev) => ({ ...prev, ...color }));
  }, []);

  const handlePixelClick = useCallback(
    (paneIndex: number, position: GridPosition) => {
      if (!isValidGridPosition(position)) return;
      setPanes((prev) => {
        const next = prev.map((grid) => grid);
        const paneGrid = next[paneIndex];
        if (!paneGrid) return prev;
        const newGrid = paneGrid.map((row) => [...row]);
        newGrid[position.row][position.col] = colorToRgbString(selectedColor);
        next[paneIndex] = newGrid;
        return [...next];
      });
    },
    [selectedColor]
  );

  const handleAddPane = () => {
    setPanes((prev) => [...prev, createInitialGrid()]);
  };

  const handleClosePane = (paneIndex: number) => {
    setPanes((prev) => prev.filter((_, i) => i !== paneIndex));
    // Clean up ref slot
    fileLoaderRefs.current.splice(paneIndex, 1);
  };

  const handleLoadClick = (paneIndex: number) => {
    fileLoaderRefs.current[paneIndex]?.click();
  };

  const handlePixelsLoaded = (paneIndex: number, newPixels: PixelGrid) => {
    setPanes((prev) => {
      const next = [...prev];
      next[paneIndex] = newPixels;
      return next;
    });
  };

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>
      <div className="top-controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={updateColor} />
        <button className="new-pane-btn" onClick={handleAddPane}>New Pane</button>
      </div>

      <div className="panes-container">
        {panes.map((pixels, idx) => (
          <div className="pane" key={idx}>
            <div className="pane-header">
              <span>Pane {idx + 1}</span>
              <button className="close-pane-btn" onClick={() => handleClosePane(idx)}>Close</button>
            </div>
            <CanvasGrid
              pixels={pixels}
              onPixelClick={(pos) => handlePixelClick(idx, pos)}
            />
            <Controls
              pixels={pixels}
              onLoadClick={() => handleLoadClick(idx)}
            />
            <FileLoader
              ref={(el) => (fileLoaderRefs.current[idx] = el)}
              onLoad={(p) => handlePixelsLoaded(idx, p)}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PixelArt;
