import React, { useRef } from 'react';
import { Pane, GridPosition, PixelGrid } from '../types';
import { CanvasGrid } from './CanvasGrid';
import { Controls } from './Controls';
import { FileLoader } from './FileLoader';

interface PixelPaneProps {
  pane: Pane;
  onPixelClick: (paneId: string, position: GridPosition) => void;
  onLoadPixels: (paneId: string, pixels: PixelGrid) => void;
  onRemovePane: (paneId: string) => void;
  canRemove: boolean;
}

export const PixelPane: React.FC<PixelPaneProps> = ({
  pane,
  onPixelClick,
  onLoadPixels,
  onRemovePane,
  canRemove
}) => {
  const fileLoaderRef = useRef<HTMLInputElement>(null);

  const handleLoadClick = () => {
    fileLoaderRef.current?.click();
  };

  const handlePixelClick = (position: GridPosition) => {
    onPixelClick(pane.id, position);
  };

  const handleLoad = (pixels: PixelGrid) => {
    onLoadPixels(pane.id, pixels);
  };

  const handleRemove = () => {
    onRemovePane(pane.id);
  };

  return (
    <div className="pixel-pane">
      <div className="pane-header">
        <h3>{pane.name}</h3>
        {canRemove && (
          <button className="remove-pane-btn" onClick={handleRemove}>
            ×
          </button>
        )}
      </div>

      <CanvasGrid
        pixels={pane.pixels}
        onPixelClick={handlePixelClick}
      />

      <Controls
        pixels={pane.pixels}
        onLoadClick={handleLoadClick}
        paneName={pane.name}
      />
      
      <FileLoader
        ref={fileLoaderRef}
        onLoad={handleLoad}
      />
    </div>
  );
};