import React from 'react';
import { PixelGrid } from '../types';
import { savePixelsAsBitmapWithName } from '../utils/fileUtils';

interface ControlsProps {
  pixels: PixelGrid;
  onLoadClick: () => void;
  paneName?: string;
}

export const Controls: React.FC<ControlsProps> = ({ pixels, onLoadClick, paneName }) => {
  const handleSave = () => {
    savePixelsAsBitmapWithName(pixels, paneName);
  };

  return (
    <div className="controls">
      <button onClick={handleSave}>Save as Bitmap</button>
      <button onClick={onLoadClick}>Load Bitmap</button>
    </div>
  );
};