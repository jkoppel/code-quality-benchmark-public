import React from 'react';
import PixelArt from './PixelArt';
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <PixelArt />
    </div>
  );
}

export default App;
