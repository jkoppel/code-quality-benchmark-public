import React from 'react';
import './styles/PixelArt.css';
import { useMultiPanePixelArt } from './hooks/useMultiPanePixelArt';
import { ColorPicker } from './components/ColorPicker';
import { PixelPane } from './components/PixelPane';

const PixelArt: React.FC = () => {
  const {
    panes,
    selectedColor,
    updatePixel,
    updateColor,
    addPane,
    removePane,
    loadPixelsToPane
  } = useMultiPanePixelArt();

  return (
    <div className="pixel-art-container">
      <h1>Multi-Pane Pixel Art Editor</h1>
      
      <ColorPicker
        selectedColor={selectedColor}
        onColorChange={updateColor}
      />

      <div className="pane-controls">
        <button className="add-pane-btn" onClick={addPane}>
          + Add New Pane
        </button>
      </div>

      <div className="panes-container">
        {panes.map((pane) => (
          <PixelPane
            key={pane.id}
            pane={pane}
            onPixelClick={updatePixel}
            onLoadPixels={loadPixelsToPane}
            onRemovePane={removePane}
            canRemove={panes.length > 1}
          />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;