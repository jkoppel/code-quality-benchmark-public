export const GRID_SIZE = 32;
export const PIXEL_SIZE = 15;
export const GRID_LINE_COLOR = '#E0E0E0';
export const DEFAULT_PIXEL_COLOR = '#FFFFFF';
export const DEFAULT_COLOR = { r: 0, g: 0, b: 0 };
export const FILE_DOWNLOAD_NAME = 'pixel-art.bmp';