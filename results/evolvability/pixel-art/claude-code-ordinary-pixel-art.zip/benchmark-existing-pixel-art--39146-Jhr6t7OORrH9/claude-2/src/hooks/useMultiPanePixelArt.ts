import { useState, useCallback } from 'react';
import { Pane, PixelGrid, Color, GridPosition } from '../types';
import { GRID_SIZE, DEFAULT_PIXEL_COLOR, DEFAULT_COLOR } from '../constants';
import { colorToRgbString, isValidGridPosition } from '../utils/canvasUtils';

const createInitialGrid = (): PixelGrid => {
  return Array(GRID_SIZE)
    .fill(null)
    .map(() => Array(GRID_SIZE).fill(DEFAULT_PIXEL_COLOR));
};

const createPane = (id: string, name: string): Pane => ({
  id,
  pixels: createInitialGrid(),
  name
});

export const useMultiPanePixelArt = () => {
  const [selectedColor, setSelectedColor] = useState<Color>(DEFAULT_COLOR);
  const [panes, setPanes] = useState<Pane[]>([createPane('1', 'Pane 1')]);

  const updatePixel = useCallback(
    (paneId: string, position: GridPosition) => {
      if (!isValidGridPosition(position)) return;

      setPanes((prevPanes) =>
        prevPanes.map((pane) =>
          pane.id === paneId
            ? {
                ...pane,
                pixels: pane.pixels.map((row, rowIndex) =>
                  rowIndex === position.row
                    ? row.map((pixel, colIndex) =>
                        colIndex === position.col
                          ? colorToRgbString(selectedColor)
                          : pixel
                      )
                    : row
                )
              }
            : pane
        )
      );
    },
    [selectedColor]
  );

  const updateColor = useCallback((color: Partial<Color>) => {
    setSelectedColor((prevColor) => ({ ...prevColor, ...color }));
  }, []);

  const addPane = useCallback(() => {
    const newId = (Math.max(...panes.map(p => parseInt(p.id))) + 1).toString();
    const newPane = createPane(newId, `Pane ${newId}`);
    setPanes((prevPanes) => [...prevPanes, newPane]);
  }, [panes]);

  const removePane = useCallback((paneId: string) => {
    setPanes((prevPanes) => {
      const filteredPanes = prevPanes.filter((pane) => pane.id !== paneId);
      return filteredPanes.length > 0 ? filteredPanes : [createPane('1', 'Pane 1')];
    });
  }, []);

  const loadPixelsToPane = useCallback((paneId: string, newPixels: PixelGrid) => {
    setPanes((prevPanes) =>
      prevPanes.map((pane) =>
        pane.id === paneId ? { ...pane, pixels: newPixels } : pane
      )
    );
  }, []);

  const resetPane = useCallback((paneId: string) => {
    setPanes((prevPanes) =>
      prevPanes.map((pane) =>
        pane.id === paneId ? { ...pane, pixels: createInitialGrid() } : pane
      )
    );
  }, []);

  return {
    panes,
    selectedColor,
    updatePixel,
    updateColor,
    setSelectedColor,
    addPane,
    removePane,
    loadPixelsToPane,
    resetPane
  };
};