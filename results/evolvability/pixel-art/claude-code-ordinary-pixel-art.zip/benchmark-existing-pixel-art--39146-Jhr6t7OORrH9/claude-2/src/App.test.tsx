import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders multi-pane pixel art editor', () => {
  render(<App />);
  const titleElement = screen.getByText(/multi-pane pixel art editor/i);
  expect(titleElement).toBeInTheDocument();
});

test('renders add new pane button', () => {
  render(<App />);
  const addPaneButton = screen.getByText(/add new pane/i);
  expect(addPaneButton).toBeInTheDocument();
});

test('renders initial pane', () => {
  render(<App />);
  const paneTitle = screen.getByText(/pane 1/i);
  expect(paneTitle).toBeInTheDocument();
});
