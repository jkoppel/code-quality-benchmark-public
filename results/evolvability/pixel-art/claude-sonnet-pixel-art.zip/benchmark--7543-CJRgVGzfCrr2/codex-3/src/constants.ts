export const GRID_SIZE = 32;

