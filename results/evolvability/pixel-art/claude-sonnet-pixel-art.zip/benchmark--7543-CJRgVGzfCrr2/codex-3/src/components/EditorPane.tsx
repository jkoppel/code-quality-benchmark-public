import React, { useRef } from 'react';
import PixelGrid from './PixelGrid';
import FileControls from './FileControls';
import { GRID_SIZE } from '../constants';

interface EditorPaneProps {
  paneIndex: number;
  pixels: string[][];
  selectedColor: string;
  onPixelClick: (row: number, col: number) => void;
  onSetPixels: (pixels: string[][]) => void;
  onClose: () => void;
}

const EditorPane: React.FC<EditorPaneProps> = ({
  paneIndex,
  pixels,
  selectedColor,
  onPixelClick,
  onSetPixels,
  onClose,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    const canvas = document.createElement('canvas');
    canvas.width = GRID_SIZE;
    canvas.height = GRID_SIZE;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
          ctx.fillStyle = pixels[row][col];
          ctx.fillRect(col, row, 1, 1);
        }
      }

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `pixel-art-${paneIndex + 1}.png`;
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    }
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = GRID_SIZE;
        canvas.height = GRID_SIZE;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
          const imageData = ctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
          const newPixels = Array(GRID_SIZE)
            .fill(null)
            .map(() => Array(GRID_SIZE).fill('#ffffff'));

          for (let row = 0; row < GRID_SIZE; row++) {
            for (let col = 0; col < GRID_SIZE; col++) {
              const i = (row * GRID_SIZE + col) * 4;
              const r = imageData.data[i];
              const g = imageData.data[i + 1];
              const b = imageData.data[i + 2];
              newPixels[row][col] = `#${r
                .toString(16)
                .padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b
                .toString(16)
                .padStart(2, '0')}`;
            }
          }
          onSetPixels(newPixels);
        }
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="editor-pane">
      <div className="editor-pane-header">
        <span>Pane {paneIndex + 1}</span>
        <button className="close-pane-button" onClick={onClose} aria-label={`Close pane ${paneIndex + 1}`}>
          ×
        </button>
      </div>
      <PixelGrid pixels={pixels} onPixelClick={onPixelClick} />
      <div className="pane-controls">
        <FileControls onSave={handleSave} onLoad={handleLoad} fileInputRef={fileInputRef} />
      </div>
    </div>
  );
};

export default EditorPane;

