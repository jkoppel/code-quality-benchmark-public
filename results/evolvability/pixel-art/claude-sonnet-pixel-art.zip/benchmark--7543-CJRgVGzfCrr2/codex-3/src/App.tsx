import React, { useState } from 'react';
import EditorPane from './components/EditorPane';
import ColorPicker from './components/ColorPicker';
import './App.css';
import { GRID_SIZE } from './constants';

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const createEmptyPixels = () =>
    Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill('#ffffff'));
  const [panes, setPanes] = useState<string[][][]>([createEmptyPixels()]);

  const handlePixelClick = (paneIndex: number, row: number, col: number) => {
    setPanes((prev) => {
      const next = prev.map((p) => p);
      const pane = next[paneIndex].map((r) => r.slice());
      pane[row][col] = selectedColor;
      next[paneIndex] = pane;
      return next;
    });
  };

  const addPane = () => {
    setPanes((prev) => [...prev, createEmptyPixels()]);
  };

  const closePane = (paneIndex: number) => {
    setPanes((prev) => prev.filter((_, i) => i !== paneIndex));
  };

  return (
    <div className="App">
      <h1>Pixel Art Editor</h1>
      <div className="controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <button className="control-button add-pane-button" onClick={addPane}>New Pane</button>
      </div>
      <div className="panes-container">
        {panes.map((panePixels, index) => (
          <EditorPane
            key={index}
            paneIndex={index}
            pixels={panePixels}
            selectedColor={selectedColor}
            onPixelClick={(row, col) => handlePixelClick(index, row, col)}
            onSetPixels={(newPixels) =>
              setPanes((prev) => prev.map((p, i) => (i === index ? newPixels : p)))
            }
            onClose={() => closePane(index)}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
