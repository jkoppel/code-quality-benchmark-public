import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import PixelPane from './components/PixelPane';
import './App.css';

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [panes, setPanes] = useState<string[]>(['1']);
  const [nextPaneId, setNextPaneId] = useState(2);

  const handleCreatePane = () => {
    setPanes(prev => [...prev, nextPaneId.toString()]);
    setNextPaneId(prev => prev + 1);
  };

  const handleClosePane = (paneId: string) => {
    if (panes.length > 1) {
      setPanes(prev => prev.filter(id => id !== paneId));
    }
  };

  return (
    <div className="App">
      <h1>Multi-Pane Pixel Art Editor</h1>
      
      <div className="top-controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <button className="create-pane-button" onClick={handleCreatePane}>
          + New Pane
        </button>
      </div>
      
      <div className="panes-container">
        {panes.map(paneId => (
          <PixelPane
            key={paneId}
            paneId={paneId}
            selectedColor={selectedColor}
            onClose={handleClosePane}
          />
        ))}
      </div>
    </div>
  );
}

export default App;