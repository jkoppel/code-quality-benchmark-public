import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import './App.css';
import Pane from './components/Pane';

const GRID_SIZE = 32;

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [panes, setPanes] = useState<number[]>([0]);
  const [nextId, setNextId] = useState(1);

  const addPane = () => {
    setPanes((prev) => [...prev, nextId]);
    setNextId((id) => id + 1);
  };

  const removePane = (id: number) => {
    setPanes((prev) => prev.filter((pid) => pid !== id));
  };

  return (
    <div className="App">
      <h1>Pixel Art Editor</h1>
      <div className="controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <div>
          <button onClick={addPane} className="control-button">
            New Pane
          </button>
        </div>
      </div>
      <div className="panes">
        {panes.map((id) => (
          <Pane
            key={id}
            selectedColor={selectedColor}
            gridSize={GRID_SIZE}
            onClose={() => removePane(id)}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
