import React, { useRef, useState } from 'react';
import PixelGrid from './PixelGrid';
import FileControls from './FileControls';
import './Pane.css';

interface PaneProps {
  selectedColor: string;
  gridSize: number;
  onClose: () => void;
}

const Pane: React.FC<PaneProps> = ({ selectedColor, gridSize, onClose }) => {
  const [pixels, setPixels] = useState<string[][]>(
    Array(gridSize)
      .fill(null)
      .map(() => Array(gridSize).fill('#ffffff'))
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePixelClick = (row: number, col: number) => {
    const newPixels = pixels.map((r) => r.slice());
    newPixels[row][col] = selectedColor;
    setPixels(newPixels);
  };

  const handleSave = () => {
    const canvas = document.createElement('canvas');
    canvas.width = gridSize;
    canvas.height = gridSize;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
          ctx.fillStyle = pixels[row][col];
          ctx.fillRect(col, row, 1, 1);
        }
      }

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'pixel-art.png';
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    }
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = gridSize;
        canvas.height = gridSize;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.drawImage(img, 0, 0, gridSize, gridSize);
          const imageData = ctx.getImageData(0, 0, gridSize, gridSize);
          const newPixels = Array(gridSize)
            .fill(null)
            .map(() => Array(gridSize).fill('#ffffff'));

          for (let row = 0; row < gridSize; row++) {
            for (let col = 0; col < gridSize; col++) {
              const i = (row * gridSize + col) * 4;
              const r = imageData.data[i];
              const g = imageData.data[i + 1];
              const b = imageData.data[i + 2];
              newPixels[row][col] = `#${r
                .toString(16)
                .padStart(2, '0')}${g
                .toString(16)
                .padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
            }
          }
          setPixels(newPixels);
        }
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="pane">
      <div className="pane-header">
        <button className="close-pane-button" onClick={onClose} title="Close pane">
          ×
        </button>
      </div>
      <PixelGrid pixels={pixels} onPixelClick={handlePixelClick} />
      <FileControls onSave={handleSave} onLoad={handleLoad} fileInputRef={fileInputRef} />
    </div>
  );
};

export default Pane;

