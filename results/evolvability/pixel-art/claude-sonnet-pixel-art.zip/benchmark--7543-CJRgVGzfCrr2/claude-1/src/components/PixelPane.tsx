import React, { useState, useRef } from 'react';
import PixelGrid from './PixelGrid';
import FileControls from './FileControls';
import './PixelPane.css';

const GRID_SIZE = 32;

interface PixelPaneProps {
  selectedColor: string;
  paneId: number;
  onClose: (id: number) => void;
}

const PixelPane: React.FC<PixelPaneProps> = ({ selectedColor, paneId, onClose }) => {
  const [pixels, setPixels] = useState<string[][]>(
    Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill('#ffffff'))
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePixelClick = (row: number, col: number) => {
    const newPixels = [...pixels];
    newPixels[row][col] = selectedColor;
    setPixels(newPixels);
  };

  const handleSave = () => {
    const canvas = document.createElement('canvas');
    canvas.width = GRID_SIZE;
    canvas.height = GRID_SIZE;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
          ctx.fillStyle = pixels[row][col];
          ctx.fillRect(col, row, 1, 1);
        }
      }
      
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `pixel-art-pane-${paneId}.png`;
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    }
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = GRID_SIZE;
        canvas.height = GRID_SIZE;
        const ctx = canvas.getContext('2d');
        
        if (ctx) {
          ctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
          const imageData = ctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
          const newPixels = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill('#ffffff'));
          
          for (let row = 0; row < GRID_SIZE; row++) {
            for (let col = 0; col < GRID_SIZE; col++) {
              const i = (row * GRID_SIZE + col) * 4;
              const r = imageData.data[i];
              const g = imageData.data[i + 1];
              const b = imageData.data[i + 2];
              newPixels[row][col] = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
            }
          }
          setPixels(newPixels);
        }
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="pixel-pane">
      <div className="pane-header">
        <h3>Pane {paneId}</h3>
        <button 
          className="close-button" 
          onClick={() => onClose(paneId)}
          title="Close pane"
        >
          ×
        </button>
      </div>
      <div className="pane-controls">
        <FileControls 
          onSave={handleSave}
          onLoad={handleLoad}
          fileInputRef={fileInputRef}
        />
      </div>
      <PixelGrid 
        pixels={pixels}
        onPixelClick={handlePixelClick}
      />
    </div>
  );
};

export default PixelPane;