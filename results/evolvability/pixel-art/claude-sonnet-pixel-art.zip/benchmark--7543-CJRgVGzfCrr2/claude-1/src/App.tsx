import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import PixelPane from './components/PixelPane';
import './App.css';

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [panes, setPanes] = useState<number[]>([1]);
  const [nextPaneId, setNextPaneId] = useState(2);

  const handleAddPane = () => {
    setPanes([...panes, nextPaneId]);
    setNextPaneId(nextPaneId + 1);
  };

  const handleClosePane = (paneId: number) => {
    if (panes.length > 1) {
      setPanes(panes.filter(id => id !== paneId));
    }
  };

  return (
    <div className="App">
      <h1>Pixel Art Editor</h1>
      <div className="controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <button className="add-pane-button" onClick={handleAddPane}>
          Add New Pane
        </button>
      </div>
      <div className="panes-container">
        {panes.map(paneId => (
          <PixelPane
            key={paneId}
            paneId={paneId}
            selectedColor={selectedColor}
            onClose={handleClosePane}
          />
        ))}
      </div>
    </div>
  );
}

export default App;