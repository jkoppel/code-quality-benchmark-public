export interface Pane {
  id: string;
  pixels: string[][];
  name: string;
}

export const GRID_SIZE = 32;

export const createEmptyPixels = (): string[][] => 
  Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill('#ffffff'));

export const generatePaneId = (): string => 
  'pane-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);