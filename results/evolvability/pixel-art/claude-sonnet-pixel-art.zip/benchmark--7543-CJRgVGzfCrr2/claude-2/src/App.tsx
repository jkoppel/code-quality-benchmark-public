import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import PaneManager from './components/PaneManager';
import EditPane from './components/EditPane';
import { Pane, GRID_SIZE, createEmptyPixels, generatePaneId } from './types';
import './App.css';

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [panes, setPanes] = useState<Pane[]>([
    {
      id: generatePaneId(),
      name: 'Pane 1',
      pixels: createEmptyPixels()
    }
  ]);

  const handlePixelClick = (paneId: string, row: number, col: number) => {
    setPanes(prevPanes =>
      prevPanes.map(pane =>
        pane.id === paneId
          ? {
              ...pane,
              pixels: pane.pixels.map((pixelRow, r) =>
                r === row
                  ? pixelRow.map((pixel, c) => (c === col ? selectedColor : pixel))
                  : pixelRow
              )
            }
          : pane
      )
    );
  };

  const handleAddPane = () => {
    const newPane: Pane = {
      id: generatePaneId(),
      name: `Pane ${panes.length + 1}`,
      pixels: createEmptyPixels()
    };
    setPanes(prevPanes => [...prevPanes, newPane]);
  };

  const handleClosePane = (paneId: string) => {
    if (panes.length > 1) {
      setPanes(prevPanes => prevPanes.filter(pane => pane.id !== paneId));
    }
  };

  const handleRenamePane = (paneId: string, newName: string) => {
    setPanes(prevPanes =>
      prevPanes.map(pane =>
        pane.id === paneId ? { ...pane, name: newName } : pane
      )
    );
  };

  const handleSave = (paneId: string) => {
    const pane = panes.find(p => p.id === paneId);
    if (!pane) return;

    const canvas = document.createElement('canvas');
    canvas.width = GRID_SIZE;
    canvas.height = GRID_SIZE;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
          ctx.fillStyle = pane.pixels[row][col];
          ctx.fillRect(col, row, 1, 1);
        }
      }
      
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${pane.name.toLowerCase().replace(/\s+/g, '-')}.png`;
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    }
  };

  const handleLoad = (paneId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = GRID_SIZE;
        canvas.height = GRID_SIZE;
        const ctx = canvas.getContext('2d');
        
        if (ctx) {
          ctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
          const imageData = ctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
          const newPixels = createEmptyPixels();
          
          for (let row = 0; row < GRID_SIZE; row++) {
            for (let col = 0; col < GRID_SIZE; col++) {
              const i = (row * GRID_SIZE + col) * 4;
              const r = imageData.data[i];
              const g = imageData.data[i + 1];
              const b = imageData.data[i + 2];
              newPixels[row][col] = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
            }
          }
          
          setPanes(prevPanes =>
            prevPanes.map(pane =>
              pane.id === paneId ? { ...pane, pixels: newPixels } : pane
            )
          );
        }
      };
      img.src = URL.createObjectURL(file);
    }
    
    // Reset the input value so the same file can be loaded again
    event.target.value = '';
  };

  return (
    <div className="App">
      <h1>Pixel Art Editor</h1>
      <div className="main-controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <PaneManager paneCount={panes.length} onAddPane={handleAddPane} />
      </div>
      <div className="panes-container">
        {panes.map(pane => (
          <EditPane
            key={pane.id}
            pane={pane}
            selectedColor={selectedColor}
            onPixelClick={handlePixelClick}
            onSave={handleSave}
            onLoad={handleLoad}
            onClose={handleClosePane}
            onRename={handleRenamePane}
          />
        ))}
      </div>
    </div>
  );
}

export default App;