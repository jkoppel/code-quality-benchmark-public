import React from 'react';
import './PaneManager.css';

interface PaneManagerProps {
  paneCount: number;
  onAddPane: () => void;
}

const PaneManager: React.FC<PaneManagerProps> = ({ paneCount, onAddPane }) => {
  return (
    <div className="pane-manager">
      <button onClick={onAddPane} className="control-button add-pane-button">
        + Add New Pane
      </button>
      <span className="pane-count">Panes: {paneCount}</span>
    </div>
  );
};

export default PaneManager;