import React from 'react';
import './FileControls.css';

interface FileControlsProps {
  onSave: () => void;
  onLoad: (event: React.ChangeEvent<HTMLInputElement>) => void;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
}

const FileControls: React.FC<FileControlsProps> = ({ onSave, onLoad, fileInputRef }) => {
  const handleLoadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="file-controls">
      <button onClick={onSave} className="control-button save-button">
        Save Bitmap
      </button>
      <button onClick={handleLoadClick} className="control-button load-button">
        Load Bitmap
      </button>
      <input
        type="file"
        accept="image/*"
        onChange={onLoad}
        ref={fileInputRef}
        style={{ display: 'none' }}
      />
    </div>
  );
};

export default FileControls;