import React, { useRef } from 'react';
import PixelGrid from './PixelGrid';
import FileControls from './FileControls';
import { Pane } from '../types';
import './EditPane.css';

interface EditPaneProps {
  pane: Pane;
  selectedColor: string;
  onPixelClick: (paneId: string, row: number, col: number) => void;
  onSave: (paneId: string) => void;
  onLoad: (paneId: string, event: React.ChangeEvent<HTMLInputElement>) => void;
  onClose: (paneId: string) => void;
  onRename: (paneId: string, newName: string) => void;
}

const EditPane: React.FC<EditPaneProps> = ({
  pane,
  selectedColor,
  onPixelClick,
  onSave,
  onLoad,
  onClose,
  onRename
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePixelClick = (row: number, col: number) => {
    onPixelClick(pane.id, row, col);
  };

  const handleSave = () => {
    onSave(pane.id);
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    onLoad(pane.id, event);
  };

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onRename(pane.id, event.target.value);
  };

  return (
    <div className="edit-pane">
      <div className="pane-header">
        <input
          type="text"
          value={pane.name}
          onChange={handleNameChange}
          className="pane-name-input"
          placeholder="Pane name"
        />
        <button onClick={() => onClose(pane.id)} className="close-pane-button">
          ✕
        </button>
      </div>
      <div className="pane-controls">
        <FileControls 
          onSave={handleSave}
          onLoad={handleLoad}
          fileInputRef={fileInputRef}
        />
      </div>
      <PixelGrid 
        pixels={pane.pixels}
        onPixelClick={handlePixelClick}
      />
    </div>
  );
};

export default EditPane;