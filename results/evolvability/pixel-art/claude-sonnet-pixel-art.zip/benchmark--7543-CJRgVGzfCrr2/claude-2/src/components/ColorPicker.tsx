import React, { useState } from 'react';
import './ColorPicker.css';

interface ColorPickerProps {
  selectedColor: string;
  onColorChange: (color: string) => void;
}

const ColorPicker: React.FC<ColorPickerProps> = ({ selectedColor, onColorChange }) => {
  const [r, setR] = useState(parseInt(selectedColor.slice(1, 3), 16));
  const [g, setG] = useState(parseInt(selectedColor.slice(3, 5), 16));
  const [b, setB] = useState(parseInt(selectedColor.slice(5, 7), 16));

  const updateColor = (newR: number, newG: number, newB: number) => {
    const hex = `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
    onColorChange(hex);
  };

  const handleRChange = (value: number) => {
    setR(value);
    updateColor(value, g, b);
  };

  const handleGChange = (value: number) => {
    setG(value);
    updateColor(r, value, b);
  };

  const handleBChange = (value: number) => {
    setB(value);
    updateColor(r, g, value);
  };

  return (
    <div className="color-picker">
      <div className="color-preview" style={{ backgroundColor: selectedColor }}></div>
      <div className="rgb-sliders">
        <div className="slider-group">
          <label>R: {r}</label>
          <input
            type="range"
            min="0"
            max="255"
            value={r}
            onChange={(e) => handleRChange(parseInt(e.target.value))}
            className="slider red"
          />
        </div>
        <div className="slider-group">
          <label>G: {g}</label>
          <input
            type="range"
            min="0"
            max="255"
            value={g}
            onChange={(e) => handleGChange(parseInt(e.target.value))}
            className="slider green"
          />
        </div>
        <div className="slider-group">
          <label>B: {b}</label>
          <input
            type="range"
            min="0"
            max="255"
            value={b}
            onChange={(e) => handleBChange(parseInt(e.target.value))}
            className="slider blue"
          />
        </div>
      </div>
    </div>
  );
};

export default ColorPicker;