import React from 'react';
import './PixelGrid.css';

interface PixelGridProps {
  pixels: string[][];
  onPixelClick: (row: number, col: number) => void;
}

const PixelGrid: React.FC<PixelGridProps> = ({ pixels, onPixelClick }) => {
  return (
    <div className="pixel-grid">
      {pixels.map((row, rowIndex) => (
        <div key={rowIndex} className="pixel-row">
          {row.map((color, colIndex) => (
            <div
              key={colIndex}
              className="pixel"
              style={{ backgroundColor: color }}
              onClick={() => onPixelClick(rowIndex, colIndex)}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default PixelGrid;