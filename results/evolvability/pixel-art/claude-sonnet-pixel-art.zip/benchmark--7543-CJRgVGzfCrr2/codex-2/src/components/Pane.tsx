import React, { useRef, useState } from 'react';
import PixelGrid from './PixelGrid';
import FileControls from './FileControls';

interface PaneProps {
  id: number;
  selectedColor: string;
  onClose: (id: number) => void;
}

const GRID_SIZE = 32;

const Pane: React.FC<PaneProps> = ({ id, selectedColor, onClose }) => {
  const [pixels, setPixels] = useState<string[][]>(
    Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill('#ffffff'))
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePixelClick = (row: number, col: number) => {
    const newPixels = pixels.map((r, rIdx) =>
      r.map((c, cIdx) => (rIdx === row && cIdx === col ? selectedColor : c))
    );
    setPixels(newPixels);
  };

  const handleSave = () => {
    const canvas = document.createElement('canvas');
    canvas.width = GRID_SIZE;
    canvas.height = GRID_SIZE;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
          ctx.fillStyle = pixels[row][col];
          ctx.fillRect(col, row, 1, 1);
        }
      }

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `pixel-art-${id}.png`;
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    }
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = GRID_SIZE;
        canvas.height = GRID_SIZE;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
          const imageData = ctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
          const newPixels = Array(GRID_SIZE)
            .fill(null)
            .map(() => Array(GRID_SIZE).fill('#ffffff'));

          for (let row = 0; row < GRID_SIZE; row++) {
            for (let col = 0; col < GRID_SIZE; col++) {
              const i = (row * GRID_SIZE + col) * 4;
              const r = imageData.data[i];
              const g = imageData.data[i + 1];
              const b = imageData.data[i + 2];
              newPixels[row][col] = `#${r
                .toString(16)
                .padStart(2, '0')}${g
                .toString(16)
                .padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
            }
          }
          setPixels(newPixels);
        }
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="pane">
      <div className="pane-header">
        <span>Pane {id}</span>
        <button className="close-pane" onClick={() => onClose(id)} aria-label={`Close pane ${id}`}>
          ✕
        </button>
      </div>
      <div className="pane-controls">
        <FileControls onSave={handleSave} onLoad={handleLoad} fileInputRef={fileInputRef} />
      </div>
      <PixelGrid pixels={pixels} onPixelClick={handlePixelClick} />
    </div>
  );
};

export default Pane;

