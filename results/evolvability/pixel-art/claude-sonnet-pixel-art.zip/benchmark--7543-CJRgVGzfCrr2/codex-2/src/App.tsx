import React, { useState } from 'react';
import Pane from './components/Pane';
import ColorPicker from './components/ColorPicker';
import './App.css';

function App() {
  const [selectedColor, setSelectedColor] = useState('#000000');
  const [paneIds, setPaneIds] = useState<number[]>([1]);
  const [nextId, setNextId] = useState(2);

  const addPane = () => {
    setPaneIds((ids) => [...ids, nextId]);
    setNextId((n) => n + 1);
  };

  const closePane = (id: number) => {
    setPaneIds((ids) => ids.filter((pid) => pid !== id));
  };

  return (
    <div className="App">
      <h1>Pixel Art Editor</h1>
      <div className="controls">
        <ColorPicker selectedColor={selectedColor} onColorChange={setSelectedColor} />
        <button className="control-button add-pane" onClick={addPane}>+ Add Pane</button>
      </div>
      <div className="panes">
        {paneIds.map((id) => (
          <Pane key={id} id={id} selectedColor={selectedColor} onClose={closePane} />
        ))}
      </div>
    </div>
  );
}

export default App;
