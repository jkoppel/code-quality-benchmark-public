import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import EditorPane from './components/EditorPane';
import './styles/PixelArt.css';

const PixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState({ r: 0, g: 0, b: 0 });
  const [paneIds, setPaneIds] = useState<string[]>(() => ['1']);

  const addPane = () => {
    // generate a simple incremental id
    const next = (paneIds.length ? Math.max(...paneIds.map((p) => parseInt(p, 10))) + 1 : 1).toString();
    setPaneIds((prev) => [...prev, next]);
  };

  const closePane = (id: string) => {
    setPaneIds((prev) => prev.filter((p) => p !== id));
  };

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>
      <ColorPicker color={selectedColor} onChange={setSelectedColor} />
      <div className="panes-toolbar">
        <button onClick={addPane}>Add Pane</button>
      </div>
      <div className="panes-container">
        {paneIds.map((id) => (
          <EditorPane key={id} id={id} color={selectedColor} onClose={closePane} />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;
