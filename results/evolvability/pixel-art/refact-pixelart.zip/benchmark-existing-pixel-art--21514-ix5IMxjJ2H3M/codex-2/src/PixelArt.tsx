import React, { useState } from 'react';
import ColorPicker from './components/ColorPicker';
import EditorPane from './components/EditorPane';
import './styles/PixelArt.css';

const PixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState({ r: 0, g: 0, b: 0 });
  const [paneIds, setPaneIds] = useState<string[]>(['1']);

  const addPane = () => {
    setPaneIds((prev) => {
      const nextId = prev.length ? String(Math.max(...prev.map((p) => parseInt(p))) + 1) : '1';
      return [...prev, nextId];
    });
  };

  const closePane = (id: string) => {
    setPaneIds((prev) => prev.filter((p) => p !== id));
  };

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>
      <ColorPicker color={selectedColor} onChange={setSelectedColor} />
      <div className="pane-toolbar">
        <button onClick={addPane}>+ Add Pane</button>
      </div>
      <div className="panes">
        {paneIds.map((id) => (
          <EditorPane key={id} id={id} selectedColor={selectedColor} onClose={closePane} />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;
