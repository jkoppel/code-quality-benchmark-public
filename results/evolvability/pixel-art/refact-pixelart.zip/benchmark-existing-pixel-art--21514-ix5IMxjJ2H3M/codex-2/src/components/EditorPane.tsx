import React from 'react';
import usePixelArt from '../hooks/usePixelArt';
import CanvasGrid from './CanvasGrid';
import Controls from './Controls';
import FileLoader from './FileLoader';
import { RGB } from '../types';

interface Props {
  id: string;
  selectedColor: RGB;
  onClose: (id: string) => void;
}

const EditorPane: React.FC<Props> = ({ id, selectedColor, onClose }) => {
  const {
    canvasRef,
    fileInputRef,
    error,
    handleCanvasClick,
    handleSave,
    handleLoadFile,
    triggerFileLoad,
  } = usePixelArt(selectedColor);

  return (
    <div className="editor-pane">
      <div className="pane-header">
        <span>Pane {id}</span>
        <button className="pane-close" aria-label={`Close pane ${id}`} onClick={() => onClose(id)}>
          ×
        </button>
      </div>
      {error && <div className="error">Error: {error}</div>}
      <CanvasGrid canvasRef={canvasRef} onClick={handleCanvasClick} />
      <Controls onSave={handleSave} onLoadClick={triggerFileLoad} />
      <FileLoader fileInputRef={fileInputRef} onChange={handleLoadFile} />
    </div>
  );
};

export default EditorPane;

