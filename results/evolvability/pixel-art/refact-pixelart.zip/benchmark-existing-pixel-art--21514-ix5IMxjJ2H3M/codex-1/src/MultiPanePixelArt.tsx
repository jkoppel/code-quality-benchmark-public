import React, { useState } from 'react';
import { RGB } from './types';
import ColorPicker from './components/ColorPicker';
import EditorPane from './components/EditorPane';
import './styles/PixelArt.css';

let nextPaneId = 1;

const MultiPanePixelArt: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState<RGB>({ r: 0, g: 0, b: 0 });
  const [paneIds, setPaneIds] = useState<number[]>([nextPaneId++]);

  function addPane() {
    setPaneIds((ids) => [...ids, nextPaneId++]);
  }

  function removePane(id: number) {
    setPaneIds((ids) => ids.filter((x) => x !== id));
  }

  return (
    <div className="pixel-art-container">
      <h1>Pixel Art Editor</h1>
      <ColorPicker color={selectedColor} onChange={setSelectedColor} />
      <div className="pane-toolbar">
        <button className="add-pane" onClick={addPane}>+ New Pane</button>
      </div>
      <div className="panes-container">
        {paneIds.map((id) => (
          <EditorPane
            key={id}
            id={id}
            selectedColor={selectedColor}
            onClose={removePane}
          />)
        )}
      </div>
    </div>
  );
};

export default MultiPanePixelArt;

