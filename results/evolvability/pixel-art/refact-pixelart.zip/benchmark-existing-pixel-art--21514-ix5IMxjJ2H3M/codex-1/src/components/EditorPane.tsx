import React from 'react';
import usePixelArt from '../hooks/usePixelArt';
import CanvasGrid from './CanvasGrid';
import Controls from './Controls';
import FileLoader from './FileLoader';

interface Props {
  id: number;
  selectedColor: { r: number; g: number; b: number };
  onClose: (id: number) => void;
}

const EditorPane: React.FC<Props> = ({ id, selectedColor, onClose }) => {
  const {
    canvasRef,
    fileInputRef,
    error,
    handleCanvasClick,
    handleSave,
    handleLoadFile,
    triggerFileLoad,
  } = usePixelArt(selectedColor);

  return (
    <div className="editor-pane">
      <div className="pane-header">
        <span>Pane #{id}</span>
        <button className="close-pane" onClick={() => onClose(id)} title="Close pane">
          ×
        </button>
      </div>
      {error && <div className="error">Error: {error}</div>}
      <CanvasGrid canvasRef={canvasRef} onClick={handleCanvasClick} />
      <div className="pane-controls">
        <Controls onSave={handleSave} onLoadClick={triggerFileLoad} />
      </div>
      <FileLoader fileInputRef={fileInputRef} onChange={handleLoadFile} />
    </div>
  );
};

export default EditorPane;

