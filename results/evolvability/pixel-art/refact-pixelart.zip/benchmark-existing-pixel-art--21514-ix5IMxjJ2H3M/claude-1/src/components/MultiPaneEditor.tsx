import React from 'react';
import useMultiPaneEditor from '../hooks/useMultiPaneEditor';
import ColorPicker from './ColorPicker';
import PixelArtPane from './PixelArtPane';
import '../styles/MultiPaneEditor.css';

const MultiPaneEditor: React.FC = () => {
  const {
    selectedColor,
    setSelectedColor,
    panes,
    addPane,
    removePane,
  } = useMultiPaneEditor();

  return (
    <div className="multi-pane-editor">
      <h1>Multi-Pane Pixel Art Editor</h1>
      
      <div className="editor-header">
        <ColorPicker color={selectedColor} onChange={setSelectedColor} />
        <div className="pane-controls">
          <button className="add-pane-btn" onClick={addPane}>
            + Add Pane
          </button>
        </div>
      </div>

      <div className="panes-container">
        {panes.map((pane) => (
          <PixelArtPane
            key={pane.id}
            paneId={pane.id}
            paneName={pane.name}
            selectedColor={selectedColor}
            onRemove={panes.length > 1 ? () => removePane(pane.id) : undefined}
          />
        ))}
      </div>
    </div>
  );
};

export default MultiPaneEditor;