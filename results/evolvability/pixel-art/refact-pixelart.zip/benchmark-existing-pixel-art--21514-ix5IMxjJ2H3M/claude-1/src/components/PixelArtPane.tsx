import React from 'react';
import usePixelArt from '../hooks/usePixelArt';
import CanvasGrid from './CanvasGrid';
import Controls from './Controls';
import FileLoader from './FileLoader';
import { RGB } from '../types';

interface Props {
  paneId: string;
  paneName: string;
  selectedColor: RGB;
  onRemove?: () => void;
}

const PixelArtPane: React.FC<Props> = ({ paneId, paneName, selectedColor, onRemove }) => {
  const {
    canvasRef,
    fileInputRef,
    error,
    handleCanvasClick,
    handleLoadFile,
    triggerFileLoad,
  } = usePixelArt(selectedColor);

  const handlePaneSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Use pane name for filename
    const fileName = `${paneName.toLowerCase().replace(/\s+/g, '-')}.png`;
    const link = document.createElement('a');
    link.download = fileName;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="pixel-art-pane">
      <div className="pane-header">
        <h3>{paneName}</h3>
        {onRemove && (
          <button className="remove-pane-btn" onClick={onRemove}>
            ×
          </button>
        )}
      </div>
      {error && <div className="error">Error: {error}</div>}
      <CanvasGrid canvasRef={canvasRef} onClick={handleCanvasClick} />
      <Controls onSave={handlePaneSave} onLoadClick={triggerFileLoad} />
      <FileLoader fileInputRef={fileInputRef} onChange={handleLoadFile} />
    </div>
  );
};

export default PixelArtPane;