import { useState, useCallback } from 'react';
import { RGB } from '../types';

export interface Pane {
  id: string;
  name: string;
}

export default function useMultiPaneEditor() {
  const [selectedColor, setSelectedColor] = useState<RGB>({ r: 0, g: 0, b: 0 });
  const [panes, setPanes] = useState<Pane[]>([{ id: '1', name: 'Pane 1' }]);
  const [nextId, setNextId] = useState(2);

  const addPane = useCallback(() => {
    const newPane: Pane = {
      id: nextId.toString(),
      name: `Pane ${nextId}`,
    };
    setPanes(prev => [...prev, newPane]);
    setNextId(prev => prev + 1);
  }, [nextId]);

  const removePane = useCallback((paneId: string) => {
    setPanes(prev => prev.filter(pane => pane.id !== paneId));
  }, []);

  return {
    selectedColor,
    setSelectedColor,
    panes,
    addPane,
    removePane,
  };
}