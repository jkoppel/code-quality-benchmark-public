export const GRID_SIZE = 32;
export const PIXEL_SIZE = 15;
export const DEFAULT_COLOR = '#FFFFFF';
export const GRID_STROKE_COLOR = '#E0E0E0';
