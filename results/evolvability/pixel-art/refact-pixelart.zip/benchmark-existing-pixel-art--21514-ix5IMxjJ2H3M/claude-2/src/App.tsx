import React from 'react';
import MultiPanePixelArt from './MultiPanePixelArt';
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <MultiPanePixelArt />
    </div>
  );
}

export default App;
