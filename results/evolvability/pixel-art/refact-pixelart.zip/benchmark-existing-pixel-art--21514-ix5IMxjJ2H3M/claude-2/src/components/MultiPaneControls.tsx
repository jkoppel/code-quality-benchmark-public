import React from 'react';
import PaneTab from './PaneTab';
import { Pane } from '../hooks/useMultiPanePixelArt';

interface Props {
  panes: Pane[];
  activePaneId: number;
  onPaneSelect: (paneId: number) => void;
  onPaneClose: (paneId: number) => void;
  onNewPane: () => void;
  onSave: (paneId: number) => void;
  onLoadClick: (paneId: number) => void;
}

const MultiPaneControls: React.FC<Props> = ({
  panes,
  activePaneId,
  onPaneSelect,
  onPaneClose,
  onNewPane,
  onSave,
  onLoadClick,
}) => {
  const activePane = panes.find(p => p.id === activePaneId);

  return (
    <div className="multi-pane-controls">
      <div className="pane-tabs">
        {panes.map(pane => (
          <PaneTab
            key={pane.id}
            paneId={pane.id}
            name={pane.name}
            isActive={pane.id === activePaneId}
            canClose={panes.length > 1}
            onSelect={onPaneSelect}
            onClose={onPaneClose}
          />
        ))}
        <button className="new-pane-button" onClick={onNewPane}>
          + New Pane
        </button>
      </div>
      
      {activePane && (
        <div className="active-pane-controls">
          <button onClick={() => onSave(activePane.id)}>
            Save "{activePane.name}" as Bitmap
          </button>
          <button onClick={() => onLoadClick(activePane.id)}>
            Load into "{activePane.name}"
          </button>
        </div>
      )}
    </div>
  );
};

export default MultiPaneControls;