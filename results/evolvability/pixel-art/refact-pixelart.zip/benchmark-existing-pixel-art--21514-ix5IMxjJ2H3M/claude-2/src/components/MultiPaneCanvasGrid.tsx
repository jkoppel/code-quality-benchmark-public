import React, { useEffect } from 'react';
import { GRID_SIZE, PIXEL_SIZE } from '../constants';
import { drawPixelGrid } from '../utils/canvasUtils';
import { Pane } from '../hooks/useMultiPanePixelArt';

interface Props {
  panes: Pane[];
  onCanvasClick: (e: React.MouseEvent<HTMLCanvasElement>, paneId: number) => void;
}

const MultiPaneCanvasGrid: React.FC<Props> = ({ panes, onCanvasClick }) => {
  // Re-draw all canvases whenever their pixel data changes
  useEffect(() => {
    panes.forEach(pane => {
      const canvas = pane.canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      drawPixelGrid(ctx, pane.pixels);
    });
  }, [panes]);

  return (
    <div className="multi-pane-canvas-container">
      {panes.map(pane => (
        <div key={pane.id} className="canvas-pane">
          <h4>{pane.name}</h4>
          <canvas
            ref={pane.canvasRef}
            width={GRID_SIZE * PIXEL_SIZE}
            height={GRID_SIZE * PIXEL_SIZE}
            className="drawing-canvas"
            onClick={(e) => onCanvasClick(e, pane.id)}
          />
        </div>
      ))}
    </div>
  );
};

export default MultiPaneCanvasGrid;