import React from 'react';

interface Props {
  paneId: number;
  name: string;
  isActive: boolean;
  canClose: boolean;
  onSelect: (paneId: number) => void;
  onClose: (paneId: number) => void;
}

const PaneTab: React.FC<Props> = ({ 
  paneId, 
  name, 
  isActive, 
  canClose, 
  onSelect, 
  onClose 
}) => {
  return (
    <div 
      className={`pane-tab ${isActive ? 'active' : ''}`}
      onClick={() => onSelect(paneId)}
    >
      <span className="pane-name">{name}</span>
      {canClose && (
        <button 
          className="close-button"
          onClick={(e) => {
            e.stopPropagation();
            onClose(paneId);
          }}
        >
          ×
        </button>
      )}
    </div>
  );
};

export default PaneTab;