import React from 'react';
import useMultiPanePixelArt from './hooks/useMultiPanePixelArt';
import ColorPicker from './components/ColorPicker';
import MultiPaneCanvasGrid from './components/MultiPaneCanvasGrid';
import MultiPaneControls from './components/MultiPaneControls';
import FileLoader from './components/FileLoader';
import './styles/PixelArt.css';
import './styles/MultiPane.css';

const MultiPanePixelArt: React.FC = () => {
  const {
    selectedColor,
    setSelectedColor,
    panes,
    activePaneId,
    setActivePaneId,
    error,
    createNewPane,
    closePane,
    handleCanvasClick,
    handleSave,
    handleLoadFile,
    triggerFileLoad,
  } = useMultiPanePixelArt();

  return (
    <div className="pixel-art-container multi-pane">
      <h1>Multi-Pane Pixel Art Editor</h1>
      {error && <div className="error">Error: {error}</div>}
      
      <ColorPicker color={selectedColor} onChange={setSelectedColor} />
      
      <MultiPaneControls
        panes={panes}
        activePaneId={activePaneId}
        onPaneSelect={setActivePaneId}
        onPaneClose={closePane}
        onNewPane={createNewPane}
        onSave={handleSave}
        onLoadClick={triggerFileLoad}
      />
      
      <MultiPaneCanvasGrid
        panes={panes}
        onCanvasClick={handleCanvasClick}
      />
      
      {panes.map(pane => (
        <FileLoader
          key={pane.id}
          fileInputRef={pane.fileInputRef}
          onChange={(e) => handleLoadFile(e, pane.id)}
        />
      ))}
    </div>
  );
};

export default MultiPanePixelArt;