import { useState, ChangeEvent, MouseEvent } from 'react';
import { RGB, PixelGrid } from '../types';
import { createEmptyGrid } from '../utils/canvasUtils';
import { loadImageFromFile } from '../utils/fileUtils';
import {
  GRID_SIZE,
  DEFAULT_COLOR,
} from '../constants';

export interface Pane {
  id: number;
  name: string;
  pixels: PixelGrid;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
}

export default function useMultiPanePixelArt() {
  const [selectedColor, setSelectedColor] = useState<RGB>({ r: 0, g: 0, b: 0 });
  const [panes, setPanes] = useState<Pane[]>([
    {
      id: 1,
      name: 'Pane 1',
      pixels: createEmptyGrid(DEFAULT_COLOR),
      canvasRef: { current: null },
      fileInputRef: { current: null },
    }
  ]);
  const [activePaneId, setActivePaneId] = useState<number>(1);
  const [nextPaneId, setNextPaneId] = useState<number>(2);
  const [error, setError] = useState<string | null>(null);

  const activePane = panes.find(p => p.id === activePaneId);

  const createNewPane = () => {
    const newPane: Pane = {
      id: nextPaneId,
      name: `Pane ${nextPaneId}`,
      pixels: createEmptyGrid(DEFAULT_COLOR),
      canvasRef: { current: null },
      fileInputRef: { current: null },
    };
    setPanes(prev => [...prev, newPane]);
    setActivePaneId(nextPaneId);
    setNextPaneId(prev => prev + 1);
  };

  const closePane = (paneId: number) => {
    if (panes.length <= 1) return; // Keep at least one pane
    
    setPanes(prev => {
      const newPanes = prev.filter(p => p.id !== paneId);
      if (activePaneId === paneId) {
        setActivePaneId(newPanes[0].id);
      }
      return newPanes;
    });
  };

  const updatePanePixels = (paneId: number, newPixels: PixelGrid) => {
    setPanes(prev => prev.map(pane => 
      pane.id === paneId ? { ...pane, pixels: newPixels } : pane
    ));
  };

  const handleCanvasClick = (e: MouseEvent<HTMLCanvasElement>, paneId: number) => {
    const pane = panes.find(p => p.id === paneId);
    if (!pane?.canvasRef.current) return;

    const canvas = pane.canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Calculate which pixel was clicked based on canvas size
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const pixelSizeX = canvasWidth / GRID_SIZE;
    const pixelSizeY = canvasHeight / GRID_SIZE;
    
    const col = Math.floor(x / pixelSizeX);
    const row = Math.floor(y / pixelSizeY);

    if (row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE) {
      const newPixels = pane.pixels.map(r => r.slice());
      newPixels[row][col] = `rgb(${selectedColor.r}, ${selectedColor.g}, ${selectedColor.b})`;
      updatePanePixels(paneId, newPixels);
    }
  };

  const handleSave = (paneId: number) => {
    const pane = panes.find(p => p.id === paneId);
    if (!pane?.canvasRef.current) return;
    
    const canvas = pane.canvasRef.current;
    const link = document.createElement('a');
    link.download = `${pane.name.toLowerCase().replace(/\s+/g, '-')}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const handleLoadFile = async (e: ChangeEvent<HTMLInputElement>, paneId: number) => {
    setError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const img = await loadImageFromFile(file);
      const temp = document.createElement('canvas');
      temp.width = GRID_SIZE;
      temp.height = GRID_SIZE;
      const tctx = temp.getContext('2d');
      if (!tctx) throw new Error('Cannot get temp canvas context');
      tctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
      const data = tctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
      
      // Convert ImageData to PixelGrid
      const newPixels: PixelGrid = [];
      for (let row = 0; row < GRID_SIZE; row++) {
        newPixels[row] = [];
        for (let col = 0; col < GRID_SIZE; col++) {
          const i = (row * GRID_SIZE + col) * 4;
          const r = data.data[i];
          const g = data.data[i + 1];
          const b = data.data[i + 2];
          newPixels[row][col] = `rgb(${r}, ${g}, ${b})`;
        }
      }
      updatePanePixels(paneId, newPixels);
    } catch (err: any) {
      setError(err.message || 'Unknown error loading image');
    } finally {
      e.target.value = '';
    }
  };

  const triggerFileLoad = (paneId: number) => {
    const pane = panes.find(p => p.id === paneId);
    pane?.fileInputRef.current?.click();
  };

  return {
    selectedColor,
    setSelectedColor,
    panes,
    activePaneId,
    setActivePaneId,
    activePane,
    error,
    createNewPane,
    closePane,
    handleCanvasClick,
    handleSave,
    handleLoadFile,
    triggerFileLoad,
  };
}