export interface RGB {
  r: number;
  g: number;
  b: number;
}

export type PixelGrid = string[][];

export interface Pane {
  id: string;
  pixels: PixelGrid;
  name: string;
}
