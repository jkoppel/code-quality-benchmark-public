import React, { useRef, useEffect, ChangeEvent, MouseEvent } from 'react';
import { RGB, PixelGrid, Pane } from '../types';
import CanvasGrid from './CanvasGrid';
import Controls from './Controls';
import FileLoader from './FileLoader';
import { GRID_SIZE, PIXEL_SIZE } from '../constants';
import { drawPixelGrid, imageDataToGrid } from '../utils/canvasUtils';
import { loadImageFromFile, saveCanvasAsBitmap } from '../utils/fileUtils';

interface Props {
  pane: Pane;
  selectedColor: RGB;
  onPixelUpdate: (paneId: string, pixels: PixelGrid) => void;
  onClose: (paneId: string) => void;
  onError: (error: string) => void;
}

const PixelPane: React.FC<Props> = ({ pane, selectedColor, onPixelUpdate, onClose, onError }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    drawPixelGrid(ctx, pane.pixels);
  }, [pane.pixels]);

  function handleCanvasClick(e: MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const col = Math.floor(x / PIXEL_SIZE);
    const row = Math.floor(y / PIXEL_SIZE);

    if (
      row >= 0 &&
      row < GRID_SIZE &&
      col >= 0 &&
      col < GRID_SIZE
    ) {
      const newPixels = pane.pixels.map((r) => r.slice());
      newPixels[row][col] = `rgb(${selectedColor.r}, ${selectedColor.g}, ${selectedColor.b})`;
      onPixelUpdate(pane.id, newPixels);
    }
  }

  function handleSave() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    saveCanvasAsBitmap(canvas, `${pane.name}.png`);
  }

  async function handleLoadFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const img = await loadImageFromFile(file);
      const temp = document.createElement('canvas');
      temp.width = GRID_SIZE;
      temp.height = GRID_SIZE;
      const tctx = temp.getContext('2d');
      if (!tctx) throw new Error('Cannot get temp canvas context');
      tctx.drawImage(img, 0, 0, GRID_SIZE, GRID_SIZE);
      const data = tctx.getImageData(0, 0, GRID_SIZE, GRID_SIZE);
      onPixelUpdate(pane.id, imageDataToGrid(data));
    } catch (err: any) {
      onError(err.message || 'Unknown error loading image');
    } finally {
      e.target.value = '';
    }
  }

  function triggerFileLoad() {
    fileInputRef.current?.click();
  }

  return (
    <div className="pixel-pane">
      <div className="pane-header">
        <h3>{pane.name}</h3>
        <button className="close-pane-btn" onClick={() => onClose(pane.id)}>×</button>
      </div>
      <CanvasGrid canvasRef={canvasRef} onClick={handleCanvasClick} />
      <Controls onSave={handleSave} onLoadClick={triggerFileLoad} />
      <FileLoader fileInputRef={fileInputRef} onChange={handleLoadFile} />
    </div>
  );
};

export default PixelPane;