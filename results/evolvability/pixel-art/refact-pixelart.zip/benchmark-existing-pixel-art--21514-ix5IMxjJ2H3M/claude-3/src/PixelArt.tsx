import React from 'react';
import useMultiPane from './hooks/useMultiPane';
import ColorPicker from './components/ColorPicker';
import PixelPane from './components/PixelPane';
import './styles/PixelArt.css';

const PixelArt: React.FC = () => {
  const {
    selectedColor,
    setSelectedColor,
    panes,
    error,
    createNewPane,
    closePane,
    updatePanePixels,
    setError,
    clearError,
  } = useMultiPane();

  return (
    <div className="pixel-art-container">
      <h1>Multi-Pane Pixel Art Editor</h1>
      {error && (
        <div className="error">
          Error: {error}
          <button onClick={clearError} className="close-error">×</button>
        </div>
      )}
      <ColorPicker color={selectedColor} onChange={setSelectedColor} />
      <div className="pane-controls">
        <button onClick={createNewPane} className="add-pane-btn">
          + Add New Pane
        </button>
      </div>
      <div className="panes-container">
        {panes.map(pane => (
          <PixelPane
            key={pane.id}
            pane={pane}
            selectedColor={selectedColor}
            onPixelUpdate={updatePanePixels}
            onClose={closePane}
            onError={setError}
          />
        ))}
      </div>
    </div>
  );
};

export default PixelArt;