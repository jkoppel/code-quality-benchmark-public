import { useState } from 'react';
import { RGB, PixelGrid, Pane } from '../types';
import { createEmptyGrid } from '../utils/canvasUtils';
import { DEFAULT_COLOR } from '../constants';

export default function useMultiPane() {
  const [selectedColor, setSelectedColor] = useState<RGB>({ r: 0, g: 0, b: 0 });
  const [panes, setPanes] = useState<Pane[]>([
    {
      id: '1',
      name: 'Canvas 1',
      pixels: createEmptyGrid(DEFAULT_COLOR),
    }
  ]);
  const [error, setError] = useState<string | null>(null);
  const [nextPaneId, setNextPaneId] = useState(2);

  const createNewPane = () => {
    const newPane: Pane = {
      id: nextPaneId.toString(),
      name: `Canvas ${nextPaneId}`,
      pixels: createEmptyGrid(DEFAULT_COLOR),
    };
    setPanes(prev => [...prev, newPane]);
    setNextPaneId(prev => prev + 1);
  };

  const closePane = (paneId: string) => {
    if (panes.length === 1) {
      setError('Cannot close the last pane');
      return;
    }
    setPanes(prev => prev.filter(pane => pane.id !== paneId));
  };

  const updatePanePixels = (paneId: string, pixels: PixelGrid) => {
    setPanes(prev => prev.map(pane => 
      pane.id === paneId ? { ...pane, pixels } : pane
    ));
  };

  const clearError = () => setError(null);

  return {
    selectedColor,
    setSelectedColor,
    panes,
    error,
    createNewPane,
    closePane,
    updatePanePixels,
    setError,
    clearError,
  };
}