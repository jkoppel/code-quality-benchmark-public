(() => {
  const { useState, useEffect, useRef } = React;

  function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

  function App() {
    const width = 32;
    const height = 32;
    const cellSize = 16; // display scale

    const [r, setR] = useState(0);
    const [g, setG] = useState(0);
    const [b, setB] = useState(0);
    const [panes, setPanes] = useState([{ id: 1 }]);
    const [nextPaneId, setNextPaneId] = useState(2);

    function createNewPane() {
      setPanes(prev => [...prev, { id: nextPaneId }]);
      setNextPaneId(prev => prev + 1);
    }

    function closePane(paneId) {
      setPanes(prev => prev.filter(pane => pane.id !== paneId));
    }

    function PixelPane({ paneId }) {
      const canvasRef = useRef(null);
      const offscreenRef = useRef(null);
      const imageDataRef = useRef(null);
      const fileInputRef = useRef(null);

      // Initialize offscreen buffer and draw blank canvas
      useEffect(() => {
        const off = document.createElement('canvas');
        off.width = width;
        off.height = height;
        offscreenRef.current = off;
        const offCtx = off.getContext('2d');
        const imgData = offCtx.createImageData(width, height);
        for (let i = 0; i < imgData.data.length; i += 4) {
          imgData.data[i] = 255;
          imgData.data[i + 1] = 255;
          imgData.data[i + 2] = 255;
          imgData.data[i + 3] = 255;
        }
        offCtx.putImageData(imgData, 0, 0);
        imageDataRef.current = imgData;
        redraw();
      }, []);

      // Draw offscreen to visible canvas, scaled
      function redraw() {
        const canvas = canvasRef.current;
        const off = offscreenRef.current;
        if (!canvas || !off) return;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(off, 0, 0, off.width, off.height, 0, 0, off.width * cellSize, off.height * cellSize);
        // optional grid lines
        ctx.strokeStyle = 'rgba(0,0,0,0.1)';
        ctx.lineWidth = 1;
        for (let x = 0; x <= width; x++) {
          ctx.beginPath();
          ctx.moveTo(x * cellSize + 0.5, 0);
          ctx.lineTo(x * cellSize + 0.5, height * cellSize);
          ctx.stroke();
        }
        for (let y = 0; y <= height; y++) {
          ctx.beginPath();
          ctx.moveTo(0, y * cellSize + 0.5);
          ctx.lineTo(width * cellSize, y * cellSize + 0.5);
          ctx.stroke();
        }
      }

      function setPixel(x, y, rr, gg, bb, aa = 255) {
        if (x < 0 || y < 0 || x >= width || y >= height) return;
        const off = offscreenRef.current;
        const offCtx = off.getContext('2d');
        let imgData = imageDataRef.current;
        if (!imgData) {
          imgData = offCtx.getImageData(0, 0, width, height);
          imageDataRef.current = imgData;
        }
        const idx = (y * width + x) * 4;
        imgData.data[idx] = rr;
        imgData.data[idx + 1] = gg;
        imgData.data[idx + 2] = bb;
        imgData.data[idx + 3] = aa;
        offCtx.putImageData(imgData, 0, 0);
      }

      function handleCanvasClick(e) {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = Math.floor((e.clientX - rect.left) / cellSize);
        const y = Math.floor((e.clientY - rect.top) / cellSize);
        setPixel(x, y, r, g, b, 255);
        redraw();
      }

      function handleSave() {
        const off = offscreenRef.current;
        if (!off) return;
        off.toBlob((blob) => {
          if (!blob) return;
          const a = document.createElement('a');
          const url = URL.createObjectURL(blob);
          a.href = url;
          a.download = `pixel-art-${paneId}.png`;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 0);
        }, 'image/png');
      }

      function handleLoadFromFile(ev) {
        const file = ev.target.files && ev.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            const off = offscreenRef.current;
            const offCtx = off.getContext('2d');
            // Draw the image resized to our grid
            const temp = document.createElement('canvas');
            temp.width = width;
            temp.height = height;
            const tctx = temp.getContext('2d');
            tctx.imageSmoothingEnabled = false;
            tctx.drawImage(img, 0, 0, width, height);
            const imgData = tctx.getImageData(0, 0, width, height);
            imageDataRef.current = imgData;
            offCtx.putImageData(imgData, 0, 0);
            redraw();
            ev.target.value = '';
          };
          img.src = reader.result;
        };
        reader.readAsDataURL(file);
      }

      return React.createElement('div', { className: 'pane' },
        React.createElement('div', { className: 'pane-header' },
          React.createElement('span', null, `Pane ${paneId}`),
          panes.length > 1 && React.createElement('button', { 
            className: 'close-btn', 
            onClick: () => closePane(paneId),
            title: 'Close pane'
          }, '×')
        ),
        React.createElement('div', { className: 'canvas-wrap' },
          React.createElement('canvas', {
            ref: canvasRef,
            width: width * cellSize,
            height: height * cellSize,
            onClick: handleCanvasClick
          })
        ),
        React.createElement('div', { className: 'pane-actions' },
          React.createElement('button', { onClick: handleSave }, 'Save'),
          React.createElement('button', { onClick: () => fileInputRef.current && fileInputRef.current.click() }, 'Load'),
          React.createElement('input', { type: 'file', accept: 'image/*', onChange: handleLoadFromFile, ref: fileInputRef, style: { display: 'none' } })
        )
      );
    }

    function Controls() {
      const color = `rgb(${r}, ${g}, ${b})`;
      const onR = (e) => setR(clamp(Number(e.target.value), 0, 255));
      const onG = (e) => setG(clamp(Number(e.target.value), 0, 255));
      const onB = (e) => setB(clamp(Number(e.target.value), 0, 255));

      return React.createElement('div', { className: 'controls' },
        React.createElement('h3', null, 'Shared Color Picker'),
        React.createElement('div', { className: 'row' },
          React.createElement('label', null, 'R'),
          React.createElement('input', { type: 'range', min: 0, max: 255, value: r, onChange: onR }),
          React.createElement('input', { type: 'number', min: 0, max: 255, value: r, onChange: onR, className: 'num' })
        ),
        React.createElement('div', { className: 'row' },
          React.createElement('label', null, 'G'),
          React.createElement('input', { type: 'range', min: 0, max: 255, value: g, onChange: onG }),
          React.createElement('input', { type: 'number', min: 0, max: 255, value: g, onChange: onG, className: 'num' })
        ),
        React.createElement('div', { className: 'row' },
          React.createElement('label', null, 'B'),
          React.createElement('input', { type: 'range', min: 0, max: 255, value: b, onChange: onB }),
          React.createElement('input', { type: 'number', min: 0, max: 255, value: b, onChange: onB, className: 'num' })
        ),
        React.createElement('div', { className: 'preview', style: { backgroundColor: color } }),
        React.createElement('div', { className: 'actions' },
          React.createElement('button', { onClick: createNewPane }, 'New Pane')
        )
      );
    }

    return React.createElement('div', { className: 'app' },
      React.createElement('header', null, 'Pixel Art (React) - Multi-Pane Editor'),
      React.createElement('div', { className: 'main' },
        React.createElement(Controls, null),
        React.createElement('div', { className: 'panes-container' },
          panes.map(pane => React.createElement(PixelPane, { key: pane.id, paneId: pane.id }))
        )
      )
    );
  }

  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(React.createElement(App));
})();

