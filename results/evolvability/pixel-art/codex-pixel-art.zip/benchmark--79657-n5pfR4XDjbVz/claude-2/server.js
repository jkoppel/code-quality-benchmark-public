const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

function parsePortArg(defaultPort = 3000) {
  const argv = process.argv.slice(2);
  let port = defaultPort;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--port=')) {
      const v = Number(a.split('=')[1]);
      if (!Number.isNaN(v)) port = v;
    } else if (a === '--port' && i + 1 < argv.length) {
      const v = Number(argv[i + 1]);
      if (!Number.isNaN(v)) port = v;
    }
  }
  return port;
}

const PORT = parsePortArg(process.env.PORT ? Number(process.env.PORT) : 3000);
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.map': 'application/octet-stream'
};

function send(res, status, data, headers = {}) {
  res.writeHead(status, headers);
  res.end(data);
}

function serveFile(req, res) {
  const urlPath = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  let filePath = path.normalize(path.join(PUBLIC_DIR, urlPath));

  if (!filePath.startsWith(PUBLIC_DIR)) {
    return send(res, 403, 'Forbidden');
  }

  fs.stat(filePath, (err, stat) => {
    if (err) {
      // Fallback to index.html for SPA-style routing and root
      const indexPath = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(indexPath, (err2, data) => {
        if (err2) return send(res, 404, 'Not found');
        send(res, 200, data, { 'Content-Type': MIME['.html'] });
      });
      return;
    }

    if (stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    fs.readFile(filePath, (err3, data) => {
      if (err3) return send(res, 404, 'Not found');
      send(res, 200, data, { 'Content-Type': type });
    });
  });
}

const server = http.createServer(serveFile);

server.listen(PORT, () => {
  const url = `http://localhost:${PORT}/`;
  console.log(`Server running at ${url}`);

  // Try to open the default browser
  try {
    const platform = process.platform;
    if (platform === 'darwin') {
      spawn('open', [url], { stdio: 'ignore', detached: true }).unref();
    } else if (platform === 'win32') {
      const cmd = process.env.comspec || 'cmd';
      spawn(cmd, ['/c', 'start', '', url], { stdio: 'ignore', detached: true }).unref();
    } else {
      spawn('xdg-open', [url], { stdio: 'ignore', detached: true }).unref();
    }
  } catch (_) {
    // Ignore open errors
  }
});

