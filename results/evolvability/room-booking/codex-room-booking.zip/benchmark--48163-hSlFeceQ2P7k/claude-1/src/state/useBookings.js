import { useEffect, useMemo, useState } from 'react'
import { ALL_ROOMS, GRAND_BALLROOM, isBallroom, isGrand, RESOURCES } from '../rooms'
import { overlaps, withinDayBounds } from '../utils/time'

const STORAGE_KEY = 'room-bookings-v1'

export function useBookings() {
  const [bookings, setBookings] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      return raw ? JSON.parse(raw) : []
    } catch (e) {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings))
  }, [bookings])

  function addBooking({ roomId, date, name, start, duration, resources = [] }) {
    const err = validateBooking({ bookings, roomId, date, start, duration, resources })
    if (err) return { ok: false, error: err }
    const id = cryptoRandomId()
    const booking = { id, roomId, date, name, start, duration, resources }
    setBookings(prev => [...prev, booking])
    return { ok: true, booking }
  }

  function removeBooking(id) {
    setBookings(prev => prev.filter(b => b.id !== id))
  }

  return { bookings, addBooking, removeBooking }
}

function cryptoRandomId() {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const buf = new Uint32Array(4)
    crypto.getRandomValues(buf)
    return Array.from(buf).map(n => n.toString(16)).join('')
  }
  return Math.random().toString(36).slice(2)
}

export function validateBooking({ bookings, roomId, date, start, duration, resources = [] }) {
  if (!ALL_ROOMS.find(r => r.id === roomId)) return 'Unknown room'
  if (typeof start !== 'number' || typeof duration !== 'number') return 'Invalid time'
  if (start % 30 !== 0) return 'Start time must be on 30-minute boundary'
  if (![30, 60].includes(duration)) return 'Duration must be 30 or 60 minutes'
  if (!withinDayBounds(start, duration)) return 'Booking must fit within the day'

  // Check overlap within the same date
  const dayBookings = bookings.filter(b => b.date === date)

  const conflicts = []

  if (isGrand(roomId)) {
    // Grand Ballroom conflicts with any of its members + existing grand
    for (const b of dayBookings) {
      const related = isGrand(b.roomId) || GRAND_BALLROOM.members.includes(b.roomId)
      if (!related) continue
      if (overlaps(start, duration, b.start, b.duration)) conflicts.push(b)
    }
  } else if (isBallroom(roomId)) {
    // A single ballroom conflicts with itself and the grand
    for (const b of dayBookings) {
      const related = b.roomId === roomId || isGrand(b.roomId)
      if (!related) continue
      if (overlaps(start, duration, b.start, b.duration)) conflicts.push(b)
    }
  } else {
    // Regular room: only conflicts with itself
    for (const b of dayBookings) {
      if (b.roomId !== roomId) continue
      if (overlaps(start, duration, b.start, b.duration)) conflicts.push(b)
    }
  }

  if (conflicts.length) return 'Time conflicts with an existing booking'

  // Check resource availability
  for (const resourceId of resources) {
    const resource = RESOURCES.find(r => r.id === resourceId)
    if (!resource) return `Unknown resource: ${resourceId}`
    
    let usedCount = 0
    for (const b of dayBookings) {
      if (b.resources && b.resources.includes(resourceId) && overlaps(start, duration, b.start, b.duration)) {
        usedCount++
      }
    }
    
    if (usedCount >= resource.count) {
      return `${resource.name} not available - all ${resource.count} units already booked for this time`
    }
  }

  return null
}
