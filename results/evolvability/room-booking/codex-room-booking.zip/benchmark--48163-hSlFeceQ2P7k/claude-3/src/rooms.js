export const ROOMS = [
  { id: 'anaconda', name: 'Anaconda' },
  { id: 'baboon', name: 'Baboon' },
  { id: 'ballroom-1', name: 'Ballroom 1' },
  { id: 'ballroom-2', name: 'Ballroom 2' },
  { id: 'ballroom-3', name: 'Ballroom 3' },
]

export const GRAND_BALLROOM = {
  id: 'grand',
  name: 'Grand Ballroom',
  members: ['ballroom-1', 'ballroom-2', 'ballroom-3'],
}

export const ALL_ROOMS = [...ROOMS, GRAND_BALLROOM]

export function isGrand(roomId) {
  return roomId === GRAND_BALLROOM.id
}

export function isBallroom(roomId) {
  return ['ballroom-1', 'ballroom-2', 'ballroom-3'].includes(roomId)
}

export const RESOURCES = [
  { id: 'speakers', name: 'Speakers', count: 2 },
  { id: 'document-cameras', name: 'Document Cameras', count: 2 },
  { id: 'laptop-carts', name: 'Laptop Carts', count: 2 }
]

