import { useMemo, useState } from 'react'
import { ALL_ROOMS, GRAND_BALLROOM } from './rooms'
import { useBookings } from './state/useBookings'
import { fmtHour, hourOccupancyForBookings, minutesToLabel, labelToMinutes, normalizeDate } from './utils/time'
import { RESOURCES } from './resources'

function todayISO() {
  return normalizeDate(new Date())
}

export default function App() {
  const [selectedRoomId, setSelectedRoomId] = useState(ALL_ROOMS[0].id)
  const [date, setDate] = useState(todayISO())
  const { bookings, addBooking, removeBooking } = useBookings()

  const dayBookings = useMemo(() => bookings.filter(b => b.date === date), [bookings, date])
  const room = ALL_ROOMS.find(r => r.id === selectedRoomId)

  return (
    <div className="app">
      <aside className="sidebar">
        <h1>Rooms</h1>
        <div className="rooms">
          {ALL_ROOMS.map(r => (
            <button key={r.id} className={`room-btn ${r.id === selectedRoomId ? 'active' : ''}`} onClick={() => setSelectedRoomId(r.id)}>
              {r.name}
            </button>
          ))}
        </div>
        <div style={{ marginTop: 12, color: '#94a3b8', fontSize: 13 }}>
          Grand Ballroom joins Ballroom 1–3
        </div>
      </aside>
      <main className="content">
        <div className="toolbar">
          <label>
            <span style={{ marginRight: 8 }}>Date:</span>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </label>
          <span style={{ color: '#94a3b8' }}>|</span>
          <span style={{ color: '#94a3b8' }}>Viewing: {room.name}</span>
        </div>

        <AvailabilityGrid roomId={selectedRoomId} date={date} bookings={dayBookings} />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <BookForm date={date} onBook={addBooking} />
          <BookingsList roomId={selectedRoomId} date={date} bookings={dayBookings} onUnbook={removeBooking} />
        </div>
      </main>
    </div>
  )
}

function relevantBookingsForRoom(roomId, date, bookings) {
  if (roomId === GRAND_BALLROOM.id) {
    return bookings.filter(b => b.date === date && (b.roomId === GRAND_BALLROOM.id || GRAND_BALLROOM.members.includes(b.roomId)))
  }
  if (GRAND_BALLROOM.members.includes(roomId)) {
    return bookings.filter(b => b.date === date && (b.roomId === roomId || b.roomId === GRAND_BALLROOM.id))
  }
  return bookings.filter(b => b.date === date && b.roomId === roomId)
}

function AvailabilityGrid({ roomId, date, bookings }) {
  const relevant = useMemo(() => relevantBookingsForRoom(roomId, date, bookings), [roomId, date, bookings])
  return (
    <div className="section">
      <h2>Availability (hourly)</h2>
      <div className="grid">
        {Array.from({ length: 24 }, (_, h) => h).map(h => {
          const occ = hourOccupancyForBookings(h, relevant)
          const status = occ === 0 ? 'Available' : occ >= 60 ? 'Booked' : 'Partially booked'
          const cls = occ === 0 ? 'badge ok' : occ >= 60 ? 'badge busy' : 'badge partial'
          return (
            <div className="row" key={h}>
              <div className="cell hour">{fmtHour(h)}</div>
              <div className="cell availability">
                <span className={cls}>{status}</span>
                <span style={{ color: '#94a3b8' }}>{occ} / 60 min occupied</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function BookForm({ date, onBook }) {
  const [roomId, setRoomId] = useState(ALL_ROOMS[0].id)
  const [name, setName] = useState('')
  const [time, setTime] = useState('09:00')
  const [duration, setDuration] = useState(60)
  const [resourceId, setResourceId] = useState('')
  const [message, setMessage] = useState('')

  function submit(e) {
    e.preventDefault()
    const start = labelToMinutes(time)
    const res = onBook({ roomId, date, name: name.trim(), start, duration: Number(duration), resourceId: resourceId || null })
    if (res.ok) {
      setMessage('Booked successfully')
      setName('')
      setResourceId('')
    } else {
      setMessage(res.error || 'Failed to book')
    }
  }

  return (
    <div className="section">
      <h2>New Booking</h2>
      <form className="form" onSubmit={submit}>
        <select value={roomId} onChange={e => setRoomId(e.target.value)}>
          {ALL_ROOMS.map(r => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </select>
        <input placeholder="Your name" value={name} onChange={e => setName(e.target.value)} required />
        <input type="time" step={1800} value={time} onChange={e => setTime(e.target.value)} />
        <select value={duration} onChange={e => setDuration(e.target.value)}>
          <option value={30}>30 minutes</option>
          <option value={60}>60 minutes</option>
        </select>
        <select value={resourceId} onChange={e => setResourceId(e.target.value)}>
          <option value="">No resource</option>
          {RESOURCES.map(r => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </select>
        <button type="submit" disabled={!name.trim()}>Book</button>
      </form>
      {message && <div className="error" style={{ marginTop: 8 }}>{message}</div>}
    </div>
  )
}

function BookingsList({ roomId, date, bookings, onUnbook }) {
  const relevant = useMemo(() => relevantBookingsForRoom(roomId, date, bookings), [roomId, date, bookings])

  return (
    <div className="section">
      <h2>Bookings</h2>
      <div className="bookings">
        {relevant.length === 0 && <div style={{ color: '#94a3b8' }}>No bookings</div>}
        {relevant
          .slice()
          .sort((a, b) => a.start - b.start)
          .map(b => (
            <div className="booking" key={b.id}>
              <div>
                <div>{b.name || '(no name)'} — {minutesToLabel(b.start)} for {b.duration}m</div>
                <div className="meta">{ALL_ROOMS.find(r => r.id === b.roomId)?.name}{b.resourceId ? ` • ${RESOURCES.find(r => r.id === b.resourceId)?.name}` : ''}</div>
              </div>
              <button onClick={() => onUnbook(b.id)}>Unbook</button>
            </div>
          ))}
      </div>
    </div>
  )
}
