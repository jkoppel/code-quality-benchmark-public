export const RESOURCES = [
  { id: 'speakers', name: 'Speakers' },
  { id: 'document-camera', name: 'Document Camera' },
  { id: 'laptop-cart', name: 'Laptop Cart' },
]

export function isKnownResource(id) {
  if (!id) return true
  return RESOURCES.some(r => r.id === id)
}

