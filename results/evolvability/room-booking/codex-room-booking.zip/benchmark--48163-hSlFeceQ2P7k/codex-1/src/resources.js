export const RESOURCES = [
  { id: 'speakers', name: 'Speakers', capacity: 2 },
  { id: 'doc-camera', name: 'Document Camera', capacity: 2 },
  { id: 'laptop-cart', name: 'Laptop Cart', capacity: 2 },
]

export function resourceById(id) {
  return RESOURCES.find(r => r.id === id)
}

export function isValidResource(id) {
  if (id == null || id === '') return true
  return !!resourceById(id)
}

