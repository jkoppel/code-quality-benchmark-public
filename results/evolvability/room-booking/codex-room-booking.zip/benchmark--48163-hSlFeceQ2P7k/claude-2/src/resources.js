import { overlaps } from './utils/time'

export const RESOURCES = [
  { id: 'speakers', name: 'Speakers', maxQuantity: 2 },
  { id: 'document-cameras', name: 'Document Cameras', maxQuantity: 2 },
  { id: 'laptop-carts', name: 'Laptop Carts', maxQuantity: 2 },
]

export function getResourceById(id) {
  return RESOURCES.find(r => r.id === id)
}

export function getResourcesUsedInTimeSlot(bookings, date, start, duration) {
  const resourceUsage = {}
  
  // Initialize counts
  RESOURCES.forEach(resource => {
    resourceUsage[resource.id] = 0
  })
  
  // Count resources used in overlapping bookings
  const dayBookings = bookings.filter(b => b.date === date)
  
  for (const booking of dayBookings) {
    if (overlaps(start, duration, booking.start, booking.duration)) {
      if (booking.resources) {
        booking.resources.forEach(resourceId => {
          if (resourceUsage[resourceId] !== undefined) {
            resourceUsage[resourceId]++
          }
        })
      }
    }
  }
  
  return resourceUsage
}