export function minutesToLabel(mins) {
  const h = Math.floor(mins / 60)
  const m = mins % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

export function labelToMinutes(label) {
  const [h, m] = label.split(':').map(Number)
  return h * 60 + m
}

export function fmtHour(hour) {
  return `${String(hour).padStart(2, '0')}:00`
}

export function sameDay(a, b) {
  return a === b
}

export function overlaps(aStart, aDur, bStart, bDur) {
  const aEnd = aStart + aDur
  const bEnd = bStart + bDur
  return aStart < bEnd && bStart < aEnd
}

export function withinDayBounds(start, duration) {
  return start >= 0 && start + duration <= 24 * 60
}

export function normalizeDate(d) {
  if (typeof d === 'string') return d
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function hourOccupancyForBookings(hour, bookings) {
  const start = hour * 60
  const end = start + 60
  let occupied = 0
  // accumulate occupied minutes within [start, end)
  for (const b of bookings) {
    const s = Math.max(b.start, start)
    const e = Math.min(b.start + b.duration, end)
    if (e > s) occupied += (e - s)
    if (occupied >= 60) return 60
  }
  return Math.min(occupied, 60)
}

