import React, { useState } from 'react';
import './App.css';
import RoomList from './components/RoomList';
import RoomDetail from './components/RoomDetail';

const ROOMS = [
  { id: 'anaconda', name: 'Anaconda' },
  { id: 'baboon', name: 'Baboon' },
  { id: 'ballroom1', name: 'Ballroom 1' },
  { id: 'ballroom2', name: 'Ballroom 2' },
  { id: 'ballroom3', name: 'Ballroom 3' },
  { id: 'grand-ballroom', name: 'Grand Ballroom' }
];

function App() {
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [bookings, setBookings] = useState([]);

  const handleBookRoom = (roomId, time, name) => {
    const booking = {
      id: Date.now(),
      roomId,
      time,
      name,
      date: selectedDate
    };

    if (roomId === 'grand-ballroom') {
      const ballroomBookings = ['ballroom1', 'ballroom2', 'ballroom3'].map(id => ({
        ...booking,
        id: Date.now() + Math.random(),
        roomId: id
      }));
      setBookings(prev => [...prev, ...ballroomBookings]);
    } else {
      setBookings(prev => [...prev, booking]);
    }
  };

  const handleUnbook = (bookingId) => {
    setBookings(prev => prev.filter(b => b.id !== bookingId));
  };

  const isRoomAvailable = (roomId, time) => {
    if (roomId === 'grand-ballroom') {
      return ['ballroom1', 'ballroom2', 'ballroom3'].every(id => 
        !bookings.some(b => b.roomId === id && b.time === time && b.date === selectedDate)
      );
    }
    return !bookings.some(b => b.roomId === roomId && b.time === time && b.date === selectedDate);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Room Booking System</h1>
        <div className="date-selector">
          <label>
            Select Date: 
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
            />
          </label>
        </div>
      </header>
      <main className="App-main">
        {!selectedRoom ? (
          <RoomList rooms={ROOMS} onSelectRoom={setSelectedRoom} />
        ) : (
          <RoomDetail 
            room={selectedRoom}
            date={selectedDate}
            bookings={bookings.filter(b => b.date === selectedDate)}
            onBook={handleBookRoom}
            onUnbook={handleUnbook}
            onBack={() => setSelectedRoom(null)}
            isRoomAvailable={isRoomAvailable}
          />
        )}
      </main>
    </div>
  );
}

export default App;
