import React, { useState } from 'react';

const RoomDetail = ({ room, date, bookings, onBook, onUnbook, onBack, isRoomAvailable, resources, isResourceAvailable, areResourcesAvailable, getResourceUsage }) => {
  const [selectedTime, setSelectedTime] = useState('');
  const [bookerName, setBookerName] = useState('');
  const [selectedResources, setSelectedResources] = useState([]);

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour < 22; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
      slots.push(`${hour.toString().padStart(2, '0')}:30`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handleBook = (e) => {
    e.preventDefault();
    if (selectedTime && bookerName.trim()) {
      onBook(room.id, selectedTime, bookerName.trim(), selectedResources);
      setSelectedTime('');
      setBookerName('');
      setSelectedResources([]);
    }
  };

  const handleResourceToggle = (resourceId) => {
    setSelectedResources(prev => {
      const isSelected = prev.includes(resourceId);
      if (isSelected) {
        return prev.filter(id => id !== resourceId);
      } else {
        return [...prev, resourceId];
      }
    });
  };

  const canBookWithResources = () => {
    if (!selectedTime) return false;
    return areResourcesAvailable(selectedResources, selectedTime);
  };

  const getRoomBookings = () => {
    if (room.id === 'grand-ballroom') {
      return bookings.filter(b => ['ballroom1', 'ballroom2', 'ballroom3'].includes(b.roomId));
    }
    return bookings.filter(b => b.roomId === room.id);
  };

  const roomBookings = getRoomBookings();

  return (
    <div className="room-detail">
      <button className="back-button" onClick={onBack}>← Back to Rooms</button>
      <h2>{room.name}</h2>
      <h3>Date: {new Date(date).toLocaleDateString()}</h3>

      <div className="booking-section">
        <h4>Book This Room</h4>
        <form onSubmit={handleBook} className="booking-form">
          <div className="form-group">
            <label>Your Name:</label>
            <input
              type="text"
              value={bookerName}
              onChange={(e) => setBookerName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Time:</label>
            <select
              value={selectedTime}
              onChange={(e) => setSelectedTime(e.target.value)}
              required
            >
              <option value="">Select a time</option>
              {timeSlots.map(time => (
                <option 
                  key={time} 
                  value={time}
                  disabled={!isRoomAvailable(room.id, time)}
                >
                  {time} {!isRoomAvailable(room.id, time) ? '(Booked)' : ''}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Additional Resources (optional):</label>
            <div className="resources-selection">
              {resources.map(resource => {
                const usage = selectedTime ? getResourceUsage(resource.id, selectedTime) : 0;
                const available = resource.quantity - usage;
                const isDisabled = selectedTime && !isResourceAvailable(resource.id, selectedTime);
                const isSelected = selectedResources.includes(resource.id);
                
                return (
                  <div key={resource.id} className="resource-option">
                    <label className={`resource-checkbox ${isDisabled ? 'disabled' : ''}`}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleResourceToggle(resource.id)}
                        disabled={isDisabled && !isSelected}
                      />
                      <span className="resource-name">{resource.name}</span>
                      <span className="resource-availability">
                        ({available} of {resource.quantity} available)
                      </span>
                    </label>
                  </div>
                );
              })}
            </div>
            {selectedTime && selectedResources.length > 0 && !canBookWithResources() && (
              <div className="resource-error">
                Some selected resources are not available for this time slot.
              </div>
            )}
          </div>
          <button type="submit" disabled={!selectedTime || !bookerName.trim() || !canBookWithResources()}>
            Book Room {selectedResources.length > 0 && '+ Resources'}
          </button>
        </form>
      </div>

      <div className="availability-section">
        <h4>Current Bookings</h4>
        {roomBookings.length === 0 ? (
          <p>No bookings for this date</p>
        ) : (
          <div className="bookings-list">
            {roomBookings
              .sort((a, b) => a.time.localeCompare(b.time))
              .map(booking => (
                <div key={booking.id} className="booking-item">
                  <span className="booking-time">{booking.time}</span>
                  <span className="booking-name">{booking.name}</span>
                  {room.id === 'grand-ballroom' && (
                    <span className="booking-room">{booking.roomId}</span>
                  )}
                  {booking.resources && booking.resources.length > 0 && (
                    <span className="booking-resources">
                      Resources: {booking.resources.map(resourceId => {
                        const resource = resources.find(r => r.id === resourceId);
                        return resource ? resource.name : resourceId;
                      }).join(', ')}
                    </span>
                  )}
                  <button 
                    className="unbook-button"
                    onClick={() => onUnbook(booking.id)}
                  >
                    Cancel
                  </button>
                </div>
              ))}
          </div>
        )}
      </div>

      <div className="availability-grid">
        <h4>Availability Overview</h4>
        <div className="time-grid">
          {timeSlots.map(time => (
            <div 
              key={time} 
              className={`time-slot ${isRoomAvailable(room.id, time) ? 'available' : 'booked'}`}
            >
              <span className="time">{time}</span>
              <span className="status">
                {isRoomAvailable(room.id, time) ? 'Available' : 'Booked'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoomDetail;