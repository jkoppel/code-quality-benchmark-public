import React from 'react';

const RoomList = ({ rooms, onSelectRoom }) => {
  return (
    <div className="room-list">
      <h2>Available Rooms</h2>
      <div className="rooms-grid">
        {rooms.map(room => (
          <div key={room.id} className="room-card" onClick={() => onSelectRoom(room)}>
            <h3>{room.name}</h3>
            <p>Click to view availability</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoomList;