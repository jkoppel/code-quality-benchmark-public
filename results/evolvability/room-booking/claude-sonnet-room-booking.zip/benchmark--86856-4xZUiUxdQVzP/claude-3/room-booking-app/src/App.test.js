import { render, screen } from '@testing-library/react';
import App from './App';

test('renders room booking system', () => {
  render(<App />);
  const titleElement = screen.getByText(/room booking system/i);
  expect(titleElement).toBeInTheDocument();
  const roomsElement = screen.getByText(/available rooms/i);
  expect(roomsElement).toBeInTheDocument();
});
