import React, { useState } from 'react';

const RoomDetail = ({ room, date, bookings, onBook, onUnbook, onBack, isRoomAvailable, resources, getResourceAvailability, isResourceAvailable }) => {
  const [selectedTime, setSelectedTime] = useState('');
  const [bookerName, setBookerName] = useState('');
  const [selectedResources, setSelectedResources] = useState([]);

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour < 22; hour++) {
      slots.push(`${hour.toString().padStart(2, '0')}:00`);
      slots.push(`${hour.toString().padStart(2, '0')}:30`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handleBook = (e) => {
    e.preventDefault();
    if (selectedTime && bookerName.trim()) {
      onBook(room.id, selectedTime, bookerName.trim(), selectedResources);
      setSelectedTime('');
      setBookerName('');
      setSelectedResources([]);
    }
  };

  const toggleResource = (resourceId) => {
    setSelectedResources(prev => 
      prev.includes(resourceId)
        ? prev.filter(id => id !== resourceId)
        : [...prev, resourceId]
    );
  };

  const getRoomBookings = () => {
    if (room.id === 'grand-ballroom') {
      return bookings.filter(b => ['ballroom1', 'ballroom2', 'ballroom3'].includes(b.roomId));
    }
    return bookings.filter(b => b.roomId === room.id);
  };

  const roomBookings = getRoomBookings();

  return (
    <div className="room-detail">
      <button className="back-button" onClick={onBack}>← Back to Rooms</button>
      <h2>{room.name}</h2>
      <h3>Date: {new Date(date).toLocaleDateString()}</h3>

      <div className="booking-section">
        <h4>Book This Room</h4>
        <form onSubmit={handleBook} className="booking-form">
          <div className="form-group">
            <label>Your Name:</label>
            <input
              type="text"
              value={bookerName}
              onChange={(e) => setBookerName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Time:</label>
            <select
              value={selectedTime}
              onChange={(e) => setSelectedTime(e.target.value)}
              required
            >
              <option value="">Select a time</option>
              {timeSlots.map(time => (
                <option 
                  key={time} 
                  value={time}
                  disabled={!isRoomAvailable(room.id, time)}
                >
                  {time} {!isRoomAvailable(room.id, time) ? '(Booked)' : ''}
                </option>
              ))}
            </select>
          </div>
          {selectedTime && resources && (
            <div className="form-group">
              <label>Resources:</label>
              <div className="resources-selection">
                {resources.map(resource => {
                  const available = getResourceAvailability(resource.id, selectedTime);
                  const canSelect = available > 0 && !selectedResources.includes(resource.id);
                  return (
                    <div key={resource.id} className="resource-option">
                      <label>
                        <input
                          type="checkbox"
                          checked={selectedResources.includes(resource.id)}
                          onChange={() => toggleResource(resource.id)}
                          disabled={!canSelect && !selectedResources.includes(resource.id)}
                        />
                        {resource.name} ({available} available)
                      </label>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          <button type="submit" disabled={!selectedTime || !bookerName.trim()}>
            Book Room
          </button>
        </form>
      </div>

      <div className="availability-section">
        <h4>Current Bookings</h4>
        {roomBookings.length === 0 ? (
          <p>No bookings for this date</p>
        ) : (
          <div className="bookings-list">
            {roomBookings
              .sort((a, b) => a.time.localeCompare(b.time))
              .map(booking => (
                <div key={booking.id} className="booking-item">
                  <span className="booking-time">{booking.time}</span>
                  <span className="booking-name">{booking.name}</span>
                  {room.id === 'grand-ballroom' && (
                    <span className="booking-room">{booking.roomId}</span>
                  )}
                  {booking.resources && booking.resources.length > 0 && (
                    <span className="booking-resources">
                      Resources: {booking.resources.map(resourceId => 
                        resources?.find(r => r.id === resourceId)?.name
                      ).join(', ')}
                    </span>
                  )}
                  <button 
                    className="unbook-button"
                    onClick={() => onUnbook(booking.id)}
                  >
                    Cancel
                  </button>
                </div>
              ))}
          </div>
        )}
      </div>

      <div className="availability-grid">
        <h4>Availability Overview</h4>
        <div className="time-grid">
          {timeSlots.map(time => (
            <div 
              key={time} 
              className={`time-slot ${isRoomAvailable(room.id, time) ? 'available' : 'booked'}`}
            >
              <span className="time">{time}</span>
              <span className="status">
                {isRoomAvailable(room.id, time) ? 'Available' : 'Booked'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoomDetail;