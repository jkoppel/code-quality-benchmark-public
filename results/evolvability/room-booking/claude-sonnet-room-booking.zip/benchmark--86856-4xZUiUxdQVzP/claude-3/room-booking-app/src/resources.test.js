import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

test('resource booking functionality', () => {
  render(<App />);
  
  // Click on a room to open room detail
  const roomCard = screen.getByText('Anaconda');
  fireEvent.click(roomCard);
  
  // Check that booking form appears
  expect(screen.getByText('Book This Room')).toBeInTheDocument();
  
  // Select a time to reveal resources
  const timeSelect = screen.getByRole('combobox');
  fireEvent.change(timeSelect, { target: { value: '09:00' } });
  
  // Check that resources appear with correct availability
  expect(screen.getByText('Speakers (2 available)')).toBeInTheDocument();
  expect(screen.getByText('Document Cameras (2 available)')).toBeInTheDocument();
  expect(screen.getByText('Laptop Carts (2 available)')).toBeInTheDocument();
});