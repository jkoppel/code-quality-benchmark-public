export type Resource = 'Speakers' | 'Document Camera' | 'Laptop Cart';

export interface Booking {
  id: string;
  roomName: string;
  date: string;
  startTime: string;
  endTime: string;
  userName: string;
  resource?: Resource;
}

export interface Room {
  name: string;
  isVirtual?: boolean;
  components?: string[];
}

export interface TimeSlot {
  time: string;
  available: boolean;
  booking?: Booking;
}
