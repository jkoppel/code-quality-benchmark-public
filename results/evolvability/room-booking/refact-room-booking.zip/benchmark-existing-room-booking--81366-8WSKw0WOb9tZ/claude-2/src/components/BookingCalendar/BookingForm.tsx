import React from 'react';
import { HOURS, RESOURCES } from '../../constants';

interface BookingFormProps {
  selectedRoom: string;
  selectedSlot: string;
  selectedEndSlot: string | null;
  userName: string;
  selectedResources: string[];
  onUserNameChange: (name: string) => void;
  onResourcesChange: (resources: string[]) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  selectedRoom,
  selectedSlot,
  selectedEndSlot,
  userName,
  selectedResources,
  onUserNameChange,
  onResourcesChange,
  onConfirm,
  onCancel
}) => {
  const getEndTime = () => {
    if (selectedEndSlot) {
      const endIndex = HOURS.indexOf(selectedEndSlot);
      return HOURS[endIndex + 1] || '20:00';
    } else {
      const startIndex = HOURS.indexOf(selectedSlot);
      return HOURS[startIndex + 1] || '20:00';
    }
  };

  const handleResourceChange = (resourceName: string, checked: boolean) => {
    if (checked) {
      onResourcesChange([...selectedResources, resourceName]);
    } else {
      onResourcesChange(selectedResources.filter(r => r !== resourceName));
    }
  };

  return (
    <div className="booking-form">
      <h4>Book {selectedRoom}</h4>
      <p>From {selectedSlot} to {getEndTime()}</p>
      <input
        type="text"
        placeholder="Your name"
        value={userName}
        onChange={(e) => onUserNameChange(e.target.value)}
      />
      
      <div className="resources-section">
        <h5>Additional Resources (Optional):</h5>
        {RESOURCES.map(resource => (
          <label key={resource.name} className="resource-checkbox">
            <input
              type="checkbox"
              checked={selectedResources.includes(resource.name)}
              onChange={(e) => handleResourceChange(resource.name, e.target.checked)}
            />
            {resource.name} (Available: {resource.totalCount})
          </label>
        ))}
      </div>

      <button onClick={onConfirm} disabled={!userName.trim()}>
        Confirm Booking
      </button>
      <button onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default BookingForm;
