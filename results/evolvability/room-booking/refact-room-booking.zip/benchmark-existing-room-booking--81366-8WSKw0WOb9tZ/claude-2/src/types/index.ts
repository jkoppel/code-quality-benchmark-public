export interface Booking {
  id: string;
  roomName: string;
  date: string;
  startTime: string;
  endTime: string;
  userName: string;
  resources?: string[];
}

export interface Room {
  name: string;
  isVirtual?: boolean;
  components?: string[];
}

export interface TimeSlot {
  time: string;
  available: boolean;
  booking?: Booking;
}

export interface Resource {
  name: string;
  totalCount: number;
}
