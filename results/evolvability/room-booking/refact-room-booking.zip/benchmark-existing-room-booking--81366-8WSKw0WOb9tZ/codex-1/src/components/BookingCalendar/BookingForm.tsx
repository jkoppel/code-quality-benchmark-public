import React from 'react';
import { ResourceType } from '../../types';
import { HOURS } from '../../constants';

interface BookingFormProps {
  selectedRoom: string;
  selectedSlot: string;
  selectedEndSlot: string | null;
  userName: string;
  resource: ResourceType | null;
  onUserNameChange: (name: string) => void;
  onResourceChange: (resource: ResourceType | null) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  selectedRoom,
  selectedSlot,
  selectedEndSlot,
  userName,
  resource,
  onUserNameChange,
  onResourceChange,
  onConfirm,
  onCancel
}) => {
  const getEndTime = () => {
    if (selectedEndSlot) {
      const endIndex = HOURS.indexOf(selectedEndSlot);
      return HOURS[endIndex + 1] || '20:00';
    } else {
      const startIndex = HOURS.indexOf(selectedSlot);
      return HOURS[startIndex + 1] || '20:00';
    }
  };

  return (
    <div className="booking-form">
      <h4>Book {selectedRoom}</h4>
      <p>From {selectedSlot} to {getEndTime()}</p>
      <input
        type="text"
        placeholder="Your name"
        value={userName}
        onChange={(e) => onUserNameChange(e.target.value)}
      />
      <div style={{ marginTop: '8px' }}>
        <label>
          Resource:
          <select
            value={resource || ''}
            onChange={e => onResourceChange((e.target.value || null) as ResourceType | null)}
            style={{ marginLeft: '8px' }}
          >
            <option value="">None</option>
            <option value="speakers">Speakers</option>
            <option value="document_camera">Document Camera</option>
            <option value="laptop_cart">Laptop Cart</option>
          </select>
        </label>
      </div>
      <button onClick={onConfirm} disabled={!userName.trim()}>
        Confirm Booking
      </button>
      <button onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default BookingForm;
