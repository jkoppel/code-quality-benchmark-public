import { useState, useCallback } from 'react';
import { Booking, ResourceType } from '../types';
import { createBooking, cancelBooking, hasResourceCapacity } from '../services/bookingService';

/**
 * Hook to manage booking state with centralized business logic
 */
export function useBookings(initialBookings: Booking[] = []) {
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);

  const addBooking = useCallback(
    (
      roomName: string,
      date: string,
      startTime: string,
      endTime: string,
      userName: string,
      resources: ResourceType[] = []
    ) => {
      setBookings(prev => {
        if (!hasResourceCapacity(prev, date, startTime, endTime, resources)) {
          alert('Selected resources are fully booked for this time range.');
          return prev;
        }
        const newBookings = createBooking(roomName, date, startTime, endTime, userName, resources);
        return [...prev, ...newBookings];
      });
    },
    []
  );

  const removeBooking = useCallback(
    (bookingId: string) => {
      setBookings(prev => cancelBooking(prev, bookingId));
    },
    []
  );

  return {
    bookings,
    addBooking,
    removeBooking
  };
}
