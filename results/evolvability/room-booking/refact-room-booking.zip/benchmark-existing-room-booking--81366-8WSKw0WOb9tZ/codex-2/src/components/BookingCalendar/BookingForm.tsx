import React from 'react';
import { HOURS, RESOURCES } from '../../constants';
import { ResourceType } from '../../types';

interface BookingFormProps {
  selectedRoom: string;
  selectedSlot: string;
  selectedEndSlot: string | null;
  userName: string;
  selectedResources: ResourceType[];
  onUserNameChange: (name: string) => void;
  onResourcesChange: (resources: ResourceType[]) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  selectedRoom,
  selectedSlot,
  selectedEndSlot,
  userName,
  selectedResources,
  onUserNameChange,
  onResourcesChange,
  onConfirm,
  onCancel
}) => {
  const getEndTime = () => {
    if (selectedEndSlot) {
      const endIndex = HOURS.indexOf(selectedEndSlot);
      return HOURS[endIndex + 1] || '20:00';
    } else {
      const startIndex = HOURS.indexOf(selectedSlot);
      return HOURS[startIndex + 1] || '20:00';
    }
  };

  return (
    <div className="booking-form">
      <h4>Book {selectedRoom}</h4>
      <p>From {selectedSlot} to {getEndTime()}</p>
      <input
        type="text"
        placeholder="Your name"
        value={userName}
        onChange={(e) => onUserNameChange(e.target.value)}
      />
      <div style={{ marginTop: '8px', marginBottom: '8px' }}>
        <p style={{ margin: 0 }}>Resources (max 2 of each available):</p>
        {RESOURCES.map((res) => {
          const checked = selectedResources.includes(res);
          return (
            <label key={res} style={{ display: 'block' }}>
              <input
                type="checkbox"
                checked={checked}
                onChange={(e) => {
                  const next = e.target.checked
                    ? [...selectedResources, res]
                    : selectedResources.filter(r => r !== res);
                  onResourcesChange(next);
                }}
              />{' '}
              {res}
            </label>
          );
        })}
      </div>
      <button onClick={onConfirm} disabled={!userName.trim()}>
        Confirm Booking
      </button>
      <button onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default BookingForm;
