import React, { useState } from 'react';
import { HOURS, RESOURCES } from '../../constants';

interface BookingFormProps {
  selectedRoom: string;
  selectedSlot: string;
  selectedEndSlot: string | null;
  userName: string;
  onUserNameChange: (name: string) => void;
  onConfirm: (resources?: string[]) => void;
  onCancel: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  selectedRoom,
  selectedSlot,
  selectedEndSlot,
  userName,
  onUserNameChange,
  onConfirm,
  onCancel
}) => {
  const [selectedResources, setSelectedResources] = useState<string[]>([]);
  const getEndTime = () => {
    if (selectedEndSlot) {
      const endIndex = HOURS.indexOf(selectedEndSlot);
      return HOURS[endIndex + 1] || '20:00';
    } else {
      const startIndex = HOURS.indexOf(selectedSlot);
      return HOURS[startIndex + 1] || '20:00';
    }
  };

  const handleResourceToggle = (resource: string) => {
    setSelectedResources(prev => 
      prev.includes(resource) 
        ? prev.filter(r => r !== resource)
        : [...prev, resource]
    );
  };

  const handleConfirm = () => {
    onConfirm(selectedResources.length > 0 ? selectedResources : undefined);
  };

  return (
    <div className="booking-form">
      <h4>Book {selectedRoom}</h4>
      <p>From {selectedSlot} to {getEndTime()}</p>
      <input
        type="text"
        placeholder="Your name"
        value={userName}
        onChange={(e) => onUserNameChange(e.target.value)}
      />
      
      <div style={{ margin: '10px 0' }}>
        <h5>Additional Resources (optional):</h5>
        {RESOURCES.map(resource => (
          <label key={resource} style={{ display: 'block', margin: '5px 0' }}>
            <input
              type="checkbox"
              checked={selectedResources.includes(resource)}
              onChange={() => handleResourceToggle(resource)}
            />
            {' '}{resource} (2 available)
          </label>
        ))}
      </div>

      <button onClick={handleConfirm} disabled={!userName.trim()}>
        Confirm Booking
      </button>
      <button onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default BookingForm;
