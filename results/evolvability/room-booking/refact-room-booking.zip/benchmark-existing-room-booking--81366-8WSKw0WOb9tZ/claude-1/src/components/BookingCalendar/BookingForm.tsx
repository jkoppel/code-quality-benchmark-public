import React, { useState } from 'react';
import { HOURS, RESOURCES } from '../../constants';

interface BookingFormProps {
  selectedRoom: string;
  selectedSlot: string;
  selectedEndSlot: string | null;
  userName: string;
  onUserNameChange: (name: string) => void;
  onConfirm: (resources: string[]) => void;
  onCancel: () => void;
}

const BookingForm: React.FC<BookingFormProps> = ({
  selectedRoom,
  selectedSlot,
  selectedEndSlot,
  userName,
  onUserNameChange,
  onConfirm,
  onCancel
}) => {
  const [selectedResources, setSelectedResources] = useState<string[]>([]);

  const handleResourceToggle = (resource: string) => {
    setSelectedResources(prev => 
      prev.includes(resource)
        ? prev.filter(r => r !== resource)
        : [...prev, resource]
    );
  };

  const getEndTime = () => {
    if (selectedEndSlot) {
      const endIndex = HOURS.indexOf(selectedEndSlot);
      return HOURS[endIndex + 1] || '20:00';
    } else {
      const startIndex = HOURS.indexOf(selectedSlot);
      return HOURS[startIndex + 1] || '20:00';
    }
  };

  return (
    <div className="booking-form">
      <h4>Book {selectedRoom}</h4>
      <p>From {selectedSlot} to {getEndTime()}</p>
      <input
        type="text"
        placeholder="Your name"
        value={userName}
        onChange={(e) => onUserNameChange(e.target.value)}
      />
      
      <div className="resources-section">
        <h5>Additional Resources (Optional)</h5>
        {RESOURCES.map(resource => (
          <label key={resource} className="resource-checkbox">
            <input
              type="checkbox"
              checked={selectedResources.includes(resource)}
              onChange={() => handleResourceToggle(resource)}
            />
            {resource} (2 available)
          </label>
        ))}
      </div>
      
      <button onClick={() => onConfirm(selectedResources)} disabled={!userName.trim()}>
        Confirm Booking
      </button>
      <button onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default BookingForm;
